/**
 * Navbar.js — Sticky navigation bar component
 * logsearch.xyz
 *
 * - Auth-aware: shows Login/Register or Profile dropdown
 * - Responsive hamburger menu
 * - Active link highlighting
 * - SPA navigation via data-link
 */

import { $, $$ } from '../utils.js';
import { isAuthenticated, getUser, performLogout, subscribe } from '../store.js';
import { navigate } from '../router.js';


/** Navbar links (public) */
const NAV_LINKS = [
    { label: 'Log Arama', href: '/search' },
    { label: 'Durum', href: '/status' },
    { label: 'Dokümantasyon', href: '/docs' },
    { label: 'Fiyatlandırma', href: '/pricing' },
];

/**
 * Render the Navbar
 */
export function renderNavbar() {
    const el = $('#navbar');
    if (!el) return;

    el.innerHTML = '';
    el.className = 'navbar';

    const inner = document.createElement('div');
    inner.className = 'navbar__inner container';

    // Brand
    const brand = document.createElement('a');
    brand.href = '/';
    brand.className = 'navbar__brand';
    brand.setAttribute('data-link', '/');
    brand.innerHTML = 'logsearch<span class="navbar__brand-xyz">.xyz</span>';

    // Links
    const links = document.createElement('nav');
    links.className = 'navbar__links';
    links.setAttribute('aria-label', 'Ana navigasyon');

    NAV_LINKS.forEach(({ label, href }) => {
        const a = document.createElement('a');
        a.href = href;
        a.className = 'navbar__link';
        a.setAttribute('data-link', href);
        a.textContent = label;
        links.appendChild(a);
    });

    // Actions (auth buttons or profile)
    const actions = document.createElement('div');
    actions.className = 'navbar__actions';
    actions.id = 'navbar-actions';
    renderAuthSection(actions);

    // Hamburger
    const hamburger = document.createElement('button');
    hamburger.className = 'navbar__hamburger';
    hamburger.setAttribute('aria-label', 'Menüyü aç');
    hamburger.innerHTML = '<span></span><span></span><span></span>';

    // Mobile nav
    const mobileNav = document.createElement('div');
    mobileNav.className = 'navbar__mobile';
    mobileNav.id = 'navbar-mobile';

    NAV_LINKS.forEach(({ label, href }) => {
        const a = document.createElement('a');
        a.href = href;
        a.className = 'navbar__link';
        a.setAttribute('data-link', href);
        a.textContent = label;
        mobileNav.appendChild(a);
    });

    const mobileActions = document.createElement('div');
    mobileActions.className = 'navbar__actions';
    mobileActions.id = 'navbar-mobile-actions';
    renderAuthSection(mobileActions);
    mobileNav.appendChild(mobileActions);

    // Hamburger toggle with morphing animation
    hamburger.addEventListener('click', () => {
        const isOpen = mobileNav.classList.toggle('is-open');
        hamburger.classList.toggle('is-active', isOpen);
        document.body.classList.toggle('scroll-locked', isOpen);
    });

    // Close mobile nav on link click
    mobileNav.addEventListener('click', (e) => {
        if (e.target.closest('[data-link]')) {
            mobileNav.classList.remove('is-open');
            hamburger.classList.remove('is-active');
            document.body.classList.remove('scroll-locked');
        }
    });


    inner.appendChild(brand);
    inner.appendChild(links);
    inner.appendChild(actions);
    inner.appendChild(hamburger);
    el.appendChild(inner);

    // Clean up existing spacer and mobile nav to prevent duplication
    document.querySelector('.navbar-spacer')?.remove();
    document.querySelector('.navbar__mobile')?.remove();

    // Insert spacer for fixed navbar
    const spacer = document.createElement('div');
    spacer.className = 'navbar-spacer';
    el.after(spacer);
    spacer.after(mobileNav);

    // Global click handler to close profile dropdown (added once)
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.navbar__profile')) {
            document.querySelectorAll('.navbar__dropdown.is-open').forEach(d => d.classList.remove('is-open'));
        }
    });

    // Scroll-aware navbar shrink
    let ticking = false;
    const onScroll = () => {
        if (!ticking) {
            requestAnimationFrame(() => {
                el.classList.toggle('is-scrolled', window.scrollY > 30);
                ticking = false;
            });
            ticking = true;
        }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    // Subscribe to auth changes
    subscribe('auth', () => {
        renderAuthSection($('#navbar-actions'));
        renderAuthSection($('#navbar-mobile-actions'));
    });
}

/**
 * Render auth section (login/register or profile dropdown)
 * @param {HTMLElement} container
 */
function renderAuthSection(container) {
    if (!container) return;

    container.innerHTML = '';

    if (isAuthenticated()) {
        const user = getUser();
        const initials = (user?.name || user?.email || 'U').charAt(0).toUpperCase();

        // Profile button
        const profileWrap = document.createElement('div');
        profileWrap.className = 'navbar__profile';

        const profileBtn = document.createElement('button');
        profileBtn.className = 'navbar__profile-btn';
        profileBtn.innerHTML = `
      <span class="navbar__avatar">${initials}</span>
      <span>${user?.name || user?.email || 'Kullanıcı'}</span>
      <span style="font-size:0.6rem; margin-left:2px;">▼</span>
    `;

        // Dropdown
        const dropdown = document.createElement('div');
        dropdown.className = 'navbar__dropdown';
        dropdown.innerHTML = `
      <a class="navbar__dropdown-item" href="/dashboard" data-link="/dashboard">Dashboard</a>
      <a class="navbar__dropdown-item" href="/dashboard/keys" data-link="/dashboard/keys">API Anahtarları</a>
      <a class="navbar__dropdown-item" href="/dashboard/usage" data-link="/dashboard/usage">Kullanım</a>
      <div class="navbar__dropdown-divider"></div>
      <button class="navbar__dropdown-item" id="logout-btn">Çıkış Yap</button>
    `;

        profileBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            dropdown.classList.toggle('is-open');
        });

        // Logout
        dropdown.querySelector('#logout-btn')?.addEventListener('click', async () => {
            await performLogout();
            navigate('/');
        });

        // Close dropdown on nav
        dropdown.addEventListener('click', (e) => {
            if (e.target.closest('[data-link]')) {
                dropdown.classList.remove('is-open');
            }
        });

        profileWrap.appendChild(profileBtn);
        profileWrap.appendChild(dropdown);
        container.appendChild(profileWrap);
    } else {
        const loginBtn = document.createElement('a');
        loginBtn.href = '/auth/login';
        loginBtn.className = 'btn btn--ghost btn--sm';
        loginBtn.setAttribute('data-link', '/auth/login');
        loginBtn.textContent = 'Giriş Yap';

        const registerBtn = document.createElement('a');
        registerBtn.href = '/auth/register';
        registerBtn.className = 'btn btn--primary btn--sm';
        registerBtn.setAttribute('data-link', '/auth/register');
        registerBtn.textContent = 'Kaydol';

        container.appendChild(loginBtn);
        container.appendChild(registerBtn);
    }
}

/**
 * Update active link in Navbar based on current path
 */
export function updateActiveLink() {
    const path = window.location.pathname;
    $$('.navbar__link').forEach((link) => {
        const href = link.getAttribute('href');
        if (href === path || (href !== '/' && path.startsWith(href))) {
            link.classList.add('navbar__link--active');
        } else {
            link.classList.remove('navbar__link--active');
        }
    });
}

export default { renderNavbar, updateActiveLink };
