/**
 * AdminSidebar.js — Admin panel sidebar navigation
 * logsearch.xyz
 */

import { $ } from '../utils.js';

const ADMIN_LINKS = [
    { icon: '📊', label: 'Genel Bakış', path: '/admin' },
    { icon: '👥', label: 'Kullanıcılar', path: '/admin/users' },
    { icon: '💰', label: 'Planlar & Fiyat', path: '/admin/plans' },
    { icon: '🔑', label: 'API Anahtarları', path: '/admin/keys' },
    { icon: '📈', label: 'Kullanım Logları', path: '/admin/usage' },
    { icon: '💳', label: 'Ödemeler', path: '/admin/payments' },
    { icon: '🔒', label: 'Giriş Logları', path: '/admin/logins' },
    { icon: '⚙️', label: 'Site Ayarları', path: '/admin/settings' },
];

export function renderAdminSidebar(visible = true) {
    const existing = $('#admin-sidebar');

    if (!visible) {
        if (existing) existing.remove();
        return;
    }

    if (existing) return;

    const sidebar = document.createElement('aside');
    sidebar.id = 'admin-sidebar';
    sidebar.className = 'sidebar sidebar--admin';

    const heading = document.createElement('div');
    heading.className = 'sidebar__heading';
    heading.textContent = 'ADMİN PANEL';

    const nav = document.createElement('nav');
    nav.className = 'sidebar__section';

    ADMIN_LINKS.forEach(({ icon, label, path }) => {
        const a = document.createElement('a');
        a.className = 'sidebar__link';
        a.href = path;
        a.dataset.link = path;
        a.innerHTML = `<span class="sidebar__icon">${icon}</span> ${label}`;
        nav.appendChild(a);
    });

    sidebar.appendChild(heading);
    sidebar.appendChild(nav);

    // Back to dashboard link
    const backSection = document.createElement('div');
    backSection.className = 'sidebar__section';
    backSection.style.marginTop = 'auto';
    backSection.innerHTML = `
        <div class="sidebar__heading">KULLANICI</div>
        <a class="sidebar__link" href="/dashboard" data-link="/dashboard">
            <span class="sidebar__icon">←</span> Dashboard'a Dön
        </a>
    `;
    sidebar.appendChild(backSection);

    const app = $('#app');
    if (app) app.parentNode.insertBefore(sidebar, app);
}

export function updateAdminSidebarActive() {
    const path = window.location.pathname;
    document.querySelectorAll('#admin-sidebar .sidebar__link').forEach((link) => {
        const href = link.getAttribute('href');
        const isActive = path === href || (href !== '/admin' && path.startsWith(href));
        link.classList.toggle('sidebar__link--active', isActive);
    });
}
