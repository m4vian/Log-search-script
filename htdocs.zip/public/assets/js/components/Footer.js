/**
 * Footer.js — Site footer with legal document links
 * logsearch.xyz
 *
 * All legal links open TermsModal via Modal.openTermsModal()
 */

import { $ } from '../utils.js';
import { openTermsModal } from './Modal.js';

/** Legal documents map: slug → display title */
const LEGAL_DOCS = [
    { slug: 'kvkk', title: 'KVKK Aydınlatma Metni' },
    { slug: 'gizlilik', title: 'Gizlilik Politikası' },
    { slug: 'kullanim-kosullari', title: 'Kullanım Koşulları' },
    { slug: 'uyelik-sozlesmesi', title: 'Üyelik Sözleşmesi' },
    { slug: 'mesafeli-satis', title: 'Mesafeli Satış Sözleşmesi' },
    { slug: 'iptal-iade', title: 'İptal & İade Politikası' },
];

/**
 * Render the footer
 */
export function renderFooter() {
    const el = $('#footer-root');
    if (!el) return;

    el.className = 'footer';

    el.innerHTML = `
    <div class="container">
      <div class="footer__grid">
        <!-- Brand Column -->
        <div>
          <div class="footer__brand">logsearch<span>.xyz</span></div>
          <p class="footer__desc">
            API Key ile log arama altyapısı. Hızlı, güvenli ve ölçeklenebilir log sorgulama servisi.
          </p>
        </div>

        <!-- Product Column -->
        <div>
          <h4 class="footer__heading">Ürün</h4>
          <a class="footer__link" href="/docs" data-link="/docs">Dokümantasyon</a>
          <a class="footer__link" href="/pricing" data-link="/pricing">Fiyatlandırma</a>
          <a class="footer__link" href="/status" data-link="/status">Sistem Durumu</a>
        </div>

        <!-- Account Column -->
        <div>
          <h4 class="footer__heading">Hesap</h4>
          <a class="footer__link" href="/auth/login" data-link="/auth/login">Giriş Yap</a>
          <a class="footer__link" href="/auth/register" data-link="/auth/register">Kaydol</a>
          <a class="footer__link" href="/dashboard" data-link="/dashboard">Dashboard</a>
        </div>

        <!-- Legal Column -->
        <div>
          <h4 class="footer__heading">Yasal</h4>
          <div id="footer-legal-links"></div>
        </div>
      </div>

      <!-- Bottom bar -->
      <div class="footer__bottom">
        <span>&copy; ${new Date().getFullYear()} logsearch.xyz — Tüm hakları saklıdır.</span>
        <span>Türkiye</span>
      </div>
    </div>
  `;

    // Render legal links
    const legalContainer = $('#footer-legal-links');
    LEGAL_DOCS.forEach(({ slug, title }) => {
        const link = document.createElement('button');
        link.className = 'footer__link';
        link.textContent = title;
        link.addEventListener('click', () => openTermsModal(slug, title));
        legalContainer.appendChild(link);
    });
}

export default { renderFooter };
