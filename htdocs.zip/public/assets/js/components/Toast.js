/**
 * Toast.js — Toast notification component
 * logsearch.xyz
 *
 * Types: success, error, info, warning
 * Auto-dismiss after configurable duration
 */

import { $ } from '../utils.js';

/** Default toast duration in ms */
const DEFAULT_DURATION = 4000;

/** Icon map for toast types */
const ICONS = {
    success: '✓',
    error: '✕',
    info: 'ℹ',
    warning: '⚠',
};

/**
 * Show a toast notification
 * @param {Object} options
 * @param {string} options.message
 * @param {'success'|'error'|'info'|'warning'} [options.type='info']
 * @param {number} [options.duration=4000]
 */
export function showToast({ message, type = 'info', duration = DEFAULT_DURATION }) {
    const container = $('#toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast--${type}`;
    toast.innerHTML = `
    <span class="toast__icon">${ICONS[type] || ICONS.info}</span>
    <span class="toast__msg">${message}</span>
    <button class="toast__close" aria-label="Kapat">&times;</button>
  `;

    // Close on button click
    toast.querySelector('.toast__close').addEventListener('click', () => {
        dismissToast(toast);
    });

    container.appendChild(toast);

    // Auto dismiss
    if (duration > 0) {
        setTimeout(() => dismissToast(toast), duration);
    }
}

/**
 * Dismiss a toast with animation
 * @param {HTMLElement} toast
 */
function dismissToast(toast) {
    if (!toast || !toast.parentNode) return;

    toast.classList.add('toast--out');
    toast.addEventListener('animationend', () => {
        toast.remove();
    });
}

/* Convenience methods */
export const toastSuccess = (message) => showToast({ message, type: 'success' });
export const toastError = (message) => showToast({ message, type: 'error' });
export const toastInfo = (message) => showToast({ message, type: 'info' });
export const toastWarning = (message) => showToast({ message, type: 'warning' });

export default { showToast, toastSuccess, toastError, toastInfo, toastWarning };
