/**
 * Tabs.js — Tabbed content component
 * logsearch.xyz
 *
 * Usage:
 *   initTabs(containerEl)
 * Expects markup with .tabs__tab[data-tab] buttons and .tabs__panel[data-panel] divs
 */

/**
 * Initialize tabs within a container
 * @param {HTMLElement} container
 */
export function initTabs(container) {
    if (!container) return;

    const tabs = container.querySelectorAll('.tabs__tab');
    const panels = container.querySelectorAll('.tabs__panel');

    tabs.forEach((tab) => {
        tab.addEventListener('click', () => {
            const target = tab.dataset.tab;

            // Deactivate all tabs
            tabs.forEach((t) => t.classList.remove('tabs__tab--active'));
            panels.forEach((p) => p.classList.remove('tabs__panel--active'));

            // Activate selected
            tab.classList.add('tabs__tab--active');

            const targetPanel = container.querySelector(`.tabs__panel[data-panel="${target}"]`);
            if (targetPanel) {
                targetPanel.classList.add('tabs__panel--active');
            }
        });
    });

    // Activate first tab by default
    if (tabs.length > 0) {
        tabs[0].classList.add('tabs__tab--active');
    }
    if (panels.length > 0) {
        panels[0].classList.add('tabs__panel--active');
    }
}

export default { initTabs };
