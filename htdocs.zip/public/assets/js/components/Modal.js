/**
 * Modal.js — Reusable modal component with focus trap & AJAX loading
 * logsearch.xyz
 *
 * Features:
 * - ESC key closes
 * - Overlay click closes
 * - Focus trap (Tab / Shift+Tab)
 * - Body scroll lock
 * - Loading spinner while fetching content
 * - Error state
 */

import { $ } from '../utils.js';

/** Focusable selector list */
const FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';

/** Active modal state */
let activeModal = null;

/**
 * Open a modal
 * @param {Object} options
 * @param {string} options.title — Modal title
 * @param {string} [options.content] — HTML content (if already available)
 * @param {() => Promise<string>} [options.fetchContent] — Async function that returns HTML
 */
export function openModal({ title, content, fetchContent }) {
    // Close any existing modal first
    if (activeModal) closeModal();

    const root = $('#modal-root');

    // Build modal markup
    root.innerHTML = `
    <div class="modal-overlay" id="modal-overlay">
      <div class="modal" role="dialog" aria-modal="true" aria-label="${title}">
        <div class="modal__header">
          <h2 class="modal__title">${title}</h2>
          <button class="modal__close" id="modal-close-btn" aria-label="Kapat">&times;</button>
        </div>
        <div class="modal__body" id="modal-body">
          ${content || `
            <div class="modal__loading">
              <div class="modal__spinner"></div>
              <span>Yükleniyor...</span>
            </div>
          `}
        </div>
      </div>
    </div>
  `;

    // Lock body scroll
    document.body.classList.add('scroll-locked');

    // Store reference
    activeModal = {
        overlay: $('#modal-overlay'),
        closeBtn: $('#modal-close-btn'),
        body: $('#modal-body'),
        previousFocus: document.activeElement,
    };

    // Event listeners
    activeModal.closeBtn.addEventListener('click', closeModal);
    activeModal.overlay.addEventListener('click', onOverlayClick);
    document.addEventListener('keydown', onKeyDown);

    // Focus the close button
    requestAnimationFrame(() => {
        activeModal?.closeBtn?.focus();
    });

    // Fetch content if needed
    if (!content && fetchContent) {
        loadContent(fetchContent);
    }
}

/**
 * Close the active modal
 */
export function closeModal() {
    if (!activeModal) return;

    const root = $('#modal-root');
    root.innerHTML = '';

    // Unlock body scroll
    document.body.classList.remove('scroll-locked');

    // Remove event listeners
    document.removeEventListener('keydown', onKeyDown);

    // Restore focus
    if (activeModal.previousFocus) {
        activeModal.previousFocus.focus();
    }

    activeModal = null;
}

/**
 * Load content via async function
 * @param {() => Promise<string>} fetchContent
 */
async function loadContent(fetchContent) {
    try {
        const html = await fetchContent();
        if (activeModal) {
            activeModal.body.innerHTML = html;
        }
    } catch (err) {
        console.error('[Modal] Failed to load content:', err);
        if (activeModal) {
            activeModal.body.innerHTML = `
        <div class="modal__error">
          <p>İçerik yüklenemedi.</p>
          <p style="margin-top: 0.5rem; font-size: 0.75rem; opacity: 0.7;">${err.message || 'Bilinmeyen hata'}</p>
        </div>
      `;
        }
    }
}

/**
 * Handle overlay click — close only if click is on overlay itself
 * @param {MouseEvent} e
 */
function onOverlayClick(e) {
    if (e.target === activeModal?.overlay) {
        closeModal();
    }
}

/**
 * Handle keydown — ESC to close, Tab for focus trap
 * @param {KeyboardEvent} e
 */
function onKeyDown(e) {
    if (!activeModal) return;

    if (e.key === 'Escape') {
        e.preventDefault();
        closeModal();
        return;
    }

    // Focus trap
    if (e.key === 'Tab') {
        const modal = activeModal.overlay.querySelector('.modal');
        const focusable = modal.querySelectorAll(FOCUSABLE);
        if (focusable.length === 0) return;

        const first = focusable[0];
        const last = focusable[focusable.length - 1];

        if (e.shiftKey) {
            if (document.activeElement === first) {
                e.preventDefault();
                last.focus();
            }
        } else {
            if (document.activeElement === last) {
                e.preventDefault();
                first.focus();
            }
        }
    }
}

/**
 * Open a terms/legal modal — convenience method
 * @param {string} slug — e.g. 'kvkk', 'gizlilik'
 * @param {string} title — Display title
 */
export function openTermsModal(slug, title) {
    openModal({
        title,
        fetchContent: async () => {
            const { fetchLegalDocument } = await import('../api.js');
            return fetchLegalDocument(slug);
        },
    });
}

export default { openModal, closeModal, openTermsModal };
