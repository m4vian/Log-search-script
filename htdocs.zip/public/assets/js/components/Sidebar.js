/**
 * Sidebar.js — Dashboard sidebar navigation
 * logsearch.xyz
 */

import { $ } from '../utils.js';

/** Sidebar navigation items */
const SIDEBAR_ITEMS = [
    { icon: '◉', label: 'Genel Bakış', href: '/dashboard' },
    { icon: '⚿', label: 'API Anahtarları', href: '/dashboard/keys' },
    { icon: '◔', label: 'Kullanım', href: '/dashboard/usage' },
    { icon: '◎', label: 'Dokümantasyon', href: '/docs' },
];

/**
 * Render the sidebar
 * @param {boolean} [visible=true]
 */
export function renderSidebar(visible = true) {
    const existing = $('#dashboard-sidebar');

    if (!visible) {
        if (existing) existing.remove();
        return;
    }

    // Sidebar already exists — don't recreate, just update active state
    if (existing) return;

    const sidebar = document.createElement('aside');
    sidebar.id = 'dashboard-sidebar';
    sidebar.className = 'sidebar';

    const section = document.createElement('nav');
    section.className = 'sidebar__section';

    const heading = document.createElement('div');
    heading.className = 'sidebar__heading';
    heading.textContent = 'Dashboard';
    section.appendChild(heading);

    const currentPath = window.location.pathname;

    SIDEBAR_ITEMS.forEach(({ icon, label, href }) => {
        const link = document.createElement('a');
        link.href = href;
        link.className = 'sidebar__link';
        link.setAttribute('data-link', href);

        if (href === currentPath) {
            link.classList.add('sidebar__link--active');
        }

        link.innerHTML = `
      <span class="sidebar__icon">${icon}</span>
      <span>${label}</span>
    `;

        section.appendChild(link);
    });

    sidebar.appendChild(section);

    // Insert sidebar before #app
    const app = $('#app');
    app.parentNode.insertBefore(sidebar, app);
}

/**
 * Update sidebar active state
 */
export function updateSidebarActive() {
    const path = window.location.pathname;
    const links = document.querySelectorAll('.sidebar__link');
    links.forEach((link) => {
        const href = link.getAttribute('href');
        if (href === path) {
            link.classList.add('sidebar__link--active');
        } else {
            link.classList.remove('sidebar__link--active');
        }
    });
}

export default { renderSidebar, updateSidebarActive };
