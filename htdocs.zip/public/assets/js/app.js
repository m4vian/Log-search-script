/**
 * app.js — Application entry point
 * logsearch.xyz
 *
 * Initializes the router, navbar, footer.
 * Registers all routes and starts the SPA.
 */

import { addRoute, initRouter, setHooks } from './router.js';
import { renderNavbar, updateActiveLink } from './components/Navbar.js';
import { renderFooter } from './components/Footer.js';
import { renderSidebar, updateSidebarActive } from './components/Sidebar.js';
import { renderAdminSidebar, updateAdminSidebarActive } from './components/AdminSidebar.js';
import { verifySession } from './store.js';

/* ---- Route Definitions ---- */

// Public pages
addRoute('/', {
    page: () => import('./pages/Home.js'),
    layout: 'public',
});

addRoute('/status', {
    page: () => import('./pages/Status.js'),
    layout: 'public',
});

addRoute('/docs', {
    page: () => import('./pages/Docs.js'),
    layout: 'public',
});


addRoute('/pricing', {
    page: () => import('./pages/Pricing.js'),
    layout: 'public',
});

addRoute('/search', {
    page: () => import('./pages/Search.js'),
    layout: 'public',
});

// Auth pages
addRoute('/auth/login', {
    page: () => import('./pages/Login.js'),
    layout: 'public',
});

addRoute('/auth/register', {
    page: () => import('./pages/Register.js'),
    layout: 'public',
});

// Dashboard pages (protected)
addRoute('/dashboard', {
    page: () => import('./pages/Dashboard.js'),
    layout: 'dashboard',
    protected: true,
});

addRoute('/dashboard/keys', {
    page: () => import('./pages/Keys.js'),
    layout: 'dashboard',
    protected: true,
});

addRoute('/dashboard/usage', {
    page: () => import('./pages/Usage.js'),
    layout: 'dashboard',
    protected: true,
});

// Admin pages (admin-only — non-admin sees 404)
addRoute('/admin', {
    page: () => import('./pages/admin/AdminDashboard.js'),
    layout: 'admin',
    protected: true,
    adminOnly: true,
});

addRoute('/admin/users', {
    page: () => import('./pages/admin/AdminUsers.js'),
    layout: 'admin',
    protected: true,
    adminOnly: true,
});

addRoute('/admin/plans', {
    page: () => import('./pages/admin/AdminPlans.js'),
    layout: 'admin',
    protected: true,
    adminOnly: true,
});

addRoute('/admin/keys', {
    page: () => import('./pages/admin/AdminKeys.js'),
    layout: 'admin',
    protected: true,
    adminOnly: true,
});

addRoute('/admin/usage', {
    page: () => import('./pages/admin/AdminUsage.js'),
    layout: 'admin',
    protected: true,
    adminOnly: true,
});

addRoute('/admin/payments', {
    page: () => import('./pages/admin/AdminPayments.js'),
    layout: 'admin',
    protected: true,
    adminOnly: true,
});

addRoute('/admin/logins', {
    page: () => import('./pages/admin/AdminLogins.js'),
    layout: 'admin',
    protected: true,
    adminOnly: true,
});

addRoute('/admin/settings', {
    page: () => import('./pages/admin/AdminSettings.js'),
    layout: 'admin',
    protected: true,
    adminOnly: true,
});

// 404
addRoute('/404', {
    page: () => import('./pages/NotFound.js'),
    layout: 'public',
});

/* ---- Lifecycle Hooks ---- */

setHooks({
    /**
     * Before render — handle layout changes (sidebar, footer visibility)
     * @param {Object} config — route config
     * @param {string} path — current path
     */
    beforeRender(config, path) {
        const isDashboard = config.layout === 'dashboard';
        const isAdmin = config.layout === 'admin';

        // Show/hide sidebars
        renderSidebar(isDashboard);
        renderAdminSidebar(isAdmin);

        // Show/hide footer (hide on dashboard and admin)
        const footerEl = document.getElementById('footer-root');
        if (footerEl) {
            footerEl.style.display = (isDashboard || isAdmin) ? 'none' : '';
        }

        // Adjust main content for dashboard/admin layout
        const appEl = document.getElementById('app');
        if (appEl) {
            if (isDashboard || isAdmin) {
                appEl.style.minHeight = `calc(100vh - var(--navbar-height))`;
            } else {
                appEl.style.minHeight = '';
            }
        }
    },

    /**
     * After render — update active states
     */
    afterRender(config, path) {
        updateActiveLink();
        if (config.layout === 'dashboard') {
            updateSidebarActive();
        }
        if (config.layout === 'admin') {
            updateAdminSidebarActive();
        }
    },
});

/* ---- Initialize Application ---- */

document.addEventListener('DOMContentLoaded', async () => {
    // Render persistent components
    renderNavbar();
    renderFooter();

    // Verify session with server before routing
    await verifySession();

    // Start router
    initRouter();

    console.log('[App] logsearch.xyz initialized');
});
