/**
 * api.js — API wrapper for logsearch.xyz
 *
 * All API calls go through /server/api.php?action=xxx
 * Session-based auth (cookies handled by browser automatically)
 */

/** Base URL for API endpoint */
const API_URL = '/server/api.php';

/** Default request timeout in ms */
const DEFAULT_TIMEOUT = 10000;

/**
 * Custom API error
 */
export class ApiError extends Error {
    constructor(message, status = 0, data = null) {
        super(message);
        this.name = 'ApiError';
        this.status = status;
        this.data = data;
    }
}

/**
 * Core fetch wrapper
 * @param {string} url
 * @param {Object} options
 * @returns {Promise<*>}
 */
async function fetchWrapper(url, options = {}) {
    const {
        method = 'GET',
        headers = {},
        body,
        timeout = DEFAULT_TIMEOUT,
        responseType = 'json',
    } = options;

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);

    const fetchOptions = {
        method,
        headers: { ...headers },
        signal: controller.signal,
        credentials: 'same-origin', // send cookies for session
    };

    if (body) {
        if (typeof body === 'object') {
            fetchOptions.headers['Content-Type'] = 'application/json';
            fetchOptions.body = JSON.stringify(body);
        } else {
            fetchOptions.body = body;
        }
    }

    try {
        const response = await fetch(url, fetchOptions);
        clearTimeout(timeoutId);

        if (!response.ok) {
            let errorData = null;
            try {
                errorData = await response.json();
            } catch {
                // not JSON
            }
            throw new ApiError(
                errorData?.message || `HTTP ${response.status}: ${response.statusText}`,
                response.status,
                errorData
            );
        }

        switch (responseType) {
            case 'text':
            case 'html':
                return await response.text();
            case 'json':
            default:
                return await response.json();
        }
    } catch (err) {
        clearTimeout(timeoutId);
        if (err instanceof ApiError) throw err;
        if (err.name === 'AbortError') {
            throw new ApiError('İstek zaman aşımına uğradı.', 408);
        }
        throw new ApiError(err.message || 'Bağlantı hatası oluştu.', 0);
    }
}

// ─── Public API Methods ─────────────────────────

/**
 * General purpose request (legacy compat)
 */
export async function request(url, options = {}) {
    return fetchWrapper(url, options);
}

/**
 * API action call helper
 * @param {string} action — action name
 * @param {Object} options — { method, body, query }
 * @returns {Promise<Object>} response JSON
 */
async function apiCall(action, options = {}) {
    const { method = 'GET', body = null, query = {} } = options;

    const params = new URLSearchParams({ action, ...query });
    const url = `${API_URL}?${params.toString()}`;

    const result = await fetchWrapper(url, { method, body, responseType: 'json' });

    if (result.success === false) {
        throw new ApiError(result.message || 'Bilinmeyen hata', 400, result.data);
    }

    return result;
}

// ─── AUTH ────────────────────────────────────────

export async function apiRegister(name, email, password) {
    return apiCall('register', { method: 'POST', body: { name, email, password } });
}

export async function apiLogin(email, password) {
    return apiCall('login', { method: 'POST', body: { email, password } });
}

export async function apiLogout() {
    return apiCall('logout', { method: 'POST' });
}

export async function apiGetMe() {
    return apiCall('me');
}

// ─── DASHBOARD ──────────────────────────────────

export async function apiGetDashboard() {
    return apiCall('dashboard');
}

// ─── API KEYS ───────────────────────────────────

export async function apiGetKeys() {
    return apiCall('keys');
}

export async function apiCreateKey(name = '') {
    return apiCall('create_key', { method: 'POST', body: { name } });
}

export async function apiRevokeKey(keyId) {
    return apiCall('revoke_key', { method: 'POST', body: { key_id: keyId } });
}

// ─── USAGE ──────────────────────────────────────

export async function apiGetUsage(period = 'today') {
    return apiCall('usage', { query: { period } });
}

// ─── NOTIFICATIONS ──────────────────────────────

export async function apiGetNotifications() {
    return apiCall('notifications');
}

export async function apiMarkNotificationsRead() {
    return apiCall('notifications', { method: 'POST' });
}

// ─── BALANCE ────────────────────────────────────

export async function apiGetBalanceHistory() {
    return apiCall('balance_history');
}

// ─── LEGAL ──────────────────────────────────────

export async function fetchLegalDocument(slug) {
    return fetchWrapper(`/server/legal/${slug}.php`, {
        responseType: 'html',
        timeout: 8000,
    });
}

// ─── ADMIN ──────────────────────────────────────

export async function apiAdminDashboard() {
    return apiCall('admin_dashboard');
}

export async function apiAdminUsers(page = 1, search = '', status = '', role = '') {
    return apiCall('admin_users', { query: { page, search, status, role } });
}

export async function apiAdminUserUpdate(userId, data) {
    return apiCall('admin_user_update', { method: 'POST', body: { user_id: userId, ...data } });
}

export async function apiAdminPlans() {
    return apiCall('admin_plans');
}

export async function apiAdminPlanSave(plan) {
    return apiCall('admin_plan_save', { method: 'POST', body: plan });
}

export async function apiAdminPlanDelete(planId) {
    return apiCall('admin_plan_delete', { method: 'POST', body: { plan_id: planId } });
}

export async function apiAdminKeys(page = 1, search = '') {
    return apiCall('admin_keys', { query: { page, search } });
}

export async function apiAdminKeyRevoke(keyId) {
    return apiCall('admin_key_revoke', { method: 'POST', body: { key_id: keyId } });
}

export async function apiAdminUsage(page = 1) {
    return apiCall('admin_usage', { query: { page } });
}

export async function apiAdminPayments(page = 1) {
    return apiCall('admin_payments', { query: { page } });
}

export async function apiAdminLogins(page = 1) {
    return apiCall('admin_logins', { query: { page } });
}

export async function apiAdminSettings() {
    return apiCall('admin_settings');
}

export async function apiAdminSettingsUpdate(settings) {
    return apiCall('admin_settings_update', { method: 'POST', body: settings });
}

// ─── Public ─────────────────────────────────────────

export async function apiGetConfig() {
    return apiCall('get_config');
}

export async function apiGetPlans() {
    return apiCall('get_plans');
}

// ─── SEARCH ──────────────────────────────────────

/**
 * Perform log search
 * @param {string} q — search query
 * @returns {Promise<Object>} { success: true, results: string[], total: number }
 */
export async function apiSearch(q) {
    return apiCall('search', { query: { q } });
}
