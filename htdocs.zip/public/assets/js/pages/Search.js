/**
 * Search.js — Log search results page
 */

import { apiSearch } from '../api.js';
import { isAuthenticated } from '../store.js';
import { navigate } from '../router.js';

const Search = {
    container: null,

    init(container) {
        this.container = container;
        const urlParams = new URLSearchParams(window.location.search);
        const q = urlParams.get('q') || '';

        if (!isAuthenticated()) {
            this.renderAuthRequired();
            return;
        }

        this.render(q);
        if (q) {
            this.handleSearch(q);
        }
    },


    render(q) {
        this.container.innerHTML = `
      <section class="section">
        <div class="container">
          <div class="section-header text-center">
            <h1 class="hero__title">🔍 Log Arama</h1>
            <p class="hero__subtitle">Tüm loglarımız arasından anlık arama yapın.</p>
          </div>

          <div class="card p-5 mb-8" style="background: var(--color-bg-secondary); border: 1px solid var(--color-accent); box-shadow: var(--shadow-glow);">
              <form id="page-search-form" class="flex gap-4">
                  <input type="text" id="page-search-input" class="form-input" placeholder="Aranacak kelime (örn: site1.com, sonoyuncu)..." value="${esc(q)}" style="height: 50px; font-size: 1.1rem; border-color: var(--color-border-light);">
                  <button type="submit" class="btn btn--primary" style="padding: 0 var(--space-8); height: 50px;">ARA</button>
              </form>
          </div>

          <div id="search-results-content">
            ${q ? '<div class="loading-spinner">Yükleniyor...</div>' : '<div class="empty-state"><div class="empty-state__icon">🔍</div><p class="empty-state__title">Aramaya Başlayın</p><p class="empty-state__desc">Yukarıdaki kutuyu kullanarak arama yapabilirsiniz.</p></div>'}
          </div>
        </div>
      </section>
    `;
        this.bindEvents();
    },

    bindEvents() {
        this.container.querySelector('#page-search-form')?.addEventListener('submit', (e) => {
            e.preventDefault();
            const q = this.container.querySelector('#page-search-input').value.trim();
            if (q) {
                // Update URL without reload if possible, or just navigate
                navigate(`/search?q=${encodeURIComponent(q)}`);
            }
        });
    },

    async handleSearch(q) {
        const content = document.getElementById('search-results-content');
        try {
            const response = await apiSearch(q);
            const data = response.data;
            this.currentResults = data.results || [];

            if (this.currentResults.length === 0) {
                content.innerHTML = `
          <div class="card p-5 text-center">
            <h3>Sonuç Bulunamadı</h3>
            <p class="text-muted">"${esc(q)}" ile eşleşen herhangi bir kayıt bulunamadı.</p>
          </div>
        `;
                return;
            }

            const initialResults = this.currentResults.slice(0, 10);
            const hasMore = this.currentResults.length > 10;

            content.innerHTML = `
        <div class="card p-4 mb-4 flex flex--between">
          <p><strong>${data.total}</strong> sonuç bulundu.</p>
          <button class="btn btn--secondary btn--sm" id="download-btn">📥 İndir (.txt)</button>
        </div>
        <div class="table-wrapper">
          <table class="table">
            <thead>
              <tr>
                <th style="width: 50px;">No</th>
                <th>Kayıt Detayı</th>
              </tr>
            </thead>
            <tbody id="search-tbody">
              ${initialResults.map((line, idx) => `
                <tr>
                  <td class="text-muted">${idx + 1}</td>
                  <td><code>${esc(line)}</code></td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
        ${hasMore ? `
          <div class="text-center mt-6" id="show-more-container">
            <button class="btn btn--secondary" id="show-more-btn">Daha Fazla Göster (${this.currentResults.length - 10} adet)</button>
          </div>
        ` : ''}
      `;

            // Bind results events
            this.container.querySelector('#download-btn')?.addEventListener('click', () => this.handleDownload(q));
            this.container.querySelector('#show-more-btn')?.addEventListener('click', () => {
                const tbody = document.getElementById('search-tbody');
                const rest = this.currentResults.slice(10);
                tbody.insertAdjacentHTML('beforeend', rest.map((line, idx) => `
          <tr>
            <td class="text-muted">${idx + 11}</td>
            <td><code>${esc(line)}</code></td>
          </tr>
        `).join(''));
                document.getElementById('show-more-container').remove();
            });

        } catch (err) {
            content.innerHTML = `
        <div class="card p-5 text-center">
          <h3 class="text-error">Hata</h3>
          <p>${esc(err.message)}</p>
        </div>
      `;
        }
    },

    handleDownload(q) {
        if (!this.currentResults || this.currentResults.length === 0) return;
        const blob = new Blob([this.currentResults.join('\n')], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `logsearch_${q.replace(/[^a-z0-9]/gi, '_')}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    },

    renderAuthRequired() {
        this.container.innerHTML = `
      <section class="section">
        <div class="container text-center">
          <div class="card p-5">
            <h2>Giriş Yapmanız Gerekiyor</h2>
            <p>Loglarda arama yapabilmek için lütfen hesabınıza giriş yapın.</p>
            <div class="mt-4">
              <a href="/auth/login" data-link="/auth/login" class="btn btn--primary">Giriş Yap</a>
              <a href="/auth/register" data-link="/auth/register" class="btn btn--secondary ml-2">Kaydol</a>
            </div>
          </div>
        </div>
      </section>
    `;
    }
};

function esc(s) {
    const d = document.createElement('div');
    d.textContent = s || '';
    return d.innerHTML;
}

export default Search;
