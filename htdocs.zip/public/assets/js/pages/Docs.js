/**
 * Docs.js — API documentation page
 * logsearch.xyz
 *
 * Endpoint list, code tabs (JS/Python/PHP), copy button, rate limits, error codes.
 */

import { initTabs } from '../components/Tabs.js';
import { copyToClipboard } from '../utils.js';
import { toastSuccess, toastError } from '../components/Toast.js'; // Added toastError
import { apiGetPlans } from '../api.js'; // Added apiGetPlans

/** API Endpoints */
const ENDPOINTS = [
  // ... same as before ...
  {
    method: 'GET',
    path: '/api/v1/search',
    desc: 'Log kayıtlarını sorgular. Anahtar kelime, tarih aralığı ve seviye ile filtreleme destekler.',
    params: 'q (string), from (ISO date), to (ISO date), level (info|warn|error), limit (int), offset (int)',
  },
  {
    method: 'GET',
    path: '/api/v1/health',
    desc: 'API sunucusunun sağlık durumunu döndürür.',
    params: '—',
  },
  {
    method: 'POST',
    path: '/api/v1/logs',
    desc: 'Yeni log kaydı gönderir. Body JSON formatında olmalıdır.',
    params: 'message (string), level (string), metadata (object)',
  },
  {
    method: 'GET',
    path: '/api/v1/stats',
    desc: 'Hesabınıza ait kullanım istatistiklerini döndürür.',
    params: 'period (today|week|month)',
  },
];

/** Code examples */
const CODE_EXAMPLES = {
  // ... same as before ...
  javascript: `// JavaScript (Fetch API)
const API_KEY = 'your_api_key_here';
const BASE_URL = 'https://api.logsearch.xyz/v1';

async function searchLogs(query) {
  const response = await fetch(
    \`\${BASE_URL}/search?q=\${encodeURIComponent(query)}\`,
    {
      headers: {
        'Authorization': \`Bearer \${API_KEY}\`,
        'Content-Type': 'application/json'
      }
    }
  );

  if (!response.ok) {
    throw new Error(\`HTTP \${response.status}\`);
  }

  return await response.json();
}

// Kullanım
const results = await searchLogs('error database');
console.log(results.data);`,

  python: `# Python (requests)
import requests

API_KEY = 'your_api_key_here'
BASE_URL = 'https://api.logsearch.xyz/v1'

headers = {
    'Authorization': f'Bearer {API_KEY}',
    'Content-Type': 'application/json'
}

def search_logs(query):
    response = requests.get(
        f'{BASE_URL}/search',
        headers=headers,
        params={'q': query}
    )
    response.raise_for_status()
    return response.json()

# Kullanım
results = search_logs('error database')
print(results['data'])`,

  php: `<?php
// PHP (cURL)
$apiKey = 'your_api_key_here';
$baseUrl = 'https://api.logsearch.xyz/v1';

function searchLogs(string $query): array {
    global $apiKey, $baseUrl;

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $baseUrl . '/search?' . http_build_query(['q' => $query]),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . $apiKey,
            'Content-Type: application/json'
        ],
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200) {
        throw new Exception("HTTP {$httpCode}");
    }

    return json_decode($response, true);
}

// Kullanım
$results = searchLogs('error database');
print_r($results['data']);`,
};

/** Error codes */
const ERROR_CODES = [
  // ... same as before ...
  { code: 200, desc: 'Başarılı', type: 'success' },
  { code: 400, desc: 'Geçersiz istek parametreleri', type: 'warning' },
  { code: 401, desc: 'Geçersiz veya eksik API anahtarı', type: 'error' },
  { code: 403, desc: 'Yetkisiz erişim', type: 'error' },
  { code: 404, desc: 'Kaynak bulunamadı', type: 'warning' },
  { code: 429, desc: 'Rate limit aşıldı', type: 'error' },
  { code: 500, desc: 'Sunucu hatası', type: 'error' },
];

const Docs = {
  /**
   * Initialize and render
   * @param {HTMLElement} container
   */
  async init(container) {
    container.innerHTML = `
      <div class="docs-page">
        <div class="container">
          <!-- Header -->
          <div class="docs-page__header">
            <h1>API Dokümantasyonu</h1>
            <p>logsearch.xyz REST API referansı. Tüm istekler HTTPS üzerinden yapılmalıdır.</p>
          </div>

          <!-- API Key Usage -->
          <section class="docs-section">
            <h2 class="docs-section__title">API Anahtarı Kullanımı</h2>
            <div class="card" style="margin-bottom: var(--space-6);">
              <p style="color: var(--color-text-secondary); font-size: var(--fs-sm); line-height: var(--lh-relaxed);">
                Tüm API isteklerinizde <code style="color: var(--color-accent-text); background: var(--color-accent-muted); padding: 2px 6px; border-radius: 4px;">Authorization</code> 
                header'ı ile API anahtarınızı göndermeniz gerekmektedir.
              </p>
              <div class="code-block" style="margin-top: var(--space-4);">
                <div class="code-block__header">
                  <span>Header</span>
                </div>
                <pre><code>Authorization: Bearer YOUR_API_KEY</code></pre>
              </div>
              <p style="margin-top: var(--space-4); font-size: var(--fs-sm); color: var(--color-text-muted);">
                API anahtarınızı <a href="/dashboard/keys" data-link="/dashboard/keys">Dashboard → API Anahtarları</a> sayfasından oluşturabilirsiniz.
              </p>
            </div>
          </section>

          <!-- Endpoints -->
          <section class="docs-section">
            <h2 class="docs-section__title">Endpoints</h2>
            <div id="endpoints-list"></div>
          </section>

          <!-- Code Examples -->
          <section class="docs-section">
            <h2 class="docs-section__title">Kod Örnekleri</h2>
            <div id="code-tabs-container">
              <div class="tabs" role="tablist">
                <button class="tabs__tab" data-tab="javascript" role="tab">JavaScript</button>
                <button class="tabs__tab" data-tab="python" role="tab">Python</button>
                <button class="tabs__tab" data-tab="php" role="tab">PHP</button>
              </div>
              <div class="tabs__panel" data-panel="javascript">
                <div class="code-block">
                  <div class="code-block__header">
                    <span>search.js</span>
                    <button class="code-block__copy" data-copy="javascript">Kopyala</button>
                  </div>
                  <pre><code>${escapeCode(CODE_EXAMPLES.javascript)}</code></pre>
                </div>
              </div>
              <div class="tabs__panel" data-panel="python">
                <div class="code-block">
                  <div class="code-block__header">
                    <span>search.py</span>
                    <button class="code-block__copy" data-copy="python">Kopyala</button>
                  </div>
                  <pre><code>${escapeCode(CODE_EXAMPLES.python)}</code></pre>
                </div>
              </div>
              <div class="tabs__panel" data-panel="php">
                <div class="code-block">
                  <div class="code-block__header">
                    <span>search.php</span>
                    <button class="code-block__copy" data-copy="php">Kopyala</button>
                  </div>
                  <pre><code>${escapeCode(CODE_EXAMPLES.php)}</code></pre>
                </div>
              </div>
            </div>
          </section>

          <!-- Rate Limiting -->
          <section class="docs-section">
            <h2 class="docs-section__title">Rate Limiting</h2>
            <div class="card">
              <p style="color: var(--color-text-secondary); font-size: var(--fs-sm); line-height: var(--lh-relaxed); margin-bottom: var(--space-4);">
                API istekleriniz plan türünüze göre rate-limit ile sınırlandırılmıştır. Limit aşıldığında <code style="color: var(--color-error); background: var(--color-error-muted); padding: 2px 6px; border-radius: 4px;">429 Too Many Requests</code> yanıtı alırsınız.
              </p>
              <div class="table-wrapper">
                <table class="table">
                  <thead>
                    <tr>
                      <th>Plan</th>
                      <th>İstek / Dakika</th>
                      <th>İstek / Gün</th>
                    </tr>
                  </thead>
                  <tbody id="rate-limits-body">
                    <tr><td colspan="3" class="text-center text-muted">Yükleniyor...</td></tr>
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          <!-- Error Codes -->
          <section class="docs-section">
            <h2 class="docs-section__title">Hata Kodları</h2>
            <div class="table-wrapper">
              <table class="table">
                <thead>
                  <tr>
                    <th>Kod</th>
                    <th>Açıklama</th>
                    <th>Tür</th>
                  </tr>
                </thead>
                <tbody>
                  ${ERROR_CODES.map((e) => `
                    <tr>
                      <td><strong>${e.code}</strong></td>
                      <td>${e.desc}</td>
                      <td><span class="badge badge--${e.type}">${e.type === 'success' ? 'Başarı' : e.type === 'warning' ? 'Uyarı' : 'Hata'}</span></td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          </section>
        </div>
      </div>
    `;

    // Render endpoints
    const endpointsList = container.querySelector('#endpoints-list');
    ENDPOINTS.forEach(({ method, path, desc, params }) => {
      const card = document.createElement('div');
      card.className = 'endpoint-card';
      card.innerHTML = `
        <div>
          <span class="endpoint-card__method endpoint-card__method--${method.toLowerCase()}">${method}</span>
          <span class="endpoint-card__path">${path}</span>
        </div>
        <p class="endpoint-card__desc">${desc}</p>
        ${params !== '—' ? `<p style="margin-top: var(--space-2); font-size: var(--fs-xs); color: var(--color-text-muted);">Parametreler: ${params}</p>` : ''}
      `;
      endpointsList.appendChild(card);
    });

    // Init code tabs
    const tabsContainer = container.querySelector('#code-tabs-container');
    initTabs(tabsContainer);

    // Copy buttons
    container.querySelectorAll('[data-copy]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const lang = btn.dataset.copy;
        const code = CODE_EXAMPLES[lang];
        if (code) {
          const success = await copyToClipboard(code);
          if (success) {
            btn.textContent = 'Kopyalandı!';
            toastSuccess('Kod panoya kopyalandı.');
            setTimeout(() => { btn.textContent = 'Kopyala'; }, 2000);
          }
        }
      });
    });

    // Fetch and Render Rate Limits
    try {
      const result = await apiGetPlans();
      const plans = result.data.plans || [];
      const tbody = container.querySelector('#rate-limits-body');
      tbody.innerHTML = plans.map(p => `
                <tr>
                    <td><strong>${p.name}</strong></td>
                    <td>${p.requests_per_min}</td>
                    <td>${parseInt(p.requests_per_day).toLocaleString('tr-TR')}</td>
                </tr>
            `).join('');
    } catch (err) {
      // Keep default/loading or show error
      container.querySelector('#rate-limits-body').innerHTML = '<tr><td colspan="3" class="text-center text-muted">Limit bilgileri yüklenemedi.</td></tr>';
    }
  },
};

/**
 * Basic HTML escape for code display
 * @param {string} str
 * @returns {string}
 */
function escapeCode(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

export default Docs;
