/**
 * Login.js — Login page
 * logsearch.xyz
 *
 * Real API authentication via /server/api.php
 */

import { login } from '../store.js';
import { apiLogin } from '../api.js';
import { navigate } from '../router.js';
import { toastSuccess, toastError } from '../components/Toast.js';

const Login = {
  init(container) {
    container.innerHTML = `
      <div class="auth-page">
        <div class="auth-card">
          <div class="auth-card__header">
            <div class="auth-card__logo">
              <span class="auth-card__logo-icon">⚡</span>
            </div>
            <h1>Giriş Yap</h1>
            <p>Hesabınıza giriş yaparak API anahtarlarınızı yönetin.</p>
          </div>

          <form class="auth-card__form" id="login-form" novalidate>
            <div class="form-group">
              <label class="form-label" for="login-email">E-posta</label>
              <input
                type="email"
                id="login-email"
                class="form-input"
                placeholder="ornek@email.com"
                required
                autocomplete="email"
              />
            </div>

            <div class="form-group">
              <label class="form-label" for="login-password">Şifre</label>
              <input
                type="password"
                id="login-password"
                class="form-input"
                placeholder="••••••••"
                required
                autocomplete="current-password"
              />
            </div>

            <button type="submit" class="btn btn--primary btn--full btn--lg auth-submit-btn" id="login-submit">
              <span class="auth-submit-btn__text">Giriş Yap</span>
              <span class="auth-submit-btn__arrow">→</span>
            </button>
          </form>

          <div class="auth-card__footer">
            Hesabınız yok mu? <a href="/auth/register" data-link="/auth/register">Kaydol</a>
          </div>
        </div>
      </div>
    `;

    const form = container.querySelector('#login-form');
    const submitBtn = container.querySelector('#login-submit');

    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      const email = container.querySelector('#login-email').value.trim();
      const password = container.querySelector('#login-password').value;

      if (!email || !password) {
        toastError('Lütfen tüm alanları doldurun.');
        return;
      }

      if (!email.includes('@')) {
        toastError('Geçerli bir e-posta adresi girin.');
        return;
      }

      // Disable button while loading
      submitBtn.disabled = true;
      submitBtn.querySelector('.auth-submit-btn__text').textContent = 'Giriş yapılıyor...';

      try {
        const result = await apiLogin(email, password);

        // Set local state from API response
        login(result.data.user);

        toastSuccess(result.message || 'Başarıyla giriş yapıldı!');
        navigate('/dashboard');
      } catch (err) {
        toastError(err.message || 'Giriş başarısız.');
      } finally {
        submitBtn.disabled = false;
        submitBtn.querySelector('.auth-submit-btn__text').textContent = 'Giriş Yap';
      }
    });
  },
};

export default Login;
