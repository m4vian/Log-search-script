/**
 * AdminUsage.js — API usage logs
 * logsearch.xyz
 */

import { apiAdminUsage } from '../../api.js';
import { toastError } from '../../components/Toast.js';

const AdminUsage = {
    container: null, currentPage: 1,

    init(container) {
        this.container = container;
        this.load();
    },

    async load() {
        try {
            const r = await apiAdminUsage(this.currentPage);
            this.render(r.data);
        } catch (err) { toastError('Loglar yüklenemedi: ' + err.message); }
    },

    render(data) {
        const { logs, total, page, total_pages } = data;
        const methodColors = { GET: 'info', POST: 'success', PUT: 'warning', DELETE: 'error', PATCH: 'warning' };

        this.container.innerHTML = `
      <div class="dashboard-layout"><div class="dashboard-content">
        <div class="dashboard-content__header"><h1>📈 Kullanım Logları</h1><p>Toplam ${total.toLocaleString('tr-TR')} istek</p></div>
        ${logs.length ? `
        <div class="table-wrapper"><table class="table">
          <thead><tr><th>Kullanıcı</th><th>Method</th><th>Endpoint</th><th>Durum</th><th>Süre</th><th>IP</th><th>Tarih</th></tr></thead>
          <tbody>${logs.map(l => `
            <tr>
              <td>${esc(l.user_name || '—')}<br><span class="text-muted" style="font-size:var(--fs-xs);">${esc(l.user_email || '')}</span></td>
              <td><span class="badge badge--${methodColors[l.method] || 'info'}">${l.method}</span></td>
              <td style="font-family:var(--font-mono);font-size:var(--fs-xs);">${esc(l.endpoint)}</td>
              <td><span class="badge badge--${parseInt(l.status_code) < 400 ? 'success' : 'error'}">${l.status_code}</span></td>
              <td>${l.response_time_ms}ms</td>
              <td class="text-muted" style="font-family:var(--font-mono);font-size:var(--fs-xs);">${esc(l.request_ip || '—')}</td>
              <td class="text-muted" style="font-size:var(--fs-xs);">${fmtDate(l.created_at)}</td>
            </tr>`).join('')}
          </tbody>
        </table></div>
        ${total_pages > 1 ? `<div class="admin-pagination">${pgHTML(page, total_pages)}</div>` : ''}
        ` : '<div class="empty-state"><div class="empty-state__icon">📈</div><p class="empty-state__title">Log bulunamadı</p></div>'}
      </div></div>`;

        this.container.querySelectorAll('.page-btn').forEach(b => b.addEventListener('click', () => { this.currentPage = parseInt(b.dataset.page); this.load(); }));
    },
};

function esc(s) { const d = document.createElement('div'); d.textContent = s || ''; return d.innerHTML; }
function fmtDate(s) { try { return new Date(s).toLocaleString('tr-TR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }); } catch { return s || '—'; } }
function pgHTML(c, t) { let h = ''; for (let i = 1; i <= t; i++)h += `<button class="btn btn--sm ${i === c ? 'btn--primary' : 'btn--secondary'} page-btn" data-page="${i}">${i}</button> `; return h; }

export default AdminUsage;
