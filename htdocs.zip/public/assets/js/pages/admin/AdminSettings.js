/**
 * AdminSettings.js — Site settings management
 * logsearch.xyz
 */

import { apiAdminSettings, apiAdminSettingsUpdate } from '../../api.js';
import { toastSuccess, toastError } from '../../components/Toast.js';

const AdminSettings = {
    container: null,
    settings: [],

    init(container) {
        this.container = container;
        this.load();
    },

    async load() {
        try {
            const r = await apiAdminSettings();
            this.settings = r.data.settings || [];
            this.render();
        } catch (err) { toastError('Ayarlar yüklenemedi: ' + err.message); }
    },

    render() {
        this.container.innerHTML = `
      <div class="dashboard-layout"><div class="dashboard-content">
        <div class="dashboard-content__header"><h1>⚙️ Site Ayarları</h1><p>Genel sistem ayarlarını yapılandırın.</p></div>
        <div class="card" style="padding:var(--space-6);">
          <div class="admin-settings-form">
            ${this.settings.map(s => `
              <div class="form-group admin-setting-row">
                <div>
                  <label class="form-label">${esc(s.key)}</label>
                  ${s.description ? `<p class="text-muted" style="font-size:var(--fs-xs);margin-top:2px;">${esc(s.description)}</p>` : ''}
                </div>
                <div>
                  ${s.type === 'bool'
                ? `<label class="admin-toggle"><input type="checkbox" data-key="${esc(s.key)}" ${s.value === '1' || s.value === 'true' ? 'checked' : ''}><span class="admin-toggle__slider"></span></label>`
                : s.type === 'int'
                    ? `<input type="number" class="form-input" data-key="${esc(s.key)}" value="${esc(s.value || '0')}" style="max-width:160px;">`
                    : s.type === 'json'
                        ? `<textarea class="form-input" data-key="${esc(s.key)}" rows="3" style="font-family:var(--font-mono);font-size:var(--fs-xs);resize:vertical;">${esc(s.value || '{}')}</textarea>`
                        : `<input type="text" class="form-input" data-key="${esc(s.key)}" value="${esc(s.value || '')}">`
            }
                </div>
              </div>
            `).join('')}
          </div>
          <button class="btn btn--primary" id="save-settings-btn" style="margin-top:var(--space-6);">💾 Ayarları Kaydet</button>
        </div>
      </div></div>`;

        this.container.querySelector('#save-settings-btn')?.addEventListener('click', async () => {
            const btn = this.container.querySelector('#save-settings-btn');
            btn.disabled = true; btn.textContent = 'Kaydediliyor...';

            const settings = {};
            this.container.querySelectorAll('[data-key]').forEach(el => {
                const key = el.dataset.key;
                if (el.type === 'checkbox') {
                    settings[key] = el.checked ? '1' : '0';
                } else {
                    settings[key] = el.value;
                }
            });

            try {
                await apiAdminSettingsUpdate(settings);
                toastSuccess('Ayarlar başarıyla kaydedildi.');
                btn.disabled = false; btn.textContent = '💾 Ayarları Kaydet';
            } catch (err) {
                toastError(err.message);
                btn.disabled = false; btn.textContent = '💾 Ayarları Kaydet';
            }
        });
    },
};

function esc(s) { const d = document.createElement('div'); d.textContent = s || ''; return d.innerHTML; }

export default AdminSettings;
