/**
 * AdminKeys.js — All API keys management
 * logsearch.xyz
 */

import { apiAdminKeys, apiAdminKeyRevoke } from '../../api.js';
import { toastSuccess, toastError } from '../../components/Toast.js';

const AdminKeys = {
    container: null, currentPage: 1, search: '',

    init(container) {
        this.container = container;
        this.renderLoading();
        this.load();
    },

    renderLoading() {
        this.container.innerHTML = `<div class="dashboard-layout"><div class="dashboard-content">
      <div class="dashboard-content__header"><h1>🔑 API Anahtarları</h1><p>Tüm kullanıcıların API anahtarlarını yönetin.</p></div>
      <div class="skeleton skeleton--text" style="height:400px;border-radius:var(--radius-md);"></div>
    </div></div>`;
    },

    async load() {
        try {
            const r = await apiAdminKeys(this.currentPage, this.search);
            this.render(r.data);
        } catch (err) { toastError('Anahtarlar yüklenemedi: ' + err.message); }
    },

    render(data) {
        const { keys, total, page, total_pages } = data;
        this.container.innerHTML = `
      <div class="dashboard-layout"><div class="dashboard-content">
        <div class="dashboard-content__header"><h1>🔑 API Anahtarları</h1><p>Toplam ${total} anahtar</p></div>
        <div class="admin-filters">
          <input type="text" class="form-input" placeholder="Kullanıcı veya prefix ara..." id="admin-key-search" value="${esc(this.search)}" style="max-width:280px;">
        </div>
        ${keys.length ? `
        <div class="table-wrapper"><table class="table">
          <thead><tr><th>Kullanıcı</th><th>Prefix</th><th>Ad</th><th>Durum</th><th>Son Kullanım</th><th>Oluşturma</th><th>İşlem</th></tr></thead>
          <tbody>${keys.map(k => `
            <tr>
              <td><strong>${esc(k.user_name)}</strong><br><span class="text-muted" style="font-size:var(--fs-xs);">${esc(k.user_email)}</span></td>
              <td><code style="font-size:var(--fs-xs);">${esc(k.prefix)}...</code></td>
              <td>${esc(k.name)}</td>
              <td><span class="badge badge--${k.status === 'active' ? 'success' : 'error'}">${k.status}</span></td>
              <td class="text-muted" style="font-size:var(--fs-xs);">${k.last_used_at ? fmtDate(k.last_used_at) : '—'}</td>
              <td class="text-muted" style="font-size:var(--fs-xs);">${fmtDate(k.created_at)}</td>
              <td>${k.status === 'active' ? `<button class="btn btn--sm btn--danger revoke-key-btn" data-id="${k.id}">İptal Et</button>` : `<span class="text-muted">${fmtDate(k.revoked_at)}</span>`}</td>
            </tr>`).join('')}
          </tbody>
        </table></div>
        ${total_pages > 1 ? `<div class="admin-pagination">${pgHTML(page, total_pages)}</div>` : ''}
        ` : '<div class="empty-state"><div class="empty-state__icon">🔑</div><p class="empty-state__title">Anahtar bulunamadı</p></div>'}
      </div></div>`;

        let timer;
        this.container.querySelector('#admin-key-search')?.addEventListener('input', (e) => {
            clearTimeout(timer); timer = setTimeout(() => { this.search = e.target.value; this.currentPage = 1; this.load(); }, 400);
        });
        this.container.querySelectorAll('.page-btn').forEach(b => b.addEventListener('click', () => { this.currentPage = parseInt(b.dataset.page); this.load(); }));
        this.container.querySelectorAll('.revoke-key-btn').forEach(b => b.addEventListener('click', async () => {
            if (!confirm('Bu anahtarı iptal etmek istediğinize emin misiniz?')) return;
            try { await apiAdminKeyRevoke(b.dataset.id); toastSuccess('Anahtar iptal edildi.'); this.load(); } catch (err) { toastError(err.message); }
        }));
    },
};

function esc(s) { const d = document.createElement('div'); d.textContent = s || ''; return d.innerHTML; }
function fmtDate(s) { try { return new Date(s).toLocaleString('tr-TR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }); } catch { return s || '—'; } }
function pgHTML(c, t) { let h = ''; for (let i = 1; i <= t; i++)h += `<button class="btn btn--sm ${i === c ? 'btn--primary' : 'btn--secondary'} page-btn" data-page="${i}">${i}</button> `; return h; }

export default AdminKeys;
