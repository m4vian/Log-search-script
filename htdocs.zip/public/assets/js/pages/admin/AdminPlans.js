/**
 * AdminPlans.js — Plan & pricing management
 * logsearch.xyz
 */

import { apiAdminPlans, apiAdminPlanSave, apiAdminPlanDelete } from '../../api.js';
import { toastSuccess, toastError } from '../../components/Toast.js';
import { openModal, closeModal } from '../../components/Modal.js';

const AdminPlans = {
  container: null,
  plans: [],

  init(container) {
    this.container = container;
    this.renderLoading();
    this.loadPlans();
  },

  renderLoading() {
    this.container.innerHTML = `
      <div class="dashboard-layout"><div class="dashboard-content">
        <div class="dashboard-content__header"><h1>💰 Plan & Fiyat Yönetimi</h1><p>API planlarını oluşturun, düzenleyin veya silin.</p></div>
        <div class="skeleton skeleton--text" style="height:300px;border-radius:var(--radius-md);"></div>
      </div></div>`;
  },

  async loadPlans() {
    try {
      const r = await apiAdminPlans();
      this.plans = r.data.plans || [];
      this.render();
    } catch (err) {
      toastError('Planlar yüklenemedi: ' + err.message);
    }
  },

  render() {
    this.container.innerHTML = `
      <div class="dashboard-layout"><div class="dashboard-content">
        <div class="dashboard-content__header">
          <h1>💰 Plan & Fiyat Yönetimi</h1>
          <p>${this.plans.length} plan tanımlı</p>
        </div>

        <div style="margin-bottom:var(--space-6);">
          <button class="btn btn--primary" id="add-plan-btn">+ Yeni Plan Ekle</button>
        </div>

        <div class="table-wrapper">
          <table class="table">
            <thead><tr>
              <th>Sıra</th><th>Ad</th><th>Slug</th><th>Fiyat</th><th>Dönem</th>
              <th>İstek/Gün</th><th>İstek/Dk</th><th>Maks Key</th><th>Saklama</th>
              <th>Durum</th><th>Kullanıcı</th><th>İşlem</th>
            </tr></thead>
            <tbody>
              ${this.plans.map(p => `
                <tr>
                  <td>${p.sort_order}</td>
                  <td><strong>${esc(p.name)}</strong></td>
                  <td><code style="font-size:var(--fs-xs);">${esc(p.slug)}</code></td>
                  <td>₺${parseFloat(p.price).toLocaleString('tr-TR')}</td>
                  <td>${p.billing_period}</td>
                  <td>${parseInt(p.requests_per_day).toLocaleString('tr-TR')}</td>
                  <td>${p.requests_per_min}</td>
                  <td>${p.max_keys}</td>
                  <td>${p.log_retention_days} gün</td>
                  <td><span class="badge badge--${p.is_active === '1' || p.is_active === 1 ? 'success' : 'error'}">${p.is_active === '1' || p.is_active === 1 ? 'Aktif' : 'Pasif'}</span></td>
                  <td>${p.user_count || 0}</td>
                  <td style="white-space:nowrap;">
                    <button class="btn btn--sm btn--secondary edit-plan-btn" data-id="${p.id}">Düzenle</button>
                    <button class="btn btn--sm btn--danger delete-plan-btn" data-id="${p.id}" data-users="${p.user_count || 0}">Sil</button>
                  </td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div></div>`;

    this.container.querySelector('#add-plan-btn')?.addEventListener('click', () => this.openPlanModal());
    this.container.querySelectorAll('.edit-plan-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const plan = this.plans.find(p => String(p.id) === btn.dataset.id);
        if (plan) this.openPlanModal(plan);
      });
    });
    this.container.querySelectorAll('.delete-plan-btn').forEach(btn => {
      btn.addEventListener('click', () => this.deletePlan(btn.dataset.id, btn.dataset.users));
    });
  },

  openPlanModal(plan = null) {
    const isEdit = !!plan;
    let features = '';
    if (plan?.features) {
      try { features = JSON.parse(plan.features).join('\n'); } catch { features = plan.features; }
    }

    const contentHTML = `
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:var(--space-4);">
        <div class="form-group"><label class="form-label">Plan Adı *</label><input class="form-input" id="p-name" value="${esc(plan?.name || '')}"></div>
        <div class="form-group"><label class="form-label">Slug *</label><input class="form-input" id="p-slug" value="${esc(plan?.slug || '')}"></div>
        <div class="form-group"><label class="form-label">Fiyat (₺)</label><input type="number" class="form-input" id="p-price" value="${plan?.price || 0}" step="0.01"></div>
        <div class="form-group"><label class="form-label">Para Birimi</label><input class="form-input" id="p-currency" value="${plan?.currency || 'TRY'}"></div>
        <div class="form-group"><label class="form-label">Dönem</label>
          <select class="form-input" id="p-billing">
            <option value="monthly" ${plan?.billing_period === 'monthly' ? 'selected' : ''}>Aylık</option>
            <option value="yearly" ${plan?.billing_period === 'yearly' ? 'selected' : ''}>Yıllık</option>
            <option value="lifetime" ${plan?.billing_period === 'lifetime' ? 'selected' : ''}>Ömür Boyu</option>
          </select>
        </div>
        <div class="form-group"><label class="form-label">Sıra</label><input type="number" class="form-input" id="p-sort" value="${plan?.sort_order || 0}"></div>
        <div class="form-group"><label class="form-label">İstek / Gün</label><input type="number" class="form-input" id="p-rpd" value="${plan?.requests_per_day || 1000}"></div>
        <div class="form-group"><label class="form-label">İstek / Dakika</label><input type="number" class="form-input" id="p-rpm" value="${plan?.requests_per_min || 30}"></div>
        <div class="form-group"><label class="form-label">Maks API Anahtarı</label><input type="number" class="form-input" id="p-keys" value="${plan?.max_keys || 1}"></div>
        <div class="form-group"><label class="form-label">Log Saklama (gün)</label><input type="number" class="form-input" id="p-ret" value="${plan?.log_retention_days || 7}"></div>
      </div>
      <div class="form-group" style="margin-top:var(--space-4);"><label class="form-label">Özellikler (her satıra bir tane)</label>
        <textarea class="form-input" id="p-features" rows="4" style="resize:vertical;">${features}</textarea>
      </div>
      <div class="form-group" style="margin-top:var(--space-3);">
        <label style="display:flex;align-items:center;gap:var(--space-2);cursor:pointer;">
          <input type="checkbox" id="p-active" ${(!plan || plan.is_active === '1' || plan.is_active === 1) ? 'checked' : ''}>
          <span class="form-label" style="margin:0;">Aktif</span>
        </label>
      </div>
      <button class="btn btn--primary btn--full" id="save-plan-btn" style="margin-top:var(--space-4);">Kaydet</button>`;

    openModal({ title: isEdit ? 'Plan Düzenle' : 'Yeni Plan Oluştur', content: contentHTML });

    const modalBody = document.querySelector('#modal-body');
    modalBody.querySelector('#save-plan-btn').addEventListener('click', async () => {
      const btn = modalBody.querySelector('#save-plan-btn');
      btn.disabled = true; btn.textContent = 'Kaydediliyor...';
      const featuresArr = modalBody.querySelector('#p-features').value.split('\n').map(s => s.trim()).filter(Boolean);
      try {
        await apiAdminPlanSave({
          id: plan?.id || 0,
          name: modalBody.querySelector('#p-name').value,
          slug: modalBody.querySelector('#p-slug').value,
          price: parseFloat(modalBody.querySelector('#p-price').value),
          currency: modalBody.querySelector('#p-currency').value,
          billing_period: modalBody.querySelector('#p-billing').value,
          requests_per_day: parseInt(modalBody.querySelector('#p-rpd').value),
          requests_per_min: parseInt(modalBody.querySelector('#p-rpm').value),
          max_keys: parseInt(modalBody.querySelector('#p-keys').value),
          log_retention_days: parseInt(modalBody.querySelector('#p-ret').value),
          features: featuresArr,
          sort_order: parseInt(modalBody.querySelector('#p-sort').value),
          is_active: modalBody.querySelector('#p-active').checked ? 1 : 0,
        });
        toastSuccess(isEdit ? 'Plan güncellendi.' : 'Plan oluşturuldu.');
        closeModal();
        this.loadPlans();
      } catch (err) {
        toastError(err.message);
        btn.disabled = false; btn.textContent = 'Kaydet';
      }
    });
  },

  async deletePlan(planId, userCount) {
    if (parseInt(userCount) > 0) {
      toastError('Bu planda aktif kullanıcılar var. Önce kullanıcıları başka plana taşıyın.');
      return;
    }
    if (!confirm('Bu planı silmek istediğinize emin misiniz?')) return;
    try {
      await apiAdminPlanDelete(planId);
      toastSuccess('Plan silindi.');
      this.loadPlans();
    } catch (err) {
      toastError(err.message);
    }
  },
};

function esc(s) { const d = document.createElement('div'); d.textContent = s || ''; return d.innerHTML; }

export default AdminPlans;
