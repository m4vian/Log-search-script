/**
 * AdminPayments.js — Payment history
 * logsearch.xyz
 */

import { apiAdminPayments } from '../../api.js';
import { toastError } from '../../components/Toast.js';

const AdminPayments = {
    container: null, currentPage: 1,

    init(container) {
        this.container = container;
        this.load();
    },

    async load() {
        try {
            const r = await apiAdminPayments(this.currentPage);
            this.render(r.data);
        } catch (err) { toastError('Ödemeler yüklenemedi: ' + err.message); }
    },

    render(data) {
        const { payments, total, page, total_pages } = data;
        const typeLabels = { subscription: 'Abonelik', topup: 'Yükleme', refund: 'İade' };
        const statusColors = { pending: 'warning', completed: 'success', failed: 'error', refunded: 'info' };

        this.container.innerHTML = `
      <div class="dashboard-layout"><div class="dashboard-content">
        <div class="dashboard-content__header"><h1>💳 Ödeme Geçmişi</h1><p>Toplam ${total} ödeme kaydı</p></div>
        ${payments.length ? `
        <div class="table-wrapper"><table class="table">
          <thead><tr><th>Kullanıcı</th><th>Tutar</th><th>Tür</th><th>Durum</th><th>Yöntem</th><th>İşlem ID</th><th>Tarih</th></tr></thead>
          <tbody>${payments.map(p => `
            <tr>
              <td><strong>${esc(p.user_name)}</strong><br><span class="text-muted" style="font-size:var(--fs-xs);">${esc(p.user_email)}</span></td>
              <td style="font-weight:600;">₺${parseFloat(p.amount).toLocaleString('tr-TR')}</td>
              <td>${typeLabels[p.type] || p.type}</td>
              <td><span class="badge badge--${statusColors[p.status] || 'info'}">${p.status}</span></td>
              <td class="text-muted">${esc(p.payment_method || '—')}</td>
              <td style="font-family:var(--font-mono);font-size:var(--fs-xs);">${esc(p.transaction_id || '—')}</td>
              <td class="text-muted" style="font-size:var(--fs-xs);">${fmtDate(p.created_at)}</td>
            </tr>`).join('')}
          </tbody>
        </table></div>
        ${total_pages > 1 ? `<div class="admin-pagination">${pgHTML(page, total_pages)}</div>` : ''}
        ` : '<div class="empty-state"><div class="empty-state__icon">💳</div><p class="empty-state__title">Ödeme kaydı bulunamadı</p></div>'}
      </div></div>`;

        this.container.querySelectorAll('.page-btn').forEach(b => b.addEventListener('click', () => { this.currentPage = parseInt(b.dataset.page); this.load(); }));
    },
};

function esc(s) { const d = document.createElement('div'); d.textContent = s || ''; return d.innerHTML; }
function fmtDate(s) { try { return new Date(s).toLocaleString('tr-TR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }); } catch { return s || '—'; } }
function pgHTML(c, t) { let h = ''; for (let i = 1; i <= t; i++)h += `<button class="btn btn--sm ${i === c ? 'btn--primary' : 'btn--secondary'} page-btn" data-page="${i}">${i}</button> `; return h; }

export default AdminPayments;
