/**
 * AdminDashboard.js — Admin panel overview
 * logsearch.xyz
 */

import { apiAdminDashboard } from '../../api.js';
import { toastError } from '../../components/Toast.js';

const AdminDashboard = {
    init(container) {
        this.container = container;
        this.renderLoading();
        this.loadData();
    },

    renderLoading() {
        this.container.innerHTML = `
      <div class="dashboard-layout">
        <div class="dashboard-content">
          <div class="dashboard-content__header">
            <h1>🛡️ Admin Panel</h1>
            <p>Genel sistem istatistikleri ve son aktiviteler.</p>
          </div>
          <div class="stats-grid">
            ${Array(6).fill('<div class="stat-card"><div class="skeleton skeleton--text" style="height:48px;"></div></div>').join('')}
          </div>
        </div>
      </div>
    `;
    },

    async loadData() {
        try {
            const result = await apiAdminDashboard();
            this.render(result.data);
        } catch (err) {
            toastError('Admin verileri yüklenemedi: ' + err.message);
        }
    },

    render(data) {
        const { stats, recent_logins, top_users } = data;

        this.container.innerHTML = `
      <div class="dashboard-layout">
        <div class="dashboard-content">
          <div class="dashboard-content__header">
            <h1>🛡️ Admin Panel</h1>
            <p>Genel sistem istatistikleri ve son aktiviteler.</p>
          </div>

          <div class="stats-grid">
            <div class="stat-card">
              <div class="stat-card__label">Toplam Kullanıcı</div>
              <div class="stat-card__value">${stats.total_users}</div>
              <div class="stat-card__change">${stats.active_users} aktif · ${stats.suspended_users} askıda</div>
            </div>
            <div class="stat-card">
              <div class="stat-card__label">Toplam Gelir</div>
              <div class="stat-card__value">₺${stats.total_revenue.toLocaleString('tr-TR')}</div>
              <div class="stat-card__change">Bu ay: ₺${stats.month_revenue.toLocaleString('tr-TR')}</div>
            </div>
            <div class="stat-card">
              <div class="stat-card__label">Toplam İstek</div>
              <div class="stat-card__value">${stats.total_requests.toLocaleString('tr-TR')}</div>
              <div class="stat-card__change">Bugün: ${stats.today_requests.toLocaleString('tr-TR')}</div>
            </div>
            <div class="stat-card">
              <div class="stat-card__label">Aktif API Anahtarı</div>
              <div class="stat-card__value">${stats.total_keys}</div>
            </div>
            <div class="stat-card">
              <div class="stat-card__label">Başarı Oranı</div>
              <div class="stat-card__value">%${stats.success_rate}</div>
            </div>
            <div class="stat-card">
              <div class="stat-card__label">Ort. Yanıt Süresi</div>
              <div class="stat-card__value">${stats.avg_response_ms}ms</div>
            </div>
          </div>

          <div style="display:grid; grid-template-columns:1fr 1fr; gap:var(--space-6);">
            <!-- Recent Logins -->
            <div class="card" style="padding:var(--space-6);">
              <h3 style="margin-bottom:var(--space-4);">🔐 Son Girişler</h3>
              <div class="table-wrapper">
                <table class="table">
                  <thead><tr><th>Kullanıcı</th><th>IP</th><th>Durum</th><th>Tarih</th></tr></thead>
                  <tbody>
                    ${(recent_logins || []).map(l => `
                      <tr>
                        <td>${esc(l.user_name || l.email)}</td>
                        <td class="text-muted" style="font-family:var(--font-mono);font-size:var(--fs-xs);">${esc(l.ip_address)}</td>
                        <td><span class="badge badge--${l.status === 'success' ? 'success' : 'error'}">${l.status}</span></td>
                        <td class="text-muted">${fmtDate(l.created_at)}</td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>
              </div>
            </div>

            <!-- Top Users -->
            <div class="card" style="padding:var(--space-6);">
              <h3 style="margin-bottom:var(--space-4);">🏆 En Aktif Kullanıcılar</h3>
              <div class="table-wrapper">
                <table class="table">
                  <thead><tr><th>Kullanıcı</th><th>E-posta</th><th>İstek</th></tr></thead>
                  <tbody>
                    ${(top_users || []).map(u => `
                      <tr>
                        <td><strong>${esc(u.name)}</strong></td>
                        <td class="text-muted">${esc(u.email)}</td>
                        <td>${parseInt(u.request_count).toLocaleString('tr-TR')}</td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
      </div>
    `;
    },
};

function esc(s) { const d = document.createElement('div'); d.textContent = s || ''; return d.innerHTML; }
function fmtDate(s) { try { return new Date(s).toLocaleString('tr-TR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }); } catch { return s || '—'; } }

export default AdminDashboard;
