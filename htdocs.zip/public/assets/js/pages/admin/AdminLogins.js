/**
 * AdminLogins.js — Login security logs
 * logsearch.xyz
 */

import { apiAdminLogins } from '../../api.js';
import { toastError } from '../../components/Toast.js';

const AdminLogins = {
    container: null, currentPage: 1,

    init(container) {
        this.container = container;
        this.load();
    },

    async load() {
        try {
            const r = await apiAdminLogins(this.currentPage);
            this.render(r.data);
        } catch (err) { toastError('Login logları yüklenemedi: ' + err.message); }
    },

    render(data) {
        const { logins, total, page, total_pages } = data;

        this.container.innerHTML = `
      <div class="dashboard-layout"><div class="dashboard-content">
        <div class="dashboard-content__header"><h1>🔒 Giriş Logları</h1><p>Toplam ${total.toLocaleString('tr-TR')} giriş kaydı</p></div>
        ${logins.length ? `
        <div class="table-wrapper"><table class="table">
          <thead><tr><th>Kullanıcı</th><th>E-posta</th><th>IP</th><th>Durum</th><th>Neden</th><th>Tarih</th></tr></thead>
          <tbody>${logins.map(l => `
            <tr class="${l.status !== 'success' ? 'admin-row--danger' : ''}">
              <td>${esc(l.user_name || '—')}</td>
              <td style="font-size:var(--fs-xs);">${esc(l.email)}</td>
              <td style="font-family:var(--font-mono);font-size:var(--fs-xs);">${esc(l.ip_address)}</td>
              <td><span class="badge badge--${l.status === 'success' ? 'success' : l.status === 'failed' ? 'error' : 'warning'}">${l.status}</span></td>
              <td class="text-muted" style="font-size:var(--fs-xs);">${esc(l.failure_reason || '—')}</td>
              <td class="text-muted" style="font-size:var(--fs-xs);">${fmtDate(l.created_at)}</td>
            </tr>`).join('')}
          </tbody>
        </table></div>
        ${total_pages > 1 ? `<div class="admin-pagination">${pgHTML(page, total_pages)}</div>` : ''}
        ` : '<div class="empty-state"><div class="empty-state__icon">🔒</div><p class="empty-state__title">Login kaydı bulunamadı</p></div>'}
      </div></div>`;

        this.container.querySelectorAll('.page-btn').forEach(b => b.addEventListener('click', () => { this.currentPage = parseInt(b.dataset.page); this.load(); }));
    },
};

function esc(s) { const d = document.createElement('div'); d.textContent = s || ''; return d.innerHTML; }
function fmtDate(s) { try { return new Date(s).toLocaleString('tr-TR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }); } catch { return s || '—'; } }
function pgHTML(c, t) { let h = ''; for (let i = 1; i <= t; i++)h += `<button class="btn btn--sm ${i === c ? 'btn--primary' : 'btn--secondary'} page-btn" data-page="${i}">${i}</button> `; return h; }

export default AdminLogins;
