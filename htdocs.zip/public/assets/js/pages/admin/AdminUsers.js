/**
 * AdminUsers.js — User management page
 * logsearch.xyz
 */

import { apiAdminUsers, apiAdminUserUpdate, apiAdminPlans } from '../../api.js';
import { toastSuccess, toastError } from '../../components/Toast.js';
import { openModal, closeModal } from '../../components/Modal.js';

const AdminUsers = {
  container: null,
  currentPage: 1,
  search: '',
  filterStatus: '',
  filterRole: '',
  plans: [],

  init(container) {
    this.container = container;
    this.loadPlans();
    this.renderLoading();
    this.loadUsers();
  },

  async loadPlans() {
    try {
      const r = await apiAdminPlans();
      this.plans = r.data.plans || [];
    } catch { }
  },

  renderLoading() {
    this.container.innerHTML = `
      <div class="dashboard-layout"><div class="dashboard-content">
        <div class="dashboard-content__header">
          <h1>👥 Kullanıcı Yönetimi</h1><p>Tüm kullanıcıları görüntüleyin ve yönetin.</p>
        </div>
        <div class="skeleton skeleton--text" style="height:400px;border-radius:var(--radius-md);"></div>
      </div></div>`;
  },

  async loadUsers() {
    try {
      const r = await apiAdminUsers(this.currentPage, this.search, this.filterStatus, this.filterRole);
      this.render(r.data);
    } catch (err) {
      toastError('Kullanıcılar yüklenemedi: ' + err.message);
    }
  },

  render(data) {
    const { users, total, page, total_pages } = data;
    this.container.innerHTML = `
      <div class="dashboard-layout"><div class="dashboard-content">
        <div class="dashboard-content__header">
          <h1>👥 Kullanıcı Yönetimi</h1>
          <p>Toplam ${total} kullanıcı</p>
        </div>

        <div class="admin-filters">
          <input type="text" class="form-input" placeholder="İsim veya e-posta ara..." id="admin-user-search" value="${esc(this.search)}" style="max-width:280px;">
          <select class="form-input" id="admin-user-status" style="max-width:160px;">
            <option value="">Tüm Durumlar</option>
            <option value="active" ${this.filterStatus === 'active' ? 'selected' : ''}>Aktif</option>
            <option value="suspended" ${this.filterStatus === 'suspended' ? 'selected' : ''}>Askıda</option>
            <option value="banned" ${this.filterStatus === 'banned' ? 'selected' : ''}>Yasaklı</option>
          </select>
          <select class="form-input" id="admin-user-role" style="max-width:140px;">
            <option value="">Tüm Roller</option>
            <option value="user" ${this.filterRole === 'user' ? 'selected' : ''}>User</option>
            <option value="admin" ${this.filterRole === 'admin' ? 'selected' : ''}>Admin</option>
          </select>
        </div>

        ${users.length > 0 ? `
        <div class="table-wrapper">
          <table class="table">
            <thead><tr>
              <th>Ad</th><th>E-posta</th><th>Rol</th><th>Plan</th><th>Bakiye</th><th>Durum</th><th>Son Giriş</th><th>İşlem</th>
            </tr></thead>
            <tbody>
              ${users.map(u => `
                <tr>
                  <td><strong>${esc(u.name)}</strong></td>
                  <td class="text-muted" style="font-size:var(--fs-xs);">${esc(u.email)}</td>
                  <td><span class="badge ${u.role === 'admin' ? 'badge--warning' : 'badge--info'}">${u.role}</span></td>
                  <td>${esc(u.plan_name || 'Yok')}</td>
                  <td>₺${parseFloat(u.balance).toLocaleString('tr-TR')}</td>
                  <td><span class="badge badge--${u.status === 'active' ? 'success' : u.status === 'suspended' ? 'warning' : 'error'}">${u.status}</span></td>
                  <td class="text-muted" style="font-size:var(--fs-xs);">${u.last_login_at ? fmtDate(u.last_login_at) : '—'}</td>
                  <td><button class="btn btn--sm btn--secondary edit-user-btn" data-uid="${u.id}" data-name="${esc(u.name)}" data-role="${u.role}" data-status="${u.status}" data-balance="${u.balance}" data-plan="${u.plan_id || ''}">Düzenle</button></td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>

        ${total_pages > 1 ? `<div class="admin-pagination">${this.paginationHTML(page, total_pages)}</div>` : ''}
        ` : '<div class="empty-state"><div class="empty-state__icon">👥</div><p class="empty-state__title">Kullanıcı bulunamadı</p></div>'}
      </div></div>`;

    this.bindEvents();
  },

  paginationHTML(current, total) {
    let html = '';
    for (let i = 1; i <= total; i++) {
      html += `<button class="btn btn--sm ${i === current ? 'btn--primary' : 'btn--secondary'} page-btn" data-page="${i}">${i}</button> `;
    }
    return html;
  },

  bindEvents() {
    const searchInput = this.container.querySelector('#admin-user-search');
    let searchTimer;
    searchInput?.addEventListener('input', () => {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => {
        this.search = searchInput.value;
        this.currentPage = 1;
        this.loadUsers();
      }, 400);
    });

    this.container.querySelector('#admin-user-status')?.addEventListener('change', (e) => {
      this.filterStatus = e.target.value;
      this.currentPage = 1;
      this.loadUsers();
    });

    this.container.querySelector('#admin-user-role')?.addEventListener('change', (e) => {
      this.filterRole = e.target.value;
      this.currentPage = 1;
      this.loadUsers();
    });

    this.container.querySelectorAll('.page-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        this.currentPage = parseInt(btn.dataset.page);
        this.loadUsers();
      });
    });

    this.container.querySelectorAll('.edit-user-btn').forEach(btn => {
      btn.addEventListener('click', () => this.openEditModal(btn.dataset));
    });
  },

  openEditModal(d) {
    const planOptions = this.plans.map(p =>
      `<option value="${p.id}" ${String(p.id) === String(d.plan) ? 'selected' : ''}>${esc(p.name)} (₺${p.price})</option>`
    ).join('');

    const contentHTML = `
      <div class="form-group">
        <label class="form-label">Rol</label>
        <select class="form-input" id="edit-role">
          <option value="user" ${d.role === 'user' ? 'selected' : ''}>User</option>
          <option value="admin" ${d.role === 'admin' ? 'selected' : ''}>Admin</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Durum</label>
        <select class="form-input" id="edit-status">
          <option value="active" ${d.status === 'active' ? 'selected' : ''}>Aktif</option>
          <option value="suspended" ${d.status === 'suspended' ? 'selected' : ''}>Askıda</option>
          <option value="banned" ${d.status === 'banned' ? 'selected' : ''}>Yasaklı</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Bakiye (₺)</label>
        <input type="number" class="form-input" id="edit-balance" value="${d.balance}" step="0.01">
      </div>
      <div class="form-group">
        <label class="form-label">Plan</label>
        <select class="form-input" id="edit-plan">
          <option value="">Plan Yok</option>
          ${planOptions}
        </select>
      </div>
      <button class="btn btn--primary btn--full" id="save-user-btn" style="margin-top:var(--space-4);">Kaydet</button>
    `;

    openModal({ title: 'Kullanıcı Düzenle: ' + d.name, content: contentHTML });

    const modalBody = document.querySelector('#modal-body');
    modalBody.querySelector('#save-user-btn').addEventListener('click', async () => {
      const btn = modalBody.querySelector('#save-user-btn');
      btn.disabled = true;
      btn.textContent = 'Kaydediliyor...';
      try {
        await apiAdminUserUpdate(d.uid, {
          role: modalBody.querySelector('#edit-role').value,
          status: modalBody.querySelector('#edit-status').value,
          balance: parseFloat(modalBody.querySelector('#edit-balance').value),
          plan_id: modalBody.querySelector('#edit-plan').value || null,
        });
        toastSuccess('Kullanıcı güncellendi.');
        closeModal();
        this.loadUsers();
      } catch (err) {
        toastError(err.message);
        btn.disabled = false;
        btn.textContent = 'Kaydet';
      }
    });
  },
};

function esc(s) { const d = document.createElement('div'); d.textContent = s || ''; return d.innerHTML; }
function fmtDate(s) { try { return new Date(s).toLocaleString('tr-TR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }); } catch { return s || '—'; } }

export default AdminUsers;
