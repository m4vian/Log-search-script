/**
 * Usage.js — API usage statistics page
 * logsearch.xyz
 *
 * Fetches real data from /server/api.php?action=usage
 */

import { apiGetUsage } from '../api.js';
import { toastError } from '../components/Toast.js';
import { formatDate, escapeHTML } from '../utils.js';

const Usage = {
  container: null,
  currentPeriod: 'today',

  init(container) {
    this.container = container;
    this.render();
    this.loadData();
  },

  render() {
    this.container.innerHTML = `
      <div class="dashboard-layout">
        <div class="dashboard-content">
          <div class="dashboard-content__header">
            <h1>Kullanım İstatistikleri</h1>
            <p>API kullanımınızın detaylı analizini görüntüleyin.</p>
          </div>

          <!-- Period Selector -->
          <div style="display: flex; gap: var(--space-3); margin-bottom: var(--space-6);" id="period-selector">
            <button class="filter-btn ${this.currentPeriod === 'today' ? 'filter-btn--active' : ''}" data-period="today">Bugün</button>
            <button class="filter-btn ${this.currentPeriod === 'week' ? 'filter-btn--active' : ''}" data-period="week">Bu Hafta</button>
            <button class="filter-btn ${this.currentPeriod === 'month' ? 'filter-btn--active' : ''}" data-period="month">Bu Ay</button>
          </div>

          <!-- Totals -->
          <div class="stats-grid" id="usage-totals" style="margin-bottom: var(--space-6);">
            <div class="stat-card">
              <div class="skeleton skeleton--text" style="width: 50%; height: 20px;"></div>
            </div>
            <div class="stat-card">
              <div class="skeleton skeleton--text" style="width: 50%; height: 20px;"></div>
            </div>
            <div class="stat-card">
              <div class="skeleton skeleton--text" style="width: 50%; height: 20px;"></div>
            </div>
          </div>

          <!-- Endpoint Table -->
          <h3 style="margin-bottom: var(--space-4);">Kullanım Özeti</h3>
          <div id="usage-table">
            <div class="skeleton skeleton--text" style="height: 200px; border-radius: var(--radius-md);"></div>
          </div>
        </div>
      </div>
    `;

    // Period selector events
    this.container.querySelectorAll('[data-period]').forEach((btn) => {
      btn.addEventListener('click', () => {
        this.currentPeriod = btn.dataset.period;
        this.render();
        this.loadData();
      });
    });
  },

  async loadData() {
    try {
      const result = await apiGetUsage(this.currentPeriod);
      const { totals, endpoints } = result.data;

      // Render totals
      const totalsEl = this.container.querySelector('#usage-totals');
      totalsEl.innerHTML = `
        <div class="stat-card">
          <div class="stat-card__label">Toplam İstek</div>
          <div class="stat-card__value">${(totals?.total_requests || 0).toLocaleString('tr-TR')}</div>
        </div>
        <div class="stat-card">
          <div class="stat-card__label">Başarı Oranı</div>
          <div class="stat-card__value">%${totals?.success_rate || 100}</div>
        </div>
        <div class="stat-card">
          <div class="stat-card__label">Ort. Yanıt Süresi</div>
          <div class="stat-card__value">${totals?.avg_response_ms || 0}ms</div>
        </div>
      `;

      // Render endpoints table
      const tableEl = this.container.querySelector('#usage-table');

      if (endpoints && endpoints.length > 0) {
        tableEl.innerHTML = `
          <div class="table-wrapper">
            <table class="table">
              <thead>
                <tr>
                  <th>Endpoint</th>
                  <th>İstek Sayısı</th>
                  <th>Başarı Oranı</th>
                  <th>Ort. Süre</th>
                </tr>
              </thead>
              <tbody>
                ${endpoints.map((ep) => {
          const rate = parseFloat(ep.success_rate || 100);
          const badgeClass = rate >= 99 ? 'badge--success' : (rate >= 95 ? 'badge--warning' : 'badge--error');
          return `
                  <tr>
                    <td style="font-family: var(--font-mono); font-size: var(--fs-xs);">${escapeHTML(ep.endpoint)}</td>
                    <td>${parseInt(ep.request_count).toLocaleString('tr-TR')}</td>
                    <td><span class="badge ${badgeClass}">%${ep.success_rate}</span></td>
                    <td>${ep.avg_response_ms}ms</td>
                  </tr>
                `;
        }).join('')}
              </tbody>
            </table>
          </div>
        `;
      } else {
        tableEl.innerHTML = `
          <div class="empty-state">
            <div class="empty-state__icon">📊</div>
            <p class="empty-state__title">Bu dönemde veri yok</p>
            <p class="empty-state__desc">Seçili zaman aralığında API kullanımı bulunamadı.</p>
          </div>
        `;
      }

    } catch (err) {
      console.error('[Usage] Load failed:', err);

      // Show inline empty state instead of toast
      const totalsEl = this.container.querySelector('#usage-totals');
      if (totalsEl) {
        totalsEl.innerHTML = `
          <div class="stat-card">
            <div class="stat-card__label">Toplam İstek</div>
            <div class="stat-card__value">0</div>
          </div>
          <div class="stat-card">
            <div class="stat-card__label">Başarı Oranı</div>
            <div class="stat-card__value">%100</div>
          </div>
          <div class="stat-card">
            <div class="stat-card__label">Ort. Yanıt Süresi</div>
            <div class="stat-card__value">0ms</div>
          </div>
        `;
      }

      const tableEl = this.container.querySelector('#usage-table');
      if (tableEl) {
        tableEl.innerHTML = `
          <div class="empty-state">
            <div class="empty-state__icon">📊</div>
            <p class="empty-state__title">Henüz kullanım verisi yok</p>
            <p class="empty-state__desc">API anahtarınızı kullanmaya başladığınızda kullanım istatistikleriniz burada görünecektir.</p>
          </div>
        `;
      }
    }
  },
};

export default Usage;
