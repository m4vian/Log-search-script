/**
 * NotFound.js — 404 page
 * logsearch.xyz
 */

const NotFound = {
    /**
     * Initialize and render
     * @param {HTMLElement} container
     */
    init(container) {
        container.innerHTML = `
      <div class="not-found">
        <div class="not-found__code">404</div>
        <h1 class="not-found__title">Sayfa Bulunamadı</h1>
        <p class="not-found__desc">
          Aradığınız sayfa mevcut değil veya taşınmış olabilir.
        </p>
        <div class="hero__actions">
          <a href="/" class="btn btn--primary" data-link="/">
            Ana Sayfaya Dön
          </a>
          <a href="/docs" class="btn btn--secondary" data-link="/docs">
            Dokümantasyon
          </a>
        </div>
      </div>
    `;
    },
};

export default NotFound;
