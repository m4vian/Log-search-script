/**
 * Home.js — Landing page
 * logsearch.xyz
 *
 * Hero with animated demo, 3 feature cards, CTA, trust links
 */

import { openTermsModal } from '../components/Modal.js';

/** Feature cards data */
const FEATURES = [
  {
    icon: '⚡',
    title: 'Hızlı Arama',
    desc: 'Milyonlarca log kaydını milisaniyeler içinde sorgulayın. Gelişmiş indeksleme ile anında sonuç.',
  },
  {
    icon: '🔒',
    title: 'Güvenli API',
    desc: 'API anahtarı tabanlı kimlik doğrulama, HTTPS zorunluluğu ve rate-limiting koruması.',
  },
  {
    icon: '📊',
    title: 'Detaylı Analitik',
    desc: 'API kullanımınızı gerçek zamanlı takip edin. Sorgu istatistikleri ve kullanım grafikleri.',
  },
];

/** Trust section legal links */
const TRUST_LINKS = [
  { slug: 'kvkk', title: 'KVKK Aydınlatma Metni' },
  { slug: 'gizlilik', title: 'Gizlilik Politikası' },
  { slug: 'iptal-iade', title: 'İptal & İade Politikası' },
  { slug: 'kullanim-kosullari', title: 'Kullanım Koşulları' },
];

const DEMO_DATA = [
  {
    query: 'user@logsearch:~$ search "netflix"',
    results: [
      { user: 'netflixuser01', pass: 'Str0ng!Pass42' },
      { user: 'netflixprem', pass: 'Xy$9kLm!nQ' },
      { user: 'nflix_tr_2024', pass: 'Gk#8pWz!eR' },
      { user: 'premiumNFX', pass: 'Lp@3vBn!sT' },
    ],
  },
  {
    query: 'user@logsearch:~$ search "spotify"',
    results: [
      { user: 'spotifyFam', pass: 'Mq!7xJc#wA' },
      { user: 'sp_premium_tr', pass: 'Rn@5dYf!hU' },
      { user: 'spotuser99', pass: 'Wp#2tKs!oI' },
    ],
  },
  {
    query: 'user@logsearch:~$ search "discord"',
    results: [
      { user: 'discordNitro', pass: 'Hj!4mRq#bL' },
      { user: 'dc_user_pro', pass: 'Tv@6nXe!oP' },
      { user: 'nitro2024tr', pass: 'Bd#1wYs!kQ' },
      { user: 'dcpremium99', pass: 'Zr@8gCf!vN' },
      { user: 'discord_vip', pass: 'Ux!3pHj#mS' },
    ],
  },
];

const Home = {
  _gen: 0,         // generation counter — increments on every new demo or destroy
  _ids: [],        // all setTimeout/setInterval IDs

  _clear() {
    this._gen++;
    this._ids.forEach((id) => { clearTimeout(id); clearInterval(id); });
    this._ids = [];
  },

  /** Called by router when navigating away */
  destroy() {
    this._clear();
  },

  init(container) {
    this._clear();

    container.innerHTML = `
      <!-- Hero Section -->
      <section class="hero">
        <div class="container">
          <div class="hero__badge">● LogSearch.xyz Fast Api 1.0</div>
          <h1 class="hero__title">
            Hızlı API Servis<br><em>İle Log Arama Altyapısı</em>
          </h1>
          <p class="hero__subtitle">
            Uygulamalarınızın log verilerini hızlı ve güvenli bir şekilde sorgulayın. 
            Basit REST API ile dakikalar içinde entegre olun.
          </p>
          <div class="hero__actions">
            <a href="/auth/register" class="btn btn--primary btn--lg" data-link="/auth/register">
              Hemen Kaydol
            </a>
            <a href="/docs" class="btn btn--secondary btn--lg" data-link="/docs">
              Dokümantasyon →
            </a>
          </div>

          <!-- Animated Demo Terminal -->
          <div class="hero-demo" id="hero-demo">
            <div class="hero-demo__header">
              <div class="hero-demo__dots">
                <span></span><span></span><span></span>
              </div>
              <div class="hero-demo__title">logsearch.xyz — Live Demo</div>
              <div class="hero-demo__status">● Bağlı</div>
            </div>
            <div class="hero-demo__body">
              <div class="hero-demo__chat" id="demo-chat"></div>
              <div class="hero-demo__results" id="demo-results"></div>
            </div>
          </div>

        </div>
      </section>

      <!-- Features Section -->
      <section class="features">
        <div class="container">
          <div class="features__header">
            <h2>Neden logsearch.xyz?</h2>
            <p>Modern log arama altyapısıyla uygulamalarınızın log yönetimini kolaylaştırın.</p>
          </div>
          <div class="grid grid--3" id="features-grid"></div>
        </div>
      </section>

      <!-- CTA Section -->
      <section class="section cta-section">
        <div class="container text-center">
          <h3 style="margin-bottom: var(--space-3);">Başlamaya Hazır mısınız?</h3>
          <p class="text-secondary" style="margin-bottom: var(--space-8); max-width: 440px; margin-left: auto; margin-right: auto;">
            Ücretsiz hesap oluşturun ve dakikalar içinde API anahtarınızı alın.
          </p>
          <div class="hero__actions">
            <a href="/auth/register" class="btn btn--primary" data-link="/auth/register">Ücretsiz Hesap Oluştur</a>
            <a href="/pricing" class="btn btn--secondary" data-link="/pricing">Planları İncele</a>
          </div>
        </div>
      </section>

      <!-- Trust Section -->
      <section class="trust">
        <div class="container">
          <div class="trust__inner" id="trust-links"></div>
        </div>
      </section>
    `;

    // Feature cards
    const grid = container.querySelector('#features-grid');
    FEATURES.forEach(({ icon, title, desc }, index) => {
      const card = document.createElement('div');
      card.className = 'card card--reveal';
      card.style.transitionDelay = `${index * 0.12}s`;
      card.innerHTML = `
        <div class="card__icon">${icon}</div>
        <h4 class="card__title">${title}</h4>
        <p class="card__desc">${desc}</p>
      `;
      grid.appendChild(card);
    });

    // Scroll reveal
    const revealCards = container.querySelectorAll('.card--reveal');
    if (revealCards.length > 0) {
      const obs = new IntersectionObserver((entries) => {
        entries.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('is-visible'); obs.unobserve(e.target); } });
      }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });
      revealCards.forEach((c) => obs.observe(c));
    }

    // Trust links
    const trustContainer = container.querySelector('#trust-links');
    TRUST_LINKS.forEach(({ slug, title }, index) => {
      if (index > 0) {
        const d = document.createElement('span');
        d.className = 'trust__divider';
        trustContainer.appendChild(d);
      }
      const link = document.createElement('button');
      link.className = 'trust__link';
      link.textContent = title;
      link.addEventListener('click', () => openTermsModal(slug, title));
      trustContainer.appendChild(link);
    });

    // Start demo
    this._runDemoLoop(container);
  },

  _runDemoLoop(container) {
    const chat = container.querySelector('#demo-chat');
    const results = container.querySelector('#demo-results');
    if (!chat || !results) return;

    let demoIndex = 0;

    const scheduleNext = () => {
      const id = setTimeout(() => {
        runOne();
      }, 10000);
      this._ids.push(id);
    };

    const runOne = () => {
      // Capture current generation
      const gen = this._gen;
      const dead = () => this._gen !== gen;

      const data = DEMO_DATA[demoIndex % DEMO_DATA.length];
      demoIndex++;

      // Clear both panels
      chat.innerHTML = '';
      results.innerHTML = '';

      // Create command line
      const cmdLine = document.createElement('div');
      cmdLine.className = 'demo-line demo-line--cmd';
      chat.appendChild(cmdLine);

      let ci = 0;
      const typeId = setInterval(() => {
        if (dead()) { clearInterval(typeId); return; }

        if (ci < data.query.length) {
          cmdLine.textContent = data.query.substring(0, ci + 1);
          const cur = document.createElement('span');
          cur.className = 'demo-cursor';
          cur.textContent = '█';
          cmdLine.appendChild(cur);
          ci++;
        } else {
          clearInterval(typeId);
          const cur = cmdLine.querySelector('.demo-cursor');
          if (cur) cur.remove();

          // Info line after typing done
          const t1 = setTimeout(() => {
            if (dead()) return;
            const info = document.createElement('div');
            info.className = 'demo-line demo-line--info demo-fadein';
            info.innerHTML = `<span class="demo-accent">⚡</span> ${data.results.length} sonuç bulundu <span class="demo-muted">(0.${Math.floor(Math.random() * 90) + 10}ms)</span>`;
            chat.appendChild(info);

            // Results one by one
            data.results.forEach((r, i) => {
              const t2 = setTimeout(() => {
                if (dead()) return;
                const row = document.createElement('div');
                row.className = 'demo-result demo-fadein';
                row.innerHTML = `
                  <span class="demo-result__index">${String(i + 1).padStart(2, '0')}</span>
                  <span class="demo-result__user">${r.user}</span>
                  <span class="demo-result__sep">:</span>
                  <span class="demo-result__pass">${r.pass}</span>
                `;
                results.appendChild(row);
              }, (i + 1) * 350);
              this._ids.push(t2);
            });

            // Download button
            const t3 = setTimeout(() => {
              if (dead()) return;
              const dl = document.createElement('div');
              dl.className = 'demo-download demo-fadein';
              dl.innerHTML = '<span class="demo-download__icon">⬇</span> İndir (.txt)';
              results.appendChild(dl);

              const t4 = setTimeout(() => {
                if (dead()) return;
                dl.classList.add('demo-download--clicked');
                dl.innerHTML = '<span class="demo-download__icon">✓</span> İndirildi!';

                // Schedule next demo cycle after download animation completes
                scheduleNext();
              }, 1500);
              this._ids.push(t4);
            }, (data.results.length + 1) * 350 + 300);
            this._ids.push(t3);

          }, 500);
          this._ids.push(t1);

        }
      }, 40);
      this._ids.push(typeId);
    };

    // Start first after 1s
    const startId = setTimeout(runOne, 1000);
    this._ids.push(startId);
  },
};

export default Home;
