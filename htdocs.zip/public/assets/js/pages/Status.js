/**
 * Status.js — API server status page
 * logsearch.xyz
 *
 * Server status table with UP/DOWN/MAINTENANCE badges, latency, last check.
 * Filterable by status. Refresh button (mock data).
 */

const Status = {
  /** Server data */


  servers: [
    { name: 'API Server 1', endpoint: 'api1.logsearch.xyz', status: 'MAINTENANCE', latency: '—', lastCheck: 'az önce', region: 'EU-Turkey' },
    { name: 'API Server 2', endpoint: 'api2.logsearch.xyz', status: 'UP', latency: '12ms', lastCheck: 'az önce', region: 'EU-Central' },
    { name: 'API Server 3', endpoint: 'api3.logsearch.xyz', status: 'UP', latency: '12ms', lastCheck: 'az önce', region: 'US-East' },
    { name: 'Cloud API 1', endpoint: 'cloud1.logsearch.xyz', status: 'UP', latency: '12ms', lastCheck: 'az önce', region: 'EU-West' },
    { name: 'Cloud API 2', endpoint: 'cloud2.logsearch.xyz', status: 'UP', latency: '12ms', lastCheck: 'az önce', region: 'US-East' },
  ],

  /** Current filter */
  filter: 'ALL',

  /**
   * Initialize and render
   * @param {HTMLElement} container
   */
  init(container) {
    this.container = container;
    this.render();
  },

  render() {
    const filtered = this.filter === 'ALL'
      ? this.servers
      : this.servers.filter((s) => s.status === this.filter);

    const upCount = this.servers.filter((s) => s.status === 'UP').length;
    const maintCount = this.servers.filter((s) => s.status === 'MAINTENANCE').length;
    const totalCount = this.servers.length;

    const getStatusBadge = (status) => {
      if (status === 'UP') return '<span class="badge badge--success"><span class="badge__dot"></span>Aktif</span>';
      if (status === 'MAINTENANCE') return '<span class="badge badge--warning"><span class="badge__dot"></span>Bakımda</span>';
      return '<span class="badge badge--error"><span class="badge__dot"></span>Arızalı</span>';
    };

    const getOverallBadge = () => {
      if (upCount === totalCount) return 'success';
      if (maintCount > 0) return 'warning';
      return 'error';
    };

    this.container.innerHTML = `
      <div class="status-page">
        <div class="container">
          <div class="status-page__header">
            <div>
              <h1>Sistem Durumu</h1>
              <p class="text-secondary" style="margin-top: var(--space-2);">
                <span class="badge badge--${getOverallBadge()}">
                  <span class="badge__dot"></span>
                  ${upCount}/${totalCount} Aktif — ${maintCount} Bakımda
                </span>
              </p>
            </div>
            <div class="status-page__filters">
              <button class="filter-btn ${this.filter === 'ALL' ? 'filter-btn--active' : ''}" data-filter="ALL">Tümü</button>
              <button class="filter-btn ${this.filter === 'UP' ? 'filter-btn--active' : ''}" data-filter="UP">Aktif</button>
              <button class="filter-btn ${this.filter === 'MAINTENANCE' ? 'filter-btn--active' : ''}" data-filter="MAINTENANCE">Bakımda</button>
              <button class="filter-btn ${this.filter === 'DOWN' ? 'filter-btn--active' : ''}" data-filter="DOWN">Arızalı</button>
              <button class="btn btn--secondary btn--sm" id="status-refresh">↻ Yenile</button>
            </div>
          </div>

          <div class="table-wrapper">
            <table class="table">
              <thead>
                <tr>
                  <th>Servis</th>
                  <th>Endpoint</th>
                  <th>Bölge</th>
                  <th>Durum</th>
                  <th>Gecikme</th>
                  <th>Son Kontrol</th>
                </tr>
              </thead>
              <tbody id="status-tbody">
                ${filtered.map((s) => `
                  <tr>
                    <td><strong>${s.name}</strong></td>
                    <td style="font-family: var(--font-mono); font-size: var(--fs-xs); color: var(--color-text-muted);">${s.endpoint}</td>
                    <td>${s.region}</td>
                    <td>${getStatusBadge(s.status)}</td>
                    <td>${s.latency}</td>
                    <td class="text-muted">${s.lastCheck}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>

          ${filtered.length === 0 ? `
            <div class="empty-state" style="padding: var(--space-12);">
              <div class="empty-state__icon">🔍</div>
              <p class="empty-state__title">Sonuç bulunamadı</p>
              <p class="empty-state__desc">Seçili filtreye uygun servis yok.</p>
            </div>
          ` : ''}
        </div>
      </div>
    `;

    // Event listeners
    this.container.querySelectorAll('[data-filter]').forEach((btn) => {
      btn.addEventListener('click', () => {
        this.filter = btn.dataset.filter;
        this.render();
      });
    });

    this.container.querySelector('#status-refresh')?.addEventListener('click', () => {
      // Mock refresh — randomize latency for active servers
      this.servers.forEach((s) => {
        if (s.status === 'UP') {
          s.latency = `${Math.floor(Math.random() * 40) + 5}ms`;
          s.lastCheck = 'az önce';
        }
      });
      this.render();
    });
  },
};

export default Status;
