/**
 * Pricing.js — Plans & pricing page
 * logsearch.xyz
 */


import { apiGetPlans, apiGetConfig } from '../api.js';
import { toastError } from '../components/Toast.js';
import { isAuthenticated } from '../store.js';

const Pricing = {
  /**
   * Initialize and render
   * @param {HTMLElement} container
   */
  async init(container) {
    container.innerHTML = `
      <div class="pricing-page">
        <div class="container">
          <div class="pricing-page__header">
            <h1>Fiyatlandırma</h1>
            <p>Projelerinize uygun planı seçin. Satın alım ve bakiye yükleme işlemleri Discord sunucumuz üzerinden yapılmaktadır.</p>
          </div>
          <div class="grid grid--3" id="pricing-grid">
             <!-- Skeletons -->
             <div class="skeleton" style="height:400px;border-radius:var(--radius-lg)"></div>
             <div class="skeleton" style="height:400px;border-radius:var(--radius-lg)"></div>
             <div class="skeleton" style="height:400px;border-radius:var(--radius-lg)"></div>
          </div>
        </div>
      </div>
    `;

    try {
      const [plansRes, configRes] = await Promise.all([
          apiGetPlans(),
          apiGetConfig()
      ]);
      const plans = plansRes.data.plans || [];
      const discordUrl = configRes.data.discord_url;
      this.renderPlans(container, plans, discordUrl);
    } catch (err) {
      toastError('Planlar yüklenemedi: ' + err.message);
      container.querySelector('#pricing-grid').innerHTML = '<p class="text-center text-muted col-span-3">Planlar şu anda görüntülenemiyor.</p>';
    }
  },

  renderPlans(container, plans, discordUrl) {
    const grid = container.querySelector('#pricing-grid');
    grid.innerHTML = '';

    if (plans.length === 0) {
      grid.innerHTML = '<p class="text-center text-muted col-span-3">Henüz aktif plan bulunmamaktadır.</p>';
      return;
    }

    const isAuth = isAuthenticated();

    plans.forEach((plan) => {
      let features = [];
      try {
        features = JSON.parse(plan.features || '[]');
      } catch (e) {
        features = [plan.features];
      }

      // Determine if accent based on sort_order or features
      const isAccent = plan.name.toLowerCase().includes('pro') || plan.sort_order === 2;

      const periodDisplay = plan.billing_period === 'monthly' ? '/ay' :
        plan.billing_period === 'yearly' ? '/yıl' :
          plan.billing_period === 'lifetime' ? '' : `/${plan.billing_period}`;

      const priceDisplay = plan.price == 0 ? 'Ücretsiz' : `₺${parseFloat(plan.price).toLocaleString('tr-TR')}`;

      let ctaText = 'Kayıt Ol';
      let ctaHref = '/auth/register';
      let ctaClass = isAccent ? 'btn--primary' : 'btn--secondary';
      let isExternal = false;

      if (isAuth) {
        ctaText = plan.price == 0 ? 'Mevcut Planınız' : 'Satın Al (Discord)';
        ctaHref = plan.price == 0 ? '#' : discordUrl;
        isExternal = plan.price != 0;
      }

      const card = document.createElement('div');
      card.className = `card pricing-card ${isAccent ? 'card--accent' : ''}`;
      card.innerHTML = `
        <div class="pricing-card__name">${plan.name}</div>
        <div class="pricing-card__price">${priceDisplay}<span style="font-size:0.5em;margin-left:4px;font-weight:normal;color:var(--color-text-muted)">${plan.price > 0 ? periodDisplay : ''}</span></div>
        <p class="pricing-card__desc">${plan.description || ''}</p>
        
        <div class="pricing-card__features">
          <div class="pricing-card__feature">${parseInt(plan.requests_per_day).toLocaleString('tr-TR')} istek / gün</div>
          <div class="pricing-card__feature">${plan.log_retention_days} gün log saklama</div>
          ${features.map((f) => `<div class="pricing-card__feature">${f}</div>`).join('')}
        </div>
        
        <a href="${ctaHref}" class="btn ${ctaClass} btn--full plan-action-btn" ${!isExternal && !isAuth ? `data-link="${ctaHref}"` : ''} ${isExternal ? 'target="_blank" rel="noopener noreferrer"' : ''}>
          ${ctaText}
        </a>
      `;
      grid.appendChild(card);
    });
  }
};

export default Pricing;
