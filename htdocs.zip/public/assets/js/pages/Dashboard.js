/**
 * Dashboard.js — Dashboard overview page
 * logsearch.xyz
 *
 * Fetches real data from /server/api.php?action=dashboard
 */

import { getUser } from '../store.js';
import { apiGetDashboard } from '../api.js';
import { formatDate, escapeHTML } from '../utils.js';

const Dashboard = {
  init(container) {
    const user = getUser();
    const greeting = user?.name || user?.email || 'Kullanıcı';

    // Initial loading state
    container.innerHTML = `
      <div class="dashboard-layout">
        <div class="dashboard-content">
          <div class="dashboard-content__header">
            <h1>Hoş Geldiniz, ${greeting}</h1>
            <p>API kullanımınızın genel özeti aşağıda yer almaktadır.</p>
          </div>

          <!-- Stats Grid — Skeleton -->
          <div class="stats-grid" id="stats-grid">
            ${skeletonCard()}${skeletonCard()}${skeletonCard()}${skeletonCard()}
          </div>

          <!-- Recent Activity -->
          <div style="margin-top: var(--space-4);">
            <h3 style="margin-bottom: var(--space-4);">Son Aktiviteler</h3>
            <div id="activity-table">
              <div class="skeleton skeleton--text" style="height: 200px; border-radius: var(--radius-md);"></div>
            </div>
          </div>
        </div>
      </div>
    `;

    this.loadData(container);
  },


  async loadData(container) {
    try {
      const [result, configRes] = await Promise.all([
        apiGetDashboard(),
        import('../api.js').then(m => m.apiGetConfig()) // lazy load or we can just import at top, let's keep it simple
      ]);
      const { stats, plan, recent_activity } = result.data;
      const discordUrl = configRes.data.discord_url;

      // Render stats
      const statsGrid = container.querySelector('#stats-grid');
      const weekArrow = stats.week_change >= 0 ? '↑' : '↓';
      const weekClass = stats.week_change >= 0 ? 'badge--success' : 'badge--error';

      const dailyLimit = stats.daily_limit || 100;
      const todayUsed = stats.today_requests || 0;
      const remaining = Math.max(0, dailyLimit - todayUsed);

      statsGrid.innerHTML = `
        <div class="stat-card">
          <div class="stat-card__label">Kalan İstek</div>
          <div class="stat-card__value">${remaining.toLocaleString('tr-TR')} <span style="font-size: var(--fs-sm); color: var(--color-text-muted);">/ ${dailyLimit.toLocaleString('tr-TR')}</span></div>
          <div class="stat-card__change">Bugün ${todayUsed.toLocaleString('tr-TR')} istek kullanıldı</div>
        </div>
        <div class="stat-card">
          <div class="stat-card__label">Aktif Anahtarlar</div>
          <div class="stat-card__value">${stats.active_keys}</div>
          <div class="stat-card__change">${plan ? plan.name + ' Plan' : 'Plan yok'} <a href="/pricing" data-link="/pricing" style="font-size: 0.8em; margin-left: 5px;">Yükselt</a></div>
        </div>
        <div class="stat-card">
          <div class="stat-card__label">Başarı Oranı</div>
          <div class="stat-card__value">%${stats.success_rate}</div>
          <div class="stat-card__change">Tüm zamanlar</div>
        </div>
        <div class="stat-card">
          <div class="stat-card__label">Bakiye Bilgisi</div>
          <div class="stat-card__value">₺${stats.balance.toFixed(2)}</div>
          <div class="stat-card__change mt-2"><a href="${discordUrl}" target="_blank" class="btn btn--primary btn--sm" style="padding: 2px 10px; font-size: 0.75rem;">Bakiye Yükle</a></div>
        </div>
      `;

      // Render activity table
      const actTable = container.querySelector('#activity-table');

      if (recent_activity && recent_activity.length > 0) {
        actTable.innerHTML = `
          <div class="table-wrapper">
            <table class="table">
              <thead>
                <tr>
                  <th>Tarih</th>
                  <th>Method</th>
                  <th>Endpoint</th>
                  <th>Durum</th>
                  <th>Süre</th>
                </tr>
              </thead>
              <tbody>
                ${recent_activity.map(row => {
          const badgeClass = row.status_code < 400 ? 'badge--success' : (row.status_code < 500 ? 'badge--warning' : 'badge--error');
          return `
                  <tr>
                    <td class="text-muted">${formatDate(row.created_at)}</td>
                    <td><span class="badge badge--info">${row.method}</span></td>
                    <td style="font-family: var(--font-mono); font-size: var(--fs-xs);">${escapeHTML(row.endpoint)}</td>
                    <td><span class="badge ${badgeClass}">${row.status_code}</span></td>
                    <td class="text-muted">${row.response_time_ms}ms</td>
                  </tr>
                `;
        }).join('')}
              </tbody>
            </table>
          </div>
        `;
      } else {
        actTable.innerHTML = `
          <div class="empty-state">
            <div class="empty-state__icon">📊</div>
            <p class="empty-state__title">Henüz aktivite yok</p>
            <p class="empty-state__desc">API anahtarınızı kullanarak ilk isteğinizi gönderin.</p>
          </div>
        `;
      }

    } catch (err) {
      console.error('[Dashboard] Load failed:', err);
      container.querySelector('#stats-grid').innerHTML = `
        <div class="stat-card" style="grid-column: 1 / -1; text-align: center;">
          <p class="text-muted">Veriler yüklenemedi: ${err.message}</p>
        </div>
      `;
    }
  },
};

function skeletonCard() {
  return `
    <div class="stat-card">
      <div class="skeleton skeleton--text" style="width: 60%; height: 14px; margin-bottom: var(--space-2);"></div>
      <div class="skeleton skeleton--text" style="width: 40%; height: 24px; margin-bottom: var(--space-2);"></div>
      <div class="skeleton skeleton--text" style="width: 50%; height: 12px;"></div>
    </div>
  `;
}

export default Dashboard;
