/**
 * Keys.js — API key management page
 * logsearch.xyz
 *
 * Real API: list, create, revoke keys via /server/api.php
 */

import { apiGetKeys, apiCreateKey, apiRevokeKey } from '../api.js';
import { toastSuccess, toastError } from '../components/Toast.js';
import { escapeHTML } from '../utils.js';

const Keys = {
  container: null,
  keys: [],

  init(container) {
    this.container = container;
    this.renderLoading();
    this.loadKeys();
  },

  renderLoading() {
    this.container.innerHTML = `
      <div class="dashboard-layout">
        <div class="dashboard-content">
          <div class="dashboard-content__header">
            <h1>API Anahtarları</h1>
            <p>API anahtarlarınızı oluşturun ve yönetin.</p>
          </div>
          <div class="skeleton skeleton--text" style="height: 300px; border-radius: var(--radius-md);"></div>
        </div>
      </div>
    `;
  },

  async loadKeys() {
    try {
      const result = await apiGetKeys();
      this.keys = result.data.keys || [];
      this.render();
    } catch (err) {
      toastError('Anahtarlar yüklenemedi: ' + err.message);
      this.container.querySelector('.dashboard-content').innerHTML += `
        <div class="empty-state">
          <p class="text-muted">Veriler yüklenemedi.</p>
        </div>
      `;
    }
  },

  render() {
    const activeKeys = this.keys.filter((k) => k.status === 'active');

    this.container.innerHTML = `
      <div class="dashboard-layout">
        <div class="dashboard-content">
          <div class="dashboard-content__header">
            <h1>API Anahtarları</h1>
            <p>API anahtarlarınızı oluşturun ve yönetin.</p>
          </div>

          <div class="keys-header">
            <span class="text-secondary" style="font-size: var(--fs-sm);">
              ${activeKeys.length} aktif anahtar
            </span>
            <button class="btn btn--primary btn--sm" id="create-key-btn">
              + Yeni Anahtar Oluştur
            </button>
          </div>

          ${activeKeys.length > 0 ? `
            <div class="table-wrapper">
              <table class="table">
                <thead>
                  <tr>
                    <th>Ad</th>
                    <th>Anahtar</th>
                    <th>Oluşturulma</th>
                    <th>Son Kullanım</th>
                    <th>İşlem</th>
                  </tr>
                </thead>
                <tbody id="keys-tbody">
                  ${activeKeys.map((key) => `
                    <tr data-key-id="${key.id}">
                      <td><strong>${escapeHTML(key.name)}</strong></td>
                      <td><span class="key-prefix">${escapeHTML(key.prefix)}••••••</span></td>
                      <td class="text-muted">${formatKeyDate(key.created_at)}</td>
                      <td class="text-muted">${key.last_used_at ? formatKeyDate(key.last_used_at) : 'Hiç kullanılmadı'}</td>
                      <td>
                        <button class="btn btn--danger btn--sm revoke-btn" data-id="${key.id}">
                          İptal Et
                        </button>
                      </td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          ` : `
            <div class="empty-state">
              <div class="empty-state__icon">⚿</div>
              <p class="empty-state__title">Henüz API anahtarı yok</p>
              <p class="empty-state__desc">İlk API anahtarınızı oluşturarak başlayın.</p>
            </div>
          `}
        </div>
      </div>
    `;

    // Event: Create Key
    this.container.querySelector('#create-key-btn')?.addEventListener('click', () => {
      this.createKey();
    });

    // Event: Revoke Key
    this.container.querySelectorAll('.revoke-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        this.revokeKey(parseInt(btn.dataset.id, 10));
      });
    });
  },

  async createKey() {
    const createBtn = this.container.querySelector('#create-key-btn');
    if (createBtn) {
      createBtn.disabled = true;
      createBtn.textContent = 'Oluşturuluyor...';
    }

    try {
      const result = await apiCreateKey();
      const newKey = result.data.key;

      toastSuccess(`${result.message}\n\nAnahtarınız: ${newKey.raw_key}`);

      // Reload keys
      await this.loadKeys();
    } catch (err) {
      toastError(err.message || 'Anahtar oluşturulamadı.');
    } finally {
      if (createBtn) {
        createBtn.disabled = false;
        createBtn.textContent = '+ Yeni Anahtar Oluştur';
      }
    }
  },

  async revokeKey(id) {
    const btn = this.container.querySelector(`.revoke-btn[data-id="${id}"]`);
    if (btn) {
      btn.disabled = true;
      btn.textContent = 'İptal ediliyor...';
    }

    try {
      const result = await apiRevokeKey(id);
      toastSuccess(result.message || 'Anahtar iptal edildi.');

      // Reload keys
      await this.loadKeys();
    } catch (err) {
      toastError(err.message || 'Anahtar iptal edilemedi.');
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'İptal Et';
      }
    }
  },
};

function formatKeyDate(dateStr) {
  try {
    return new Date(dateStr).toLocaleDateString('tr-TR', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  } catch {
    return dateStr || '—';
  }
}

export default Keys;
