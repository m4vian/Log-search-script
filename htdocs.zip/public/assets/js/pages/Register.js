/**
 * Register.js — Registration page
 * logsearch.xyz
 *
 * Real API registration via /server/api.php
 * Only Üyelik Sözleşmesi + KVKK checkboxes with modern toggle design.
 */

import { login } from '../store.js';
import { apiRegister } from '../api.js';
import { navigate } from '../router.js';
import { toastSuccess, toastError } from '../components/Toast.js';
import { openTermsModal } from '../components/Modal.js';

const LEGAL_ITEMS = [
  { slug: 'uyelik-sozlesmesi', title: 'Üyelik Sözleşmesi' },
  { slug: 'kvkk', title: 'KVKK Aydınlatma Metni' },
];

const Register = {
  init(container) {
    container.innerHTML = `
      <div class="auth-page">
        <div class="auth-card">
          <div class="auth-card__header">
            <div class="auth-card__logo">
              <span class="auth-card__logo-icon">⚡</span>
            </div>
            <h1>Hesap Oluştur</h1>
            <p>Ücretsiz hesap oluşturun ve hemen API kullanmaya başlayın.</p>
          </div>

          <form class="auth-card__form" id="register-form" novalidate>
            <div class="form-group">
              <label class="form-label" for="reg-name">Ad Soyad</label>
              <input
                type="text"
                id="reg-name"
                class="form-input"
                placeholder="Adınız Soyadınız"
                required
                autocomplete="name"
              />
            </div>

            <div class="form-group">
              <label class="form-label" for="reg-email">E-posta</label>
              <input
                type="email"
                id="reg-email"
                class="form-input"
                placeholder="ornek@email.com"
                required
                autocomplete="email"
              />
            </div>

            <div class="form-group">
              <label class="form-label" for="reg-password">Şifre</label>
              <input
                type="password"
                id="reg-password"
                class="form-input"
                placeholder="En az 8 karakter"
                required
                minlength="8"
                autocomplete="new-password"
              />
              <span class="form-hint">En az 8 karakter olmalıdır.</span>
            </div>

            <div class="terms-agreement" id="terms-checkboxes"></div>

            <button type="submit" class="btn btn--primary btn--full btn--lg auth-submit-btn" id="register-submit">
              <span class="auth-submit-btn__text">Hesap Oluştur</span>
              <span class="auth-submit-btn__arrow">→</span>
            </button>
          </form>

          <div class="auth-card__footer">
            Zaten hesabınız var mı? <a href="/auth/login" data-link="/auth/login">Giriş Yap</a>
          </div>
        </div>
      </div>
    `;

    // Render toggle checkboxes
    const termsContainer = container.querySelector('#terms-checkboxes');

    LEGAL_ITEMS.forEach(({ slug, title }) => {
      const item = document.createElement('label');
      item.className = 'terms-item';
      item.setAttribute('for', `terms-${slug}`);

      item.innerHTML = `
        <div class="terms-item__toggle">
          <input type="checkbox" id="terms-${slug}" name="terms-${slug}" required />
          <span class="terms-item__switch"></span>
        </div>
        <div class="terms-item__content">
          <span class="terms-item__link" data-slug="${slug}" data-title="${title}">${title}</span>
          <span class="terms-item__text">'ni okudum, kabul ediyorum.</span>
        </div>
      `;

      termsContainer.appendChild(item);
    });

    // Link click → open modal
    termsContainer.querySelectorAll('.terms-item__link').forEach((link) => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        openTermsModal(link.dataset.slug, link.dataset.title);
      });
    });

    // Form handler
    const form = container.querySelector('#register-form');
    const submitBtn = container.querySelector('#register-submit');

    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      const name = container.querySelector('#reg-name').value.trim();
      const email = container.querySelector('#reg-email').value.trim();
      const password = container.querySelector('#reg-password').value;

      if (!name || !email || !password) {
        toastError('Lütfen tüm alanları doldurun.');
        return;
      }

      if (!email.includes('@')) {
        toastError('Geçerli bir e-posta adresi girin.');
        return;
      }

      if (password.length < 8) {
        toastError('Şifre en az 8 karakter olmalıdır.');
        return;
      }

      const unchecked = LEGAL_ITEMS.some(({ slug }) => {
        return !container.querySelector(`#terms-${slug}`).checked;
      });

      if (unchecked) {
        toastError('Lütfen tüm sözleşmeleri onaylayın.');
        return;
      }

      // Disable button
      submitBtn.disabled = true;
      submitBtn.querySelector('.auth-submit-btn__text').textContent = 'Oluşturuluyor...';

      try {
        const result = await apiRegister(name, email, password);

        // Set local state from API response
        login(result.data.user);

        toastSuccess(result.message || 'Hesabınız başarıyla oluşturuldu!');
        navigate('/dashboard');
      } catch (err) {
        toastError(err.message || 'Kayıt başarısız.');
      } finally {
        submitBtn.disabled = false;
        submitBtn.querySelector('.auth-submit-btn__text').textContent = 'Hesap Oluştur';
      }
    });
  },
};

export default Register;
