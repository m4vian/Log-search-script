/**
 * store.js — Application state management
 * logsearch.xyz
 *
 * Stores auth state and user info. Persists to localStorage.
 * Provides subscribe/notify pattern for reactive updates.
 * Auth now backed by PHP session — localStorage is for fast UI checks.
 */

import { apiGetMe, apiLogin as apiLoginCall, apiLogout as apiLogoutCall } from './api.js';

const STORAGE_KEY = 'logsearch_state';

/** @type {Map<string, Set<Function>>} */
const listeners = new Map();

const defaultState = {
    auth: {
        isLoggedIn: false,
        user: null, // { id, email, name, balance, role }
    },
};

let state = loadState();

function loadState() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) return JSON.parse(raw);
    } catch (err) {
        console.warn('[Store] Failed to load state:', err);
    }
    return structuredClone(defaultState);
}

function saveState() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (err) {
        console.warn('[Store] Failed to save state:', err);
    }
}

// ─── State Access ───────────────────────────────

export function getState(key) {
    return key.split('.').reduce((obj, k) => obj?.[k], state);
}

export function setState(key, value) {
    const keys = key.split('.');
    const last = keys.pop();
    const target = keys.reduce((obj, k) => {
        if (!obj[k]) obj[k] = {};
        return obj[k];
    }, state);
    target[last] = value;
    saveState();
    notify(key);
}

export function subscribe(key, callback) {
    if (!listeners.has(key)) listeners.set(key, new Set());
    listeners.get(key).add(callback);
    return () => listeners.get(key)?.delete(callback);
}

function notify(key) {
    listeners.get(key)?.forEach((fn) => fn(getState(key)));
    const parts = key.split('.');
    while (parts.length > 1) {
        parts.pop();
        const parentKey = parts.join('.');
        listeners.get(parentKey)?.forEach((fn) => fn(getState(parentKey)));
    }
}

// ─── Auth Methods ───────────────────────────────

/**
 * @returns {boolean} true if current user has admin role
 */
export function isAdmin() {
    const user = getState('auth.user');
    return isAuthenticated() && user?.role === 'admin';
}

/**
 * Set user in local state (used after API confirms auth)
 * @param {Object} user — { id, name, email, balance, role }
 */
export function login(user) {
    setState('auth', { isLoggedIn: true, user });
}

/**
 * Clear local auth state
 */
export function logout() {
    setState('auth', { isLoggedIn: false, user: null });
}

/**
 * Perform real logout (API + local)
 */
export async function performLogout() {
    try {
        await apiLogoutCall();
    } catch {
        // Session might already be expired, that's OK
    }
    logout();
}

/**
 * Check if user is logged in
 */
export function isAuthenticated() {
    return getState('auth.isLoggedIn') === true;
}

/**
 * Get current user
 */
export function getUser() {
    return getState('auth.user');
}

/**
 * Verify session with server on page load.
 * If localStorage says user is logged in, verify with /me endpoint.
 * If session is invalid, clear local state.
 */
export async function verifySession() {
    if (!isAuthenticated()) return false;

    try {
        const result = await apiGetMe();
        if (result.success && result.data?.user) {
            login(result.data.user);
            return true;
        }
    } catch {
        // session invalid
    }
    logout();
    return false;
}
