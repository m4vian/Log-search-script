/**
 * router.js — History API based SPA router
 * logsearch.xyz
 *
 * Features:
 * - Route map with lazy page initialization
 * - pushState navigation
 * - Link intercept via [data-link] attribute
 * - Scroll to top on navigation
 * - 404 fallback
 * - Protected routes (redirect to /auth/login if not authenticated)
 */

import { isAuthenticated, isAdmin } from './store.js';

/** @type {Map<string, { page: () => Promise<{default: {init: Function}}>, protected?: boolean, layout?: string }>} */
const routes = new Map();

/** Current active page module */
let currentPage = null;

/** Callback for before-render hook (used for layout changes) */
let onBeforeRender = null;

/** Callback for after-render hook */
let onAfterRender = null;

/**
 * Register a route
 * @param {string} path
 * @param {Object} config
 */
export function addRoute(path, config) {
    routes.set(path, config);
}

/**
 * Set lifecycle hooks
 * @param {{ beforeRender?: Function, afterRender?: Function }} hooks
 */
export function setHooks(hooks) {
    if (hooks.beforeRender) onBeforeRender = hooks.beforeRender;
    if (hooks.afterRender) onAfterRender = hooks.afterRender;
}

/**
 * Navigate to a path
 * @param {string} path
 * @param {boolean} [replace=false] — use replaceState instead of pushState
 */
export function navigate(path, replace = false) {
    if (path === window.location.pathname) {
        // Same route — just scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
    }

    if (replace) {
        window.history.replaceState(null, '', path);
    } else {
        window.history.pushState(null, '', path);
    }

    handleRoute();
}

/**
 * Find matching route config for a path
 * @param {string} path
 * @returns {{ config: Object, params: Object } | null}
 */
function matchRoute(path) {
    // Exact match first
    if (routes.has(path)) {
        return { config: routes.get(path), params: {} };
    }

    // Try prefix match for nested routes (e.g. /dashboard/keys → /dashboard/keys)
    // No dynamic params needed for this project
    return null;
}

/**
 * Handle the current route
 */
async function handleRoute() {
    const path = window.location.pathname;
    const match = matchRoute(path);

    // Destroy previous page if it has a destroy method
    if (currentPage?.destroy) {
        currentPage.destroy();
    }

    let config;

    if (!match) {
        // 404 fallback
        config = routes.get('/404');
        if (!config) {
            document.getElementById('app').innerHTML = '<div class="container section text-center"><h1>404</h1><p>Sayfa bulunamadı.</p></div>';
            return;
        }
    } else {
        config = match.config;
    }

    // Protected route check
    if (config.protected && !isAuthenticated()) {
        navigate('/auth/login', true);
        return;
    }

    // Admin-only route check — show 404, don't reveal admin panel exists
    if (config.adminOnly && !isAdmin()) {
        config = routes.get('/404');
        if (!config) {
            document.getElementById('app').innerHTML = '<div class="container section text-center"><h1>404</h1><p>Sayfa bulunamadı.</p></div>';
            return;
        }
    }

    // Before render hook (layout changes, sidebar visibility etc.)
    if (onBeforeRender) {
        onBeforeRender(config, path);
    }

    // Scroll to top
    window.scrollTo({ top: 0 });

    try {
        // Load the page module
        const module = await config.page();
        const page = module.default || module;

        // Initialize and render
        const appEl = document.getElementById('app');

        if (typeof page.init === 'function') {
            currentPage = page;
            page.init(appEl);
        } else if (typeof page === 'function') {
            currentPage = { destroy: null };
            page(appEl);
        }
    } catch (err) {
        console.error('[Router] Failed to load page:', err);
        document.getElementById('app').innerHTML =
            '<div class="container section text-center"><h1>Hata</h1><p>Sayfa yüklenirken bir hata oluştu.</p></div>';
    }

    // After render hook
    if (onAfterRender) {
        onAfterRender(config, path);
    }
}

/**
 * Intercept clicks on [data-link] elements for SPA navigation
 */
function interceptLinks() {
    document.addEventListener('click', (e) => {
        const link = e.target.closest('[data-link]');
        if (!link) return;

        e.preventDefault();
        const href = link.getAttribute('href') || link.dataset.link;
        if (href) {
            navigate(href);
        }
    });
}

/**
 * Handle browser back/forward buttons
 */
function handlePopState() {
    window.addEventListener('popstate', () => {
        handleRoute();
    });
}

/**
 * Initialize the router
 */
export function initRouter() {
    interceptLinks();
    handlePopState();
    handleRoute();
}

export default {
    addRoute,
    navigate,
    initRouter,
    setHooks,
};
