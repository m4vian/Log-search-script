<?php
/**
 * Database.php — PDO Veritabanı Bağlantı Sınıfı
 * logsearch.xyz
 *
 * Singleton pattern ile tek bir bağlantı yönetir.
 * PDO hata modunu exception olarak ayarlar.
 *
 * Kullanım:
 *   $db = Database::getInstance();
 *   $pdo = $db->getConnection();
 *   $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
 *   $stmt->execute([1]);
 */

class Database
{
    /** @var Database|null Singleton instance */
    private static ?Database $instance = null;

    /** @var PDO Veritabanı bağlantısı */
    private PDO $pdo;


    /**
     * Veritabanı yapılandırması
     * Production'da bu değerler .env veya config dosyasından okunmalı
     */
    private const CONFIG = [
        'host' => 'localhost',
        'port' => 3306,
        'dbname' => 'logsearchb',
        'charset' => 'utf8mb4',
        'user' => 'root',
        'pass' => '',
    ];

    /**
     * Discord URL - Ödemeler ve destek için yönlendirme adresi
     */
    public const DISCORD_URL = 'https://discord.gg/your_discord_invite';

    /**
     * PDO bağlantı seçenekleri
     */
    private const OPTIONS = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8mb4'",
    ];

    /**
     * Private constructor — dışarıdan new ile oluşturulamaz
     */
    private function __construct()
    {
        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=%s',
            self::CONFIG['host'],
            self::CONFIG['port'],
            self::CONFIG['dbname'],
            self::CONFIG['charset']
        );

        try {
            $this->pdo = new PDO($dsn, self::CONFIG['user'], self::CONFIG['pass'], self::OPTIONS);
        }
        catch (PDOException $e) {
            // Production'da detaylı hata mesajı göstermeyin
            error_log('[Database] Connection failed: ' . $e->getMessage());
            throw new RuntimeException('Veritabanı bağlantısı kurulamadı.');
        }
    }

    /**
     * Singleton instance al
     * @return Database
     */
    public static function getInstance(): Database
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * PDO bağlantısını döndür
     * @return PDO
     */
    public function getConnection(): PDO
    {
        return $this->pdo;
    }

    /**
     * Prepared statement çalıştır
     * @param string $sql — SQL sorgusu (parametreli)
     * @param array $params — Parametreler
     * @return PDOStatement
     */
    public function query(string $sql, array $params = []): PDOStatement
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    /**
     * Tek satır getir
     * @param string $sql
     * @param array $params
     * @return array|false
     */
    public function fetchOne(string $sql, array $params = []): array |false
    {
        return $this->query($sql, $params)->fetch();
    }

    /**
     * Tüm satırları getir
     * @param string $sql
     * @param array $params
     * @return array
     */
    public function fetchAll(string $sql, array $params = []): array
    {
        return $this->query($sql, $params)->fetchAll();
    }

    /**
     * Son eklenen kaydın ID'sini döndür
     * @return string
     */
    public function lastInsertId(): string
    {
        return $this->pdo->lastInsertId();
    }

    /**
     * Transaction başlat
     */
    public function beginTransaction(): void
    {
        $this->pdo->beginTransaction();
    }

    /**
     * Transaction onayla
     */
    public function commit(): void
    {
        $this->pdo->commit();
    }

    /**
     * Transaction geri al
     */
    public function rollBack(): void
    {
        $this->pdo->rollBack();
    }

    /**
     * Clone engelleme (Singleton)
     */
    private function __clone()
    {
    }

    /**
     * Unserialize engelleme (Singleton)
     */
    public function __wakeup()
    {
        throw new RuntimeException('Cannot unserialize singleton');
    }
}
