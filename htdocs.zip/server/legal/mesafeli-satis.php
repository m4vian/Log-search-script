<?php
/**
 * Mesafeli Satış Sözleşmesi
 * logsearch.xyz — Legal Endpoint
 */
require_once __DIR__ . '/../config/headers.php';
?>

<h2>Mesafeli Satış Sözleşmesi</h2>
<p><strong>Son Güncelleme:</strong> 01 Ocak 2026</p>

<h3>1. Taraflar</h3>
<p><strong>Satıcı:</strong></p>
<ul>
  <li>Unvan: logsearch.xyz</li>
  <li>E-posta: destek@logsearch.xyz</li>
  <li>Platform: https://logsearch.xyz</li>
</ul>
<p>
  <strong>Alıcı:</strong> Platform'a üye olan ve ücretli plan satın alan kullanıcı ("Alıcı").
  Alıcı bilgileri üyelik kaydında belirtilen bilgilerdir.
</p>

<h3>2. Sözleşmenin Konusu</h3>
<p>
  İşbu sözleşmenin konusu, Alıcı'nın Platform üzerinden satın aldığı API hizmet paketinin
  ("Hizmet") sunulmasına ilişkin tarafların hak ve yükümlülüklerinin belirlenmesidir. Bu
  sözleşme, 6502 sayılı Tüketicinin Korunması Hakkında Kanun ve Mesafeli Sözleşmeler
  Yönetmeliği hükümleri çerçevesinde düzenlenmiştir.
</p>

<h3>3. Hizmet Bilgileri</h3>
<ul>
  <li><strong>Hizmet Türü:</strong> API tabanlı log arama ve sorgulama hizmeti</li>
  <li><strong>Plan Detayları:</strong> Seçilen plana göre belirlenen istek kotası, API anahtarı sayısı ve saklama süresi</li>
  <li><strong>Süre:</strong> Aylık abonelik (otomatik yenileme)</li>
  <li><strong>Fiyat:</strong> Seçilen plana göre belirlenir (KDV dahil)</li>
</ul>

<h3>4. Ödeme</h3>
<ul>
  <li>Ödeme, seçilen ödeme yöntemi ile (kredi kartı / banka kartı) gerçekleştirilir.</li>
  <li>Abonelik her dönem başında otomatik olarak yenilenir.</li>
  <li>Fiyat değişiklikleri en az 30 gün önceden bildirilir.</li>
  <li>Ödeme bilgileri güvenli ödeme altyapısı tarafından işlenir; Platform tarafından saklanmaz.</li>
</ul>

<h3>5. Teslimat</h3>
<p>
  Hizmet dijital ortamda sunulmakta olup, ödemenin onaylanmasının ardından anında
  aktif hale gelir. API anahtarı ve erişim bilgileri Dashboard üzerinden sağlanır.
</p>

<h3>6. Cayma Hakkı</h3>
<p>
  Mesafeli Sözleşmeler Yönetmeliği'nin 15/ğ maddesi gereğince, dijital içerik teslimi
  başladıktan sonra cayma hakkı kullanılamaz. Ancak Platform'un İptal & İade Politikası
  kapsamındaki koşullar saklıdır.
</p>

<h3>7. Tarafların Yükümlülükleri</h3>
<h4>7.1. Satıcının Yükümlülükleri</h4>
<ul>
  <li>Hizmeti, seçilen plan kapsamında sunmak</li>
  <li>Hizmet kesintilerini en aza indirmek ve bildirmek</li>
  <li>Alıcı verilerini gizlilik politikası kapsamında korumak</li>
  <li>Teknik destek sağlamak</li>
</ul>

<h4>7.2. Alıcının Yükümlülükleri</h4>
<ul>
  <li>Doğru ve güncel bilgiler sağlamak</li>
  <li>Hizmeti kullanım koşullarına uygun şekilde kullanmak</li>
  <li>API anahtarlarının güvenliğini sağlamak</li>
  <li>Ödeme yükümlülüklerini zamanında yerine getirmek</li>
</ul>

<h3>8. Uyuşmazlık Çözümü</h3>
<p>
  İşbu sözleşmeden doğan uyuşmazlıklarda Türkiye Cumhuriyeti kanunları uygulanır.
  Tüketici şikayetleri için Tüketici Hakem Heyetleri ve Tüketici Mahkemeleri yetkilidir.
</p>

<h3>9. Yürürlük</h3>
<p>
  Bu sözleşme, Alıcı'nın ücretli plan satın alması ile birlikte yürürlüğe girer.
</p>
