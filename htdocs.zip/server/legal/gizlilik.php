<?php
/**
 * Gizlilik Politikası
 * logsearch.xyz — Legal Endpoint
 */
require_once __DIR__ . '/../config/headers.php';
?>

<h2>Gizlilik Politikası</h2>
<p><strong>Son Güncelleme:</strong> 01 Ocak 2026</p>

<h3>1. Giriş</h3>
<p>
  logsearch.xyz ("Platform") olarak gizliliğinize değer veriyoruz. Bu politika, Platform'u
  kullanırken toplanan bilgilerin nasıl işlendiğini, saklandığını ve korunduğunu açıklamaktadır.
</p>

<h3>2. Toplanan Bilgiler</h3>
<h4>2.1. Doğrudan Sağladığınız Bilgiler</h4>
<ul>
  <li>Kayıt sırasında: ad, soyad, e-posta adresi</li>
  <li>Ödeme sırasında: fatura bilgileri (ödeme kartı bilgileri doğrudan işlenmez, üçüncü taraf ödeme sağlayıcısı kullanılır)</li>
  <li>Destek talepleri sırasında ilettiğiniz bilgiler</li>
</ul>

<h4>2.2. Otomatik Olarak Toplanan Bilgiler</h4>
<ul>
  <li>IP adresi ve tarayıcı bilgileri</li>
  <li>Erişim zaman damgaları</li>
  <li>API kullanım verileri (endpoint, istek sayısı, yanıt süreleri)</li>
  <li>Çerez bilgileri (oturum yönetimi amacıyla)</li>
</ul>

<h3>3. Bilgilerin Kullanım Amaçları</h3>
<ul>
  <li>Hizmetlerimizi sunmak ve iyileştirmek</li>
  <li>Hesabınızı yönetmek ve güvenliğini sağlamak</li>
  <li>Teknik destek sağlamak</li>
  <li>Kullanım istatistikleri oluşturmak</li>
  <li>Yasal yükümlülükleri yerine getirmek</li>
  <li>Hizmet hakkında bilgilendirme yapmak (onayınız dahilinde)</li>
</ul>

<h3>4. Çerezler</h3>
<p>
  Platform, oturum yönetimi için zorunlu çerezler kullanır. Analitik veya pazarlama amaçlı
  üçüncü taraf çerezleri kullanılmamaktadır.
</p>

<h3>5. Veri Güvenliği</h3>
<p>
  Verilerinizi korumak için endüstri standardı güvenlik önlemleri uygulamaktayız:
</p>
<ul>
  <li>SSL/TLS şifreleme (tüm iletişim HTTPS üzerinden)</li>
  <li>Şifrelerin bcrypt ile hashlanması</li>
  <li>Düzenli güvenlik denetimleri</li>
  <li>Erişim kontrolü ve yetkilendirme mekanizmaları</li>
  <li>Veritabanı şifreleme</li>
</ul>

<h3>6. Üçüncü Taraf Paylaşımları</h3>
<p>
  Kişisel verileriniz, açık rızanız olmadan üçüncü taraflarla paylaşılmaz. Ancak aşağıdaki
  durumlarda paylaşım yapılabilir:
</p>
<ul>
  <li>Yasal zorunluluklar (mahkeme kararı, resmi kurum talebi)</li>
  <li>Ödeme işlemleri için ödeme hizmeti sağlayıcıları</li>
  <li>Altyapı hizmetleri için sunucu sağlayıcıları (veriler şifreli aktarılır)</li>
</ul>

<h3>7. Veri Saklama</h3>
<p>
  Kişisel verileriniz, hizmetin sunulması için gerekli olan süre boyunca saklanır. Hesap
  silme talebiniz üzerine, yasal saklama yükümlülükleri hariç tüm veriler 90 gün içinde
  kalıcı olarak silinir.
</p>

<h3>8. Haklarınız</h3>
<p>
  Verilerinize erişim, düzeltme, silme ve taşınabilirlik hakları dahil olmak üzere yasal
  haklarınızı kullanmak için <strong>gizlilik@logsearch.xyz</strong> adresine başvurabilirsiniz.
</p>

<h3>9. Politika Değişiklikleri</h3>
<p>
  Bu gizlilik politikası gerektiğinde güncellenebilir. Önemli değişiklikler e-posta ile
  bildirilir.
</p>
