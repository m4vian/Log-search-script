<?php
/**
 * Üyelik Sözleşmesi
 * logsearch.xyz — Legal Endpoint
 */
require_once __DIR__ . '/../config/headers.php';
?>

<h2>Üyelik Sözleşmesi</h2>
<p><strong>Son Güncelleme:</strong> 01 Ocak 2026</p>

<h3>1. Taraflar</h3>
<p>
  İşbu üyelik sözleşmesi, logsearch.xyz ("Platform") ile Platform'a üye olan kullanıcı ("Üye")
  arasında, üyelik kaydının tamamlanmasıyla birlikte yürürlüğe girer.
</p>

<h3>2. Sözleşmenin Konusu</h3>
<p>
  Bu sözleşme, Üye'nin Platform hizmetlerinden yararlanma koşullarını ve tarafların karşılıklı
  hak ve yükümlülüklerini düzenler.
</p>

<h3>3. Üyelik Koşulları</h3>
<ul>
  <li>Üye olmak için 18 yaşını doldurmuş olmak gerekmektedir.</li>
  <li>Üyelik kaydı sırasında verilen bilgilerin doğru ve güncel olması zorunludur.</li>
  <li>Her gerçek veya tüzel kişi yalnızca bir hesap açabilir.</li>
  <li>Üyelik kişiye özeldir ve devredilemez.</li>
</ul>

<h3>4. Üye'nin Hak ve Yükümlülükleri</h3>
<ul>
  <li>Platform hizmetlerini kullanım koşullarına uygun şekilde kullanmak</li>
  <li>Hesap bilgilerini gizli tutmak ve güvenliğini sağlamak</li>
  <li>Hesabı üzerinden gerçekleştirilen tüm işlemlerden sorumlu olmak</li>
  <li>API anahtarlarını güvenli şekilde saklamak</li>
  <li>Ücretli plan kullanılıyorsa ödeme yükümlülüklerini zamanında yerine getirmek</li>
  <li>Platform'un teknik altyapısına zarar verecek davranışlardan kaçınmak</li>
</ul>

<h3>5. Platform'un Hak ve Yükümlülükleri</h3>
<ul>
  <li>Hizmeti planlanan kapsamda sunmak</li>
  <li>Üye verilerini gizlilik politikası kapsamında korumak</li>
  <li>Bakım ve güncelleme çalışmaları hakkında önceden bilgilendirmek</li>
  <li>Hizmet kalitesini sürekli iyileştirmek</li>
  <li>Kullanım koşullarını ihlal eden hesapları askıya alma veya feshetme hakkını saklı tutmak</li>
</ul>

<h3>6. Hizmet Kapsamı</h3>
<p>
  Üyelik ile sunulan hizmetler, seçilen plana göre değişiklik gösterir. Ücretsiz plan
  kullanıcıları temel API erişimine sahipken, ücretli plan kullanıcıları genişletilmiş
  kota ve ek özelliklerden faydalanır.
</p>

<h3>7. Üyelik Süresi ve Fesih</h3>
<ul>
  <li>Üyelik süresiz olarak geçerlidir.</li>
  <li>Üye, istediği zaman hesabını silerek üyeliğini sonlandırabilir.</li>
  <li>Platform, kullanım koşullarının ihlali halinde üyeliği tek taraflı feshedebilir.</li>
  <li>Fesih durumunda aktif abonelikler için İptal & İade Politikası geçerlidir.</li>
</ul>

<h3>8. Mücbir Sebep</h3>
<p>
  Doğal afet, savaş, terör, grev, altyapı arızası, yasal düzenlemeler gibi öngörülemez
  ve önlenemez durumlar mücbir sebep sayılır. Mücbir sebep süresince tarafların
  yükümlülükleri askıya alınır.
</p>

<h3>9. Uygulanacak Hukuk</h3>
<p>
  İşbu sözleşme Türkiye Cumhuriyeti kanunlarına tabi olup, uyuşmazlıklarda Türkiye
  Cumhuriyeti mahkemeleri yetkilidir.
</p>

<h3>10. İletişim</h3>
<p>
  Üyelik sözleşmesi hakkında sorularınız için <strong>destek@logsearch.xyz</strong> adresine
  e-posta gönderebilirsiniz.
</p>
