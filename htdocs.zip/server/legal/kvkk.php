<?php
/**
 * KVKK Aydınlatma Metni
 * logsearch.xyz — Legal Endpoint
 */
require_once __DIR__ . '/../config/headers.php';
?>

<h2>KVKK Aydınlatma Metni</h2>
<p><strong>Son Güncelleme:</strong> 01 Ocak 2026</p>

<h3>1. Veri Sorumlusu</h3>
<p>
  logsearch.xyz ("Platform") olarak, 6698 sayılı Kişisel Verilerin Korunması Kanunu ("KVKK") kapsamında,
  kişisel verilerinizin korunmasına büyük önem veriyoruz. İşbu aydınlatma metni, kişisel verilerinizin
  işlenme amaçları, hukuki sebepleri, toplanma yöntemleri ve haklarınız hakkında bilgilendirme amacıyla
  hazırlanmıştır.
</p>

<h3>2. İşlenen Kişisel Veriler</h3>
<p>Platform üzerinden aşağıdaki kişisel veriler işlenmektedir:</p>
<ul>
  <li><strong>Kimlik Bilgileri:</strong> Ad, soyad</li>
  <li><strong>İletişim Bilgileri:</strong> E-posta adresi</li>
  <li><strong>İşlem Güvenliği:</strong> IP adresi, şifre (hashlenmiş), oturum bilgileri</li>
  <li><strong>Kullanım Verileri:</strong> API kullanım logları, istek sayıları, erişim zaman damgaları</li>
  <li><strong>Finansal Bilgiler:</strong> Fatura bilgileri, ödeme geçmişi (ödeme bilgileri üçüncü taraf ödeme altyapısı tarafından işlenir)</li>
</ul>

<h3>3. Kişisel Verilerin İşlenme Amaçları</h3>
<ul>
  <li>Üyelik kaydının oluşturulması ve hesap yönetimi</li>
  <li>API hizmetlerinin sunulması ve yönetimi</li>
  <li>Kullanım istatistiklerinin oluşturulması</li>
  <li>Fatura ve ödeme işlemlerinin yürütülmesi</li>
  <li>Hizmet kalitesinin artırılması</li>
  <li>Yasal yükümlülüklerin yerine getirilmesi</li>
  <li>Bilgi güvenliği süreçlerinin yürütülmesi</li>
</ul>

<h3>4. Kişisel Verilerin Aktarılması</h3>
<p>
  Kişisel verileriniz; yasal yükümlülüklerimiz çerçevesinde yetkili kamu kurum ve kuruluşlarına,
  ödeme hizmetleri için anlaşmalı ödeme kuruluşlarına ve hizmet alınan sunucu/altyapı sağlayıcılarına
  aktarılabilir.
</p>

<h3>5. Veri Saklama Süresi</h3>
<p>
  Kişisel verileriniz, işlenme amaçlarının gerektirdiği süre boyunca ve yasal saklama süreleri
  dahilinde muhafaza edilir. Hesap silindiğinde, yasal saklama süreleri haricindeki veriler
  90 gün içerisinde silinir.
</p>

<h3>6. Haklarınız</h3>
<p>KVKK'nın 11. maddesi kapsamında aşağıdaki haklara sahipsiniz:</p>
<ul>
  <li>Kişisel verilerinizin işlenip işlenmediğini öğrenme</li>
  <li>İşlenmişse buna ilişkin bilgi talep etme</li>
  <li>İşlenme amacını ve amacına uygun kullanılıp kullanılmadığını öğrenme</li>
  <li>Yurt içinde veya yurt dışında aktarıldığı üçüncü kişileri bilme</li>
  <li>Eksik veya yanlış işlenmişse düzeltilmesini isteme</li>
  <li>KVKK'nın 7. maddesindeki şartlar çerçevesinde silinmesini isteme</li>
  <li>İşlenen verilerin münhasıran otomatik sistemler vasıtasıyla analiz edilmesi suretiyle aleyhinize bir sonucun ortaya çıkmasına itiraz etme</li>
</ul>

<h3>7. İletişim</h3>
<p>
  KVKK kapsamındaki talepleriniz için <strong>kvkk@logsearch.xyz</strong> adresine e-posta
  gönderebilirsiniz.
</p>
