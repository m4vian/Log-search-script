<?php
/**
 * Kullanım Koşulları
 * logsearch.xyz — Legal Endpoint
 */
require_once __DIR__ . '/../config/headers.php';
?>

<h2>Kullanım Koşulları</h2>
<p><strong>Son Güncelleme:</strong> 01 Ocak 2026</p>

<h3>1. Kabul</h3>
<p>
  logsearch.xyz ("Platform") hizmetlerini kullanarak işbu kullanım koşullarını kabul etmiş
  sayılırsınız. Bu koşulları kabul etmiyorsanız Platform'u kullanmamanız gerekmektedir.
</p>

<h3>2. Hizmet Tanımı</h3>
<p>
  Platform, API tabanlı log arama ve sorgulama hizmeti sunmaktadır. Kullanıcılar, API
  anahtarları aracılığıyla REST API üzerinden log verilerini sorgulayabilir ve yönetebilir.
</p>

<h3>3. Hesap Oluşturma</h3>
<ul>
  <li>Hesap oluşturmak için 18 yaşından büyük olmalısınız.</li>
  <li>Doğru ve güncel bilgiler sağlamakla yükümlüsünüz.</li>
  <li>Hesap güvenliğinizden siz sorumlusunuz.</li>
  <li>Hesap bilgilerinizi üçüncü kişilerle paylaşmamalısınız.</li>
  <li>Her kullanıcının yalnızca bir hesabı olmalıdır.</li>
</ul>

<h3>4. Kabul Edilebilir Kullanım</h3>
<p>Platform'u kullanırken aşağıdaki kurallara uymalısınız:</p>
<ul>
  <li>API'yi yasadışı amaçlarla kullanmamak</li>
  <li>Diğer kullanıcıların hizmet almasını engelleyecek davranışlarda bulunmamak</li>
  <li>Kısıtlamaları aşmaya çalışmamak (rate limit bypass, brute force vb.)</li>
  <li>Zararlı içerik göndermemek veya güvenlik açıklarını istismar etmemek</li>
  <li>API anahtarlarını gizli tutmak ve yetkisiz paylaşım yapmamak</li>
  <li>Ters mühendislik, scraping veya otomatik istismar yapmamak</li>
</ul>

<h3>5. API Kullanım Limitleri</h3>
<ul>
  <li>Her plan için belirlenen istek limitleri geçerlidir.</li>
  <li>Limit aşımında istekler geçici olarak reddedilir (HTTP 429).</li>
  <li>Sürekli limit aşımı durumunda hesap askıya alınabilir.</li>
  <li>Limit bilgilerini Dashboard üzerinden kontrol edebilirsiniz.</li>
</ul>

<h3>6. Fikri Mülkiyet</h3>
<p>
  Platform'un tasarımı, kodu, logosu, içeriği ve altyapısı üzerindeki tüm fikri mülkiyet
  hakları logsearch.xyz'ye aittir. Yazılı izin olmaksızın kopyalanamaz, dağıtılamaz veya
  değiştirilemez.
</p>

<h3>7. Sorumluluk Sınırı</h3>
<ul>
  <li>Platform, hizmet kesintilerinden doğan doğrudan veya dolaylı zararlardan sorumlu değildir.</li>
  <li>Platform, "olduğu gibi" (as-is) sunulmaktadır.</li>
  <li>Sorumluluk, ilgili dönemde ödenen hizmet bedeli ile sınırlıdır.</li>
</ul>

<h3>8. Hesap Askıya Alma ve Fesih</h3>
<p>
  Kullanım koşullarının ihlali durumunda, Platform hesabınızı önceden bildirim yapmaksızın
  askıya alabilir veya feshedebilir. Bu durumda ödemiş olduğunuz bedeller iade edilmez.
</p>

<h3>9. Koşul Değişiklikleri</h3>
<p>
  Bu koşullar gerektiğinde güncellenebilir. Önemli değişiklikler en az 15 gün önceden
  e-posta ile bildirilir. Değişiklik sonrası Platform'u kullanmaya devam etmeniz, yeni
  koşulları kabul ettiğiniz anlamına gelir.
</p>

<h3>10. İletişim</h3>
<p>
  Kullanım koşulları hakkında sorularınız için <strong>destek@logsearch.xyz</strong> adresine
  e-posta gönderebilirsiniz.
</p>
