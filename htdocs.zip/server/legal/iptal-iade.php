<?php
/**
 * İptal & İade Politikası
 * logsearch.xyz — Legal Endpoint
 */
require_once __DIR__ . '/../config/headers.php';
?>

<h2>İptal & İade Politikası</h2>
<p><strong>Son Güncelleme:</strong> 01 Ocak 2026</p>

<h3>1. Genel Bilgi</h3>
<p>
  logsearch.xyz ("Platform") tarafından sunulan API hizmetleri dijital içerik niteliğindedir.
  Bu politika, Platform üzerinden satın alınan hizmetlerin iptal ve iade koşullarını
  düzenlemektedir.
</p>

<h3>2. Ücretsiz Plan</h3>
<p>
  Ücretsiz plan kullanıcıları herhangi bir ödeme yapmadığından, iptal veya iade talebi söz konusu
  değildir. Hesabınızı istediğiniz zaman silebilirsiniz.
</p>

<h3>3. Ücretli Planlar</h3>
<h4>3.1. Abonelik İptali</h4>
<ul>
  <li>Ücretli plan aboneliklerinizi istediğiniz zaman Dashboard üzerinden iptal edebilirsiniz.</li>
  <li>İptal işlemi, mevcut fatura döneminin sonunda geçerli olur.</li>
  <li>İptal tarihine kadar olan süre boyunca hizmetleriniz aktif kalır.</li>
  <li>İptal sonrası hesabınız otomatik olarak ücretsiz plana geçirilir.</li>
</ul>

<h4>3.2. İade Koşulları</h4>
<ul>
  <li>Satın alma tarihinden itibaren <strong>14 gün</strong> içinde, hizmeti kullanmamış olmanız (API isteklerinin %10'undan azı kullanılmışsa) kaydıyla tam iade talep edebilirsiniz.</li>
  <li>14 günü aşan veya aktif olarak kullanılan hizmetler için iade yapılmaz.</li>
  <li>İade talepleri <strong>destek@logsearch.xyz</strong> adresine e-posta ile iletilmelidir.</li>
  <li>Onaylanan iadeler, ödemenin yapıldığı yöntem üzerinden <strong>10 iş günü</strong> içinde gerçekleştirilir.</li>
</ul>

<h3>4. Hizmet Kesintileri</h3>
<p>
  Platform kaynaklı uzun süreli hizmet kesintilerinde (24 saatten fazla), kesinti süresine
  karşılık gelen tutar bir sonraki fatura dönemine kredi olarak yansıtılır.
</p>

<h3>5. Cayma Hakkı</h3>
<p>
  6502 sayılı Tüketicinin Korunması Hakkında Kanun ve Mesafeli Sözleşmeler Yönetmeliği gereğince,
  dijital içerik teslimi başladıktan sonra cayma hakkı kullanılamaz. Ancak yukarıdaki iade
  koşulları geçerlidir.
</p>

<h3>6. İletişim</h3>
<p>
  İptal ve iade talepleriniz için <strong>destek@logsearch.xyz</strong> adresine e-posta
  gönderebilirsiniz.
</p>
