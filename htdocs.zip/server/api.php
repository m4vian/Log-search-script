<?php
/**
 * api.php — Merkezi API Endpoint
 * logsearch.xyz
 *
 * Tüm frontend istekleri bu dosya üzerinden işlenir.
 * ?action=xxx parametresi ile hangi işlemin yapılacağı belirlenir.
 *
 * Desteklenen eylemler:
 *   POST  register        — Yeni kullanıcı kaydı
 *   POST  login           — Kullanıcı girişi
 *   POST  logout          — Oturum sonlandırma
 *   GET   me              — Oturumdaki kullanıcı bilgisi
 *   GET   dashboard       — Dashboard istatistikleri
 *   GET   keys            — API anahtarları listesi
 *   POST  create_key      — Yeni API anahtarı oluştur
 *   POST  revoke_key      — API anahtarını iptal et
 *   GET   usage           — Kullanım istatistikleri
 *   GET   notifications   — Bildirim listesi
 *   GET   balance_history — Bakiye hareketleri
 */

// ─── Hata ayıklama (prod'da kapatılmalı) ────────────────
error_reporting(E_ALL);
ini_set('display_errors', 0);

// ─── Session ────────────────────────────────────────────
session_start();

// ─── CORS & Headers ─────────────────────────────────────
header('Content-Type: application/json; charset=UTF-8');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Cache-Control: no-cache, no-store, must-revalidate');

// ─── Preflight ──────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ─── Veritabanı Bağlantısı ─────────────────────────────
require_once __DIR__ . '/database/Database.php';

try {
    $db = Database::getInstance();
} catch (Exception $e) {
    jsonError('Veritabanı bağlantı hatası.', 500);
}

// ─── Yardımcı Fonksiyonlar ──────────────────────────────

function jsonResponse(mixed $data, int $status = 200): never {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

function jsonSuccess(mixed $data = null, string $message = 'Başarılı', int $status = 200): never {
    jsonResponse([
        'success' => true,
        'message' => $message,
        'data'    => $data,
    ], $status);
}

function jsonError(string $message, int $status = 400, mixed $data = null): never {
    jsonResponse([
        'success' => false,
        'message' => $message,
        'data'    => $data,
    ], $status);
}

function getJsonInput(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function requireAuth(): array {
    if (empty($_SESSION['user_id'])) {
        jsonError('Oturum açmanız gerekiyor.', 401);
    }
    global $db;
    $user = $db->fetchOne('SELECT id, name, email, balance, plan_id, role, status FROM users WHERE id = ?', [$_SESSION['user_id']]);
    if (!$user) {
        unset($_SESSION['user_id']);
        jsonError('Kullanıcı bulunamadı.', 401);
    }
    if ($user['status'] !== 'active') {
        unset($_SESSION['user_id']);
        jsonError('Hesabınız askıya alınmış.', 403);
    }
    return $user;
}

function requireAdmin(): array {
    $user = requireAuth();
    if ($user['role'] !== 'admin') {
        jsonError('Yetkisiz erişim.', 403);
    }
    return $user;
}

function generateApiKey(): array {
    $raw    = 'ls_' . bin2hex(random_bytes(16));
    $prefix = substr($raw, 0, 12);
    $hash   = hash('sha256', $raw);
    return ['raw' => $raw, 'prefix' => $prefix, 'hash' => $hash];
}


// ─── Router ─────────────────────────────────────────────
$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

switch ($action) {

    // ══════════════════════════════════════════════
    // PUBLIC: Arama (Logs)
    // ══════════════════════════════════════════════
    case 'search':
        if ($method !== 'GET') jsonError('Method not allowed.', 405);
        $user = requireAuth();
        $query = trim($_GET['q'] ?? '');
        
        if (!$query) {
            jsonSuccess(['results' => [], 'total' => 0]);
        }

        $logsDir = __DIR__ . '/logs/';
        $files = glob($logsDir . '*.txt');
        $results = [];
        $totalMatches = 0;

        foreach ($files as $file) {
            if (!is_readable($file)) continue;
            $handle = fopen($file, 'r');
            if ($handle) {
                while (($line = fgets($handle)) !== false) {
                    if (str_contains(strtolower($line), strtolower($query))) {
                        $results[] = trim($line);
                        $totalMatches++;
                        if ($totalMatches >= 500) break 2;
                    }
                }
                fclose($handle);
            }
        }

        // Usage log — Search category can be deducted from balance or just logged
        $db->query(
            'INSERT INTO usage_logs (user_id, endpoint, method, status_code, response_time_ms, request_ip, request_payload) VALUES (?, ?, "GET", 200, 0, ?, ?)',
            [$user['id'], 'search', $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0', $query]
        );

        jsonSuccess(['results' => $results, 'total' => $totalMatches]);
        break;

    // ══════════════════════════════════════════════
    // PUBLIC: Genel Konfigürasyon
    // ══════════════════════════════════════════════
    case 'get_config':
        if ($method !== 'GET') jsonError('Method not allowed.', 405);
        jsonSuccess(['discord_url' => Database::DISCORD_URL]);
        break;

    // ══════════════════════════════════════════════
    // PUBLIC: Planları Getir
    // ══════════════════════════════════════════════
    case 'get_plans':
        if ($method !== 'GET') jsonError('Method not allowed.', 405);
        $plans = $db->fetchAll("SELECT * FROM plans WHERE is_active = 1 ORDER BY sort_order ASC");
        jsonSuccess(['plans' => $plans]);
        break;

    // ══════════════════════════════════════════════
    // AUTH: Kayıt
    // ══════════════════════════════════════════════
    case 'register':
        if ($method !== 'POST') jsonError('Method not allowed.', 405);

        $input = getJsonInput();
        $name     = trim($input['name'] ?? '');
        $email    = trim($input['email'] ?? '');
        $password = $input['password'] ?? '';

        // Validation
        if (!$name || !$email || !$password) {
            jsonError('Lütfen tüm alanları doldurun.');
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            jsonError('Geçerli bir e-posta adresi girin.');
        }
        if (strlen($password) < 8) {
            jsonError('Şifre en az 8 karakter olmalıdır.');
        }

        // E-posta benzersizlik
        $exists = $db->fetchOne('SELECT id FROM users WHERE email = ?', [$email]);
        if ($exists) {
            jsonError('Bu e-posta adresi zaten kayıtlı.');
        }

        // Ücretsiz plan ID'si
        $freePlan = $db->fetchOne("SELECT id FROM plans WHERE slug = 'free'");
        $planId   = $freePlan ? $freePlan['id'] : null;

        // Hoş geldin bonusu
        $bonusSetting = $db->fetchOne("SELECT `value` FROM settings WHERE `key` = 'free_balance_bonus'");
        $bonus = $bonusSetting ? (float) $bonusSetting['value'] : 0;

        // Kullanıcı oluştur
        $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
        $db->query(
            'INSERT INTO users (name, email, password_hash, balance, plan_id, role, status, email_verified_at, terms_accepted_at, kvkk_accepted_at) VALUES (?, ?, ?, ?, ?, "user", "active", NOW(), NOW(), NOW())',
            [$name, $email, $hash, $bonus, $planId]
        );
        $userId = $db->lastInsertId();

        // Bonus bakiye hareketi
        if ($bonus > 0) {
            $db->query(
                'INSERT INTO balance_transactions (user_id, amount, type, category, description, balance_before, balance_after) VALUES (?, ?, "credit", "bonus", "Hoş geldin bonusu", 0.00, ?)',
                [$userId, $bonus, $bonus]
            );
        }

        // Hoş geldin bildirimi
        $db->query(
            'INSERT INTO notifications (user_id, type, title, message) VALUES (?, "system", "Hoş Geldiniz!", "logsearch.xyz ailesine hoş geldiniz. İlk API anahtarınızı oluşturarak başlayın.")',
            [$userId]
        );

        // Varsayılan API anahtarı
        $key = generateApiKey();
        $db->query(
            'INSERT INTO api_keys (user_id, name, key_hash, prefix, status) VALUES (?, "Varsayılan", ?, ?, "active")',
            [$userId, $key['hash'], $key['prefix']]
        );

        // Otomatik giriş
        $_SESSION['user_id'] = $userId;

        jsonSuccess([
            'user' => [
                'id'      => (int) $userId,
                'name'    => $name,
                'email'   => $email,
                'balance' => $bonus,
                'role'    => 'user',
            ],
            'first_api_key' => $key['raw'],
        ], 'Hesabınız başarıyla oluşturuldu!');
        break;

    // ══════════════════════════════════════════════
    // AUTH: Giriş
    // ══════════════════════════════════════════════
    case 'login':
        if ($method !== 'POST') jsonError('Method not allowed.', 405);

        $input = getJsonInput();
        $email    = trim($input['email'] ?? '');
        $password = $input['password'] ?? '';

        if (!$email || !$password) {
            jsonError('Lütfen tüm alanları doldurun.');
        }

        $user = $db->fetchOne('SELECT id, name, email, password_hash, balance, plan_id, role, status FROM users WHERE email = ?', [$email]);

        // Login log (başarısız)
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';

        if (!$user || !password_verify($password, $user['password_hash'])) {
            $db->query(
                'INSERT INTO login_logs (user_id, email, ip_address, user_agent, status, failure_reason) VALUES (?, ?, ?, ?, "failed", "Geçersiz kimlik bilgileri")',
                [$user['id'] ?? null, $email, $ip, $ua]
            );
            jsonError('E-posta veya şifre hatalı.', 401);
        }

        if ($user['status'] !== 'active') {
            $db->query(
                'INSERT INTO login_logs (user_id, email, ip_address, user_agent, status, failure_reason) VALUES (?, ?, ?, ?, "blocked", "Hesap askıda")',
                [$user['id'], $email, $ip, $ua]
            );
            jsonError('Hesabınız askıya alınmış. Destek ile iletişime geçin.', 403);
        }

        // Başarılı giriş
        $_SESSION['user_id'] = $user['id'];

        $db->query('UPDATE users SET last_login_at = NOW(), last_login_ip = ? WHERE id = ?', [$ip, $user['id']]);
        $db->query(
            'INSERT INTO login_logs (user_id, email, ip_address, user_agent, status) VALUES (?, ?, ?, ?, "success")',
            [$user['id'], $email, $ip, $ua]
        );

        jsonSuccess([
            'user' => [
                'id'      => (int) $user['id'],
                'name'    => $user['name'],
                'email'   => $user['email'],
                'balance' => (float) $user['balance'],
                'role'    => $user['role'],
            ],
        ], 'Başarıyla giriş yapıldı!');
        break;

    // ══════════════════════════════════════════════
    // AUTH: Çıkış
    // ══════════════════════════════════════════════
    case 'logout':
        if ($method !== 'POST') jsonError('Method not allowed.', 405);
        $_SESSION = [];
        session_destroy();
        jsonSuccess(null, 'Oturum sonlandırıldı.');
        break;

    // ══════════════════════════════════════════════
    // AUTH: Mevcut Kullanıcı
    // ══════════════════════════════════════════════
    case 'me':
        $user = requireAuth();

        // Plan bilgisi
        $plan = null;
        if ($user['plan_id']) {
            $plan = $db->fetchOne('SELECT slug, name, requests_per_day, requests_per_min, max_keys FROM plans WHERE id = ?', [$user['plan_id']]);
        }

        // Okunmamış bildirim sayısı
        $unread = $db->fetchOne('SELECT COUNT(*) as cnt FROM notifications WHERE user_id = ? AND is_read = 0', [$user['id']]);

        jsonSuccess([
            'user' => [
                'id'      => (int) $user['id'],
                'name'    => $user['name'],
                'email'   => $user['email'],
                'balance' => (float) $user['balance'],
                'role'    => $user['role'],
            ],
            'plan'                => $plan,
            'unread_notifications' => (int) ($unread['cnt'] ?? 0),
        ]);
        break;

    // ══════════════════════════════════════════════
    // DASHBOARD: İstatistikler
    // ══════════════════════════════════════════════
    case 'dashboard':
        $user = requireAuth();
        $uid  = $user['id'];

        // Toplam istek sayısı
        $totalReqs = $db->fetchOne('SELECT COUNT(*) as cnt FROM usage_logs WHERE user_id = ?', [$uid]);

        // Bu haftaki istek sayısı
        $weekReqs = $db->fetchOne('SELECT COUNT(*) as cnt FROM usage_logs WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)', [$uid]);

        // Geçen haftaki istek sayısı (karşılaştırma)
        $lastWeekReqs = $db->fetchOne('SELECT COUNT(*) as cnt FROM usage_logs WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 14 DAY) AND created_at < DATE_SUB(NOW(), INTERVAL 7 DAY)', [$uid]);

        // Haftalık değişim yüzdesi
        $weekChange = 0;
        if (($lastWeekReqs['cnt'] ?? 0) > 0) {
            $weekChange = round((($weekReqs['cnt'] - $lastWeekReqs['cnt']) / $lastWeekReqs['cnt']) * 100, 1);
        }

        // Aktif anahtar sayısı
        $activeKeys = $db->fetchOne('SELECT COUNT(*) as cnt FROM api_keys WHERE user_id = ? AND status = "active"', [$uid]);

        // Başarı oranı
        $successRate = $db->fetchOne('SELECT ROUND(AVG(CASE WHEN status_code < 400 THEN 100 ELSE 0 END), 1) as rate FROM usage_logs WHERE user_id = ?', [$uid]);

        // Ortalama yanıt süresi
        $avgResponse = $db->fetchOne('SELECT ROUND(AVG(response_time_ms)) as avg_ms FROM usage_logs WHERE user_id = ?', [$uid]);

        // Son 10 aktivite
        $recentActivity = $db->fetchAll(
            'SELECT endpoint, method, status_code, response_time_ms, created_at FROM usage_logs WHERE user_id = ? ORDER BY created_at DESC LIMIT 10',
            [$uid]
        );

        // Bakiye
        $balance = (float) $user['balance'];

        // Plan bilgisi
        $plan = null;
        $dailyLimit = 100;
        if ($user['plan_id']) {
            $plan = $db->fetchOne('SELECT name, slug, requests_per_day FROM plans WHERE id = ?', [$user['plan_id']]);
            if ($plan && $plan['requests_per_day']) {
                $dailyLimit = (int) $plan['requests_per_day'];
            }
        }

        // Bugünkü istek sayısı
        $todayReqs = $db->fetchOne('SELECT COUNT(*) as cnt FROM usage_logs WHERE user_id = ? AND created_at >= CURDATE()', [$uid]);

        jsonSuccess([
            'stats' => [
                'total_requests'  => (int) ($totalReqs['cnt'] ?? 0),
                'today_requests'  => (int) ($todayReqs['cnt'] ?? 0),
                'daily_limit'     => $dailyLimit,
                'week_requests'   => (int) ($weekReqs['cnt'] ?? 0),
                'week_change'     => $weekChange,
                'active_keys'     => (int) ($activeKeys['cnt'] ?? 0),
                'success_rate'    => (float) ($successRate['rate'] ?? 100),
                'avg_response_ms' => (int) ($avgResponse['avg_ms'] ?? 0),
                'balance'         => $balance,
            ],
            'plan'            => $plan,
            'recent_activity' => $recentActivity,
        ]);
        break;

    // ══════════════════════════════════════════════
    // API ANAHTARLARI: Listele
    // ══════════════════════════════════════════════
    case 'keys':
        $user = requireAuth();

        $keys = $db->fetchAll(
            'SELECT id, name, prefix, status, last_used_at, last_used_ip, created_at, revoked_at FROM api_keys WHERE user_id = ? ORDER BY created_at DESC',
            [$user['id']]
        );

        jsonSuccess(['keys' => $keys]);
        break;

    // ══════════════════════════════════════════════
    // API ANAHTARLARI: Oluştur
    // ══════════════════════════════════════════════
    case 'create_key':
        if ($method !== 'POST') jsonError('Method not allowed.', 405);

        $user  = requireAuth();
        $input = getJsonInput();
        $name  = trim($input['name'] ?? '') ?: 'Anahtar ' . date('d.m.Y H:i');

        // Plan limiti kontrol
        $plan = null;
        if ($user['plan_id']) {
            $plan = $db->fetchOne('SELECT max_keys FROM plans WHERE id = ?', [$user['plan_id']]);
        }
        $maxKeys = $plan ? (int) $plan['max_keys'] : 1;

        $currentCount = $db->fetchOne('SELECT COUNT(*) as cnt FROM api_keys WHERE user_id = ? AND status = "active"', [$user['id']]);
        if (((int) $currentCount['cnt']) >= $maxKeys) {
            jsonError("Plan limitinize ulaştınız. Maksimum {$maxKeys} aktif anahtar oluşturabilirsiniz.");
        }

        $key = generateApiKey();
        $db->query(
            'INSERT INTO api_keys (user_id, name, key_hash, prefix, status) VALUES (?, ?, ?, ?, "active")',
            [$user['id'], $name, $key['hash'], $key['prefix']]
        );

        $keyId = $db->lastInsertId();

        // Bildirim
        $db->query(
            'INSERT INTO notifications (user_id, type, title, message) VALUES (?, "system", "Yeni API Anahtarı", ?)',
            [$user['id'], "Yeni API anahtarınız oluşturuldu: {$key['prefix']}••••••"]
        );

        jsonSuccess([
            'key' => [
                'id'         => (int) $keyId,
                'name'       => $name,
                'prefix'     => $key['prefix'],
                'raw_key'    => $key['raw'],
                'status'     => 'active',
                'created_at' => date('c'),
            ],
        ], 'API anahtarı başarıyla oluşturuldu! Anahtarınızı şimdi kopyalayın, bir daha gösterilmeyecektir.');
        break;

    // ══════════════════════════════════════════════
    // API ANAHTARLARI: İptal Et
    // ══════════════════════════════════════════════
    case 'revoke_key':
        if ($method !== 'POST') jsonError('Method not allowed.', 405);

        $user  = requireAuth();
        $input = getJsonInput();
        $keyId = (int) ($input['key_id'] ?? 0);

        if (!$keyId) {
            jsonError('Anahtar ID gerekli.');
        }

        // Anahtarın bu kullanıcıya ait olduğunu kontrol et
        $key = $db->fetchOne('SELECT id, prefix, status FROM api_keys WHERE id = ? AND user_id = ?', [$keyId, $user['id']]);
        if (!$key) {
            jsonError('Anahtar bulunamadı.');
        }
        if ($key['status'] === 'revoked') {
            jsonError('Bu anahtar zaten iptal edilmiş.');
        }

        $db->query('UPDATE api_keys SET status = "revoked", revoked_at = NOW() WHERE id = ?', [$keyId]);

        jsonSuccess(null, "API anahtarı iptal edildi: {$key['prefix']}••••••");
        break;

    // ══════════════════════════════════════════════
    // KULLANIM: İstatistikler
    // ══════════════════════════════════════════════
    case 'usage':
        $user   = requireAuth();
        $uid    = $user['id'];
        $period = $_GET['period'] ?? 'today';

        // Zaman aralığı
        $dateFilter = match ($period) {
            'week'  => 'AND u.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)',
            'month' => 'AND u.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)',
            default => 'AND u.created_at >= CURDATE()',
        };

        // Endpoint bazlı istatistikler
        $endpoints = $db->fetchAll(
            "SELECT 
                CONCAT(u.method, ' ', SUBSTRING_INDEX(u.endpoint, '?', 1)) as endpoint,
                COUNT(*) as request_count,
                ROUND(AVG(CASE WHEN u.status_code < 400 THEN 100 ELSE 0 END), 1) as success_rate,
                ROUND(AVG(u.response_time_ms)) as avg_response_ms
             FROM usage_logs u
             WHERE u.user_id = ? {$dateFilter}
             GROUP BY endpoint
             ORDER BY request_count DESC
             LIMIT 20",
            [$uid]
        );

        // Toplam istatistikler
        $totals = $db->fetchOne(
            "SELECT 
                COUNT(*) as total_requests,
                ROUND(AVG(CASE WHEN u.status_code < 400 THEN 100 ELSE 0 END), 1) as success_rate,
                ROUND(AVG(u.response_time_ms)) as avg_response_ms
             FROM usage_logs u
             WHERE u.user_id = ? {$dateFilter}",
            [$uid]
        );

        // Son 10 istek
        $recentLogs = $db->fetchAll(
            "SELECT u.endpoint, u.method, u.status_code, u.response_time_ms, u.request_ip, u.created_at 
             FROM usage_logs u
             WHERE u.user_id = ? {$dateFilter}
             ORDER BY u.created_at DESC 
             LIMIT 10",
            [$uid]
        );

        jsonSuccess([
            'period'    => $period,
            'totals'    => $totals,
            'endpoints' => $endpoints,
            'recent'    => $recentLogs,
        ]);
        break;

    // ══════════════════════════════════════════════
    // BİLDİRİMLER
    // ══════════════════════════════════════════════
    case 'notifications':
        $user = requireAuth();

        $notifications = $db->fetchAll(
            'SELECT id, type, title, message, is_read, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 20',
            [$user['id']]
        );

        // Okunmamışları okundu işaretle
        if ($method === 'POST') {
            $db->query('UPDATE notifications SET is_read = 1, read_at = NOW() WHERE user_id = ? AND is_read = 0', [$user['id']]);
        }

        jsonSuccess(['notifications' => $notifications]);
        break;

    // ══════════════════════════════════════════════
    // BAKİYE HAREKETLERİ
    // ══════════════════════════════════════════════
    case 'balance_history':
        $user = requireAuth();

        $transactions = $db->fetchAll(
            'SELECT amount, type, category, description, balance_before, balance_after, created_at FROM balance_transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 30',
            [$user['id']]
        );

        jsonSuccess([
            'balance'      => (float) $user['balance'],
            'transactions' => $transactions,
        ]);
        break;

    // ══════════════════════════════════════════════
    // ADMIN: Tüm admin_* eylemleri
    // ══════════════════════════════════════════════
    case 'admin_dashboard':
    case 'admin_users':
    case 'admin_user_update':
    case 'admin_plans':
    case 'admin_plan_save':
    case 'admin_plan_delete':
    case 'admin_keys':
    case 'admin_key_revoke':
    case 'admin_usage':
    case 'admin_payments':
    case 'admin_logins':
    case 'admin_settings':
    case 'admin_settings_update':
        require_once __DIR__ . '/admin_api.php';
        break;

    // ══════════════════════════════════════════════
    // VARSAYILAN: Bilinmeyen eylem
    // ══════════════════════════════════════════════
    default:
        jsonError('Geçersiz eylem: ' . htmlspecialchars($action), 404);
        break;
}
