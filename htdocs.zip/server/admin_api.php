<?php
/**
 * admin_api.php — Admin panel API endpoints
 * logsearch.xyz
 *
 * Included by api.php for admin_* actions.
 * $db and helper functions are available from parent scope.
 */

switch ($action) {

    // ══════════════════════════════════════════════
    // ADMIN: Dashboard İstatistikleri
    // ══════════════════════════════════════════════
    case 'admin_dashboard':
        requireAdmin();

        $totalUsers    = $db->fetchOne('SELECT COUNT(*) as cnt FROM users');
        $activeUsers   = $db->fetchOne("SELECT COUNT(*) as cnt FROM users WHERE status = 'active'");
        $suspendedUsers= $db->fetchOne("SELECT COUNT(*) as cnt FROM users WHERE status = 'suspended'");
        $totalKeys     = $db->fetchOne("SELECT COUNT(*) as cnt FROM api_keys WHERE status = 'active'");
        $totalRequests = $db->fetchOne('SELECT COUNT(*) as cnt FROM usage_logs');
        $todayRequests = $db->fetchOne('SELECT COUNT(*) as cnt FROM usage_logs WHERE created_at >= CURDATE()');
        $totalRevenue  = $db->fetchOne("SELECT COALESCE(SUM(amount),0) as total FROM payments WHERE status = 'completed' AND type IN ('subscription','topup')");
        $monthRevenue  = $db->fetchOne("SELECT COALESCE(SUM(amount),0) as total FROM payments WHERE status = 'completed' AND type IN ('subscription','topup') AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
        $avgResponse   = $db->fetchOne('SELECT ROUND(AVG(response_time_ms)) as avg_ms FROM usage_logs');
        $successRate   = $db->fetchOne('SELECT ROUND(AVG(CASE WHEN status_code < 400 THEN 100 ELSE 0 END), 1) as rate FROM usage_logs');

        $recentLogins = $db->fetchAll(
            'SELECT l.email, l.ip_address, l.status, l.failure_reason, l.created_at, u.name as user_name
             FROM login_logs l LEFT JOIN users u ON l.user_id = u.id
             ORDER BY l.created_at DESC LIMIT 10'
        );

        $topUsers = $db->fetchAll(
            'SELECT u.id, u.name, u.email, COUNT(ul.id) as request_count
             FROM users u LEFT JOIN usage_logs ul ON u.id = ul.user_id
             GROUP BY u.id ORDER BY request_count DESC LIMIT 5'
        );

        jsonSuccess([
            'stats' => [
                'total_users'     => (int)($totalUsers['cnt'] ?? 0),
                'active_users'    => (int)($activeUsers['cnt'] ?? 0),
                'suspended_users' => (int)($suspendedUsers['cnt'] ?? 0),
                'total_keys'      => (int)($totalKeys['cnt'] ?? 0),
                'total_requests'  => (int)($totalRequests['cnt'] ?? 0),
                'today_requests'  => (int)($todayRequests['cnt'] ?? 0),
                'total_revenue'   => (float)($totalRevenue['total'] ?? 0),
                'month_revenue'   => (float)($monthRevenue['total'] ?? 0),
                'avg_response_ms' => (int)($avgResponse['avg_ms'] ?? 0),
                'success_rate'    => (float)($successRate['rate'] ?? 100),
            ],
            'recent_logins' => $recentLogins,
            'top_users'     => $topUsers,
        ]);
        break;

    // ══════════════════════════════════════════════
    // ADMIN: Kullanıcı Listesi
    // ══════════════════════════════════════════════
    case 'admin_users':
        requireAdmin();

        $page   = max(1, (int)($_GET['page'] ?? 1));
        $limit  = 20;
        $offset = ($page - 1) * $limit;
        $search = trim($_GET['search'] ?? '');
        $status = trim($_GET['status'] ?? '');
        $role   = trim($_GET['role'] ?? '');

        $where  = [];
        $params = [];

        if ($search) {
            $where[]  = '(u.name LIKE ? OR u.email LIKE ?)';
            $params[] = "%{$search}%";
            $params[] = "%{$search}%";
        }
        if ($status) {
            $where[]  = 'u.status = ?';
            $params[] = $status;
        }
        if ($role) {
            $where[]  = 'u.role = ?';
            $params[] = $role;
        }

        $whereSQL = $where ? 'WHERE ' . implode(' AND ', $where) : '';

        $total = $db->fetchOne("SELECT COUNT(*) as cnt FROM users u {$whereSQL}", $params);
        $users = $db->fetchAll(
            "SELECT u.id, u.name, u.email, u.role, u.status, u.balance, u.plan_id, u.last_login_at, u.last_login_ip, u.created_at,
                    p.name as plan_name, p.slug as plan_slug
             FROM users u LEFT JOIN plans p ON u.plan_id = p.id
             {$whereSQL}
             ORDER BY u.created_at DESC
             LIMIT {$limit} OFFSET {$offset}",
            $params
        );

        jsonSuccess([
            'users'      => $users,
            'total'      => (int)($total['cnt'] ?? 0),
            'page'       => $page,
            'per_page'   => $limit,
            'total_pages'=> ceil(($total['cnt'] ?? 0) / $limit),
        ]);
        break;

    // ══════════════════════════════════════════════
    // ADMIN: Kullanıcı Güncelle
    // ══════════════════════════════════════════════
    case 'admin_user_update':
        if ($method !== 'POST') jsonError('Method not allowed.', 405);
        requireAdmin();

        $input  = getJsonInput();
        $userId = (int)($input['user_id'] ?? 0);
        if (!$userId) jsonError('Kullanıcı ID gerekli.');

        $user = $db->fetchOne('SELECT id FROM users WHERE id = ?', [$userId]);
        if (!$user) jsonError('Kullanıcı bulunamadı.', 404);

        $updates = [];
        $params  = [];

        if (isset($input['role']) && in_array($input['role'], ['user', 'admin'])) {
            $updates[] = 'role = ?';
            $params[]  = $input['role'];
        }
        if (isset($input['status']) && in_array($input['status'], ['active', 'suspended', 'banned'])) {
            $updates[] = 'status = ?';
            $params[]  = $input['status'];
        }
        if (isset($input['balance'])) {
            $updates[] = 'balance = ?';
            $params[]  = (float)$input['balance'];
        }
        if (isset($input['plan_id'])) {
            $updates[] = 'plan_id = ?';
            $params[]  = $input['plan_id'] ? (int)$input['plan_id'] : null;
        }

        if (empty($updates)) jsonError('Güncellenecek alan bulunamadı.');

        $params[] = $userId;
        $db->query('UPDATE users SET ' . implode(', ', $updates) . ' WHERE id = ?', $params);

        jsonSuccess(null, 'Kullanıcı güncellendi.');
        break;

    // ══════════════════════════════════════════════
    // ADMIN: Plan Listesi
    // ══════════════════════════════════════════════
    case 'admin_plans':
        requireAdmin();

        $plans = $db->fetchAll('SELECT * FROM plans ORDER BY sort_order ASC');

        // Her plan için kullanıcı sayısını ekle
        foreach ($plans as &$plan) {
            $cnt = $db->fetchOne('SELECT COUNT(*) as cnt FROM users WHERE plan_id = ?', [$plan['id']]);
            $plan['user_count'] = (int)($cnt['cnt'] ?? 0);
        }

        jsonSuccess(['plans' => $plans]);
        break;

    // ══════════════════════════════════════════════
    // ADMIN: Plan Oluştur / Güncelle
    // ══════════════════════════════════════════════
    case 'admin_plan_save':
        if ($method !== 'POST') jsonError('Method not allowed.', 405);
        requireAdmin();

        $input = getJsonInput();
        $planId = (int)($input['id'] ?? 0);

        $name     = trim($input['name'] ?? '');
        $slug     = trim($input['slug'] ?? '');
        $price    = (float)($input['price'] ?? 0);
        $currency = trim($input['currency'] ?? 'TRY');
        $billing  = $input['billing_period'] ?? 'monthly';
        $rpd      = (int)($input['requests_per_day'] ?? 1000);
        $rpm      = (int)($input['requests_per_min'] ?? 30);
        $maxKeys  = (int)($input['max_keys'] ?? 1);
        $retention= (int)($input['log_retention_days'] ?? 7);
        $features = $input['features'] ?? '[]';
        $sortOrder= (int)($input['sort_order'] ?? 0);
        $isActive = (int)($input['is_active'] ?? 1);

        if (!$name || !$slug) jsonError('Plan adı ve slug gerekli.');

        if (is_array($features)) $features = json_encode($features, JSON_UNESCAPED_UNICODE);

        if ($planId > 0) {
            // Update
            $db->query(
                'UPDATE plans SET name=?, slug=?, price=?, currency=?, billing_period=?, requests_per_day=?, requests_per_min=?, max_keys=?, log_retention_days=?, features=?, sort_order=?, is_active=? WHERE id=?',
                [$name, $slug, $price, $currency, $billing, $rpd, $rpm, $maxKeys, $retention, $features, $sortOrder, $isActive, $planId]
            );
            jsonSuccess(null, 'Plan güncellendi.');
        } else {
            // Insert
            $db->query(
                'INSERT INTO plans (name, slug, price, currency, billing_period, requests_per_day, requests_per_min, max_keys, log_retention_days, features, sort_order, is_active) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
                [$name, $slug, $price, $currency, $billing, $rpd, $rpm, $maxKeys, $retention, $features, $sortOrder, $isActive]
            );
            jsonSuccess(['id' => $db->lastInsertId()], 'Plan oluşturuldu.');
        }
        break;

    // ══════════════════════════════════════════════
    // ADMIN: Plan Sil
    // ══════════════════════════════════════════════
    case 'admin_plan_delete':
        if ($method !== 'POST') jsonError('Method not allowed.', 405);
        requireAdmin();

        $input  = getJsonInput();
        $planId = (int)($input['plan_id'] ?? 0);
        if (!$planId) jsonError('Plan ID gerekli.');

        $userCount = $db->fetchOne('SELECT COUNT(*) as cnt FROM users WHERE plan_id = ?', [$planId]);
        if (($userCount['cnt'] ?? 0) > 0) {
            jsonError('Bu planda aktif kullanıcılar var. Önce kullanıcıları başka plana taşıyın.');
        }

        $db->query('DELETE FROM plans WHERE id = ?', [$planId]);
        jsonSuccess(null, 'Plan silindi.');
        break;

    // ══════════════════════════════════════════════
    // ADMIN: Tüm API Anahtarları
    // ══════════════════════════════════════════════
    case 'admin_keys':
        requireAdmin();

        $page   = max(1, (int)($_GET['page'] ?? 1));
        $limit  = 20;
        $offset = ($page - 1) * $limit;
        $search = trim($_GET['search'] ?? '');

        $where = [];
        $params = [];
        if ($search) {
            $where[]  = '(u.name LIKE ? OR u.email LIKE ? OR k.prefix LIKE ?)';
            $params[] = "%{$search}%";
            $params[] = "%{$search}%";
            $params[] = "%{$search}%";
        }
        $whereSQL = $where ? 'WHERE ' . implode(' AND ', $where) : '';

        $total = $db->fetchOne("SELECT COUNT(*) as cnt FROM api_keys k LEFT JOIN users u ON k.user_id = u.id {$whereSQL}", $params);
        $keys = $db->fetchAll(
            "SELECT k.id, k.name, k.prefix, k.status, k.last_used_at, k.last_used_ip, k.created_at, k.revoked_at,
                    u.name as user_name, u.email as user_email
             FROM api_keys k LEFT JOIN users u ON k.user_id = u.id
             {$whereSQL}
             ORDER BY k.created_at DESC
             LIMIT {$limit} OFFSET {$offset}",
            $params
        );

        jsonSuccess([
            'keys'       => $keys,
            'total'      => (int)($total['cnt'] ?? 0),
            'page'       => $page,
            'total_pages'=> ceil(($total['cnt'] ?? 0) / $limit),
        ]);
        break;

    // ══════════════════════════════════════════════
    // ADMIN: API Anahtarı İptal
    // ══════════════════════════════════════════════
    case 'admin_key_revoke':
        if ($method !== 'POST') jsonError('Method not allowed.', 405);
        requireAdmin();

        $input = getJsonInput();
        $keyId = (int)($input['key_id'] ?? 0);
        if (!$keyId) jsonError('Anahtar ID gerekli.');

        $db->query('UPDATE api_keys SET status = "revoked", revoked_at = NOW() WHERE id = ?', [$keyId]);
        jsonSuccess(null, 'API anahtarı iptal edildi.');
        break;

    // ══════════════════════════════════════════════
    // ADMIN: Kullanım Logları
    // ══════════════════════════════════════════════
    case 'admin_usage':
        requireAdmin();

        $page   = max(1, (int)($_GET['page'] ?? 1));
        $limit  = 30;
        $offset = ($page - 1) * $limit;

        $total = $db->fetchOne('SELECT COUNT(*) as cnt FROM usage_logs');
        $logs  = $db->fetchAll(
            "SELECT ul.endpoint, ul.method, ul.status_code, ul.response_time_ms, ul.request_ip, ul.created_at,
                    u.name as user_name, u.email as user_email
             FROM usage_logs ul LEFT JOIN users u ON ul.user_id = u.id
             ORDER BY ul.created_at DESC
             LIMIT {$limit} OFFSET {$offset}"
        );

        jsonSuccess([
            'logs'       => $logs,
            'total'      => (int)($total['cnt'] ?? 0),
            'page'       => $page,
            'total_pages'=> ceil(($total['cnt'] ?? 0) / $limit),
        ]);
        break;

    // ══════════════════════════════════════════════
    // ADMIN: Ödemeler
    // ══════════════════════════════════════════════
    case 'admin_payments':
        requireAdmin();

        $page   = max(1, (int)($_GET['page'] ?? 1));
        $limit  = 20;
        $offset = ($page - 1) * $limit;

        $total = $db->fetchOne('SELECT COUNT(*) as cnt FROM payments');
        $payments = $db->fetchAll(
            "SELECT p.id, p.amount, p.currency, p.type, p.status, p.payment_method, p.transaction_id, p.description, p.created_at, p.completed_at,
                    u.name as user_name, u.email as user_email
             FROM payments p LEFT JOIN users u ON p.user_id = u.id
             ORDER BY p.created_at DESC
             LIMIT {$limit} OFFSET {$offset}"
        );

        jsonSuccess([
            'payments'   => $payments,
            'total'      => (int)($total['cnt'] ?? 0),
            'page'       => $page,
            'total_pages'=> ceil(($total['cnt'] ?? 0) / $limit),
        ]);
        break;

    // ══════════════════════════════════════════════
    // ADMIN: Giriş Logları
    // ══════════════════════════════════════════════
    case 'admin_logins':
        requireAdmin();

        $page   = max(1, (int)($_GET['page'] ?? 1));
        $limit  = 30;
        $offset = ($page - 1) * $limit;

        $total = $db->fetchOne('SELECT COUNT(*) as cnt FROM login_logs');
        $logins = $db->fetchAll(
            "SELECT l.email, l.ip_address, l.user_agent, l.status, l.failure_reason, l.created_at,
                    u.name as user_name
             FROM login_logs l LEFT JOIN users u ON l.user_id = u.id
             ORDER BY l.created_at DESC
             LIMIT {$limit} OFFSET {$offset}"
        );

        jsonSuccess([
            'logins'     => $logins,
            'total'      => (int)($total['cnt'] ?? 0),
            'page'       => $page,
            'total_pages'=> ceil(($total['cnt'] ?? 0) / $limit),
        ]);
        break;

    // ══════════════════════════════════════════════
    // ADMIN: Site Ayarları (Getir)
    // ══════════════════════════════════════════════
    case 'admin_settings':
        requireAdmin();

        $settings = $db->fetchAll('SELECT `key`, `value`, `type`, `description` FROM settings ORDER BY `key`');
        jsonSuccess(['settings' => $settings]);
        break;

    // ══════════════════════════════════════════════
    // ADMIN: Site Ayarları (Güncelle)
    // ══════════════════════════════════════════════
    case 'admin_settings_update':
        if ($method !== 'POST') jsonError('Method not allowed.', 405);
        requireAdmin();

        $input = getJsonInput();
        $settings = $input['settings'] ?? [];

        if (!is_array($settings) || empty($settings)) {
            jsonError('Güncellenecek ayar bulunamadı.');
        }

        foreach ($settings as $key => $value) {
            $db->query('UPDATE settings SET `value` = ? WHERE `key` = ?', [(string)$value, $key]);
        }

        jsonSuccess(null, 'Ayarlar güncellendi.');
        break;
}
